import dotenv from "dotenv";

dotenv.config();

export default  {
  port: process.env.PORT || 8000,
  jwtSecret: process.env.JWT_SECRET,
  logs: {
    level: process.env.LOG_LEVEL,
  },
  database: {
    host: process.env.DB_HOST || "127.0.0.1",
    port: process.env.DB_PORT ? Number(process.env.DB_PORT) : 5432,
    username: process.env.DB_USER || "postgres",
    password: process.env.DB_PASSWORD,
    database: process.env.DB_DATABASE || "Emp_DB",
  },
  expiresInMinutes: parseInt(process.env.EXPIRES_IN_MINUTES || "120"),
  environment: process.env.NODE_ENV || "development",
};

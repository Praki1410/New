export  enum IRole {
    USER = "USER",
    ADMIN = "ADMIN",
  }
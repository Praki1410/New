export enum IRole {
  Admin = "Admin",
  Employee = "Employee",
  Manager = "Manager",
}

  export enum EmployeeStatus {
    ACTIVE = "Active",
    RESIGNED = "Resigned",
  }
  
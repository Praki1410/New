export interface IJwtPayload {
  userId: string;
  email: string;
  sessionId:string

}


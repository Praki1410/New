import { Request, Response, NextFunction } from "express";
import { ServerException } from "@helpers/ErrorHandler";

import { User } from "../models/user";
import JWTToken from "../utils/createJwtToken";

declare global {
  namespace Express {
    interface Request {
      user?: User;
      files?: { [key: string]: File[] };
    }
  }
}

export const checkJwt = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const jwtToken = new JWTToken();
  try {
    const user = await jwtToken.verify(req, next);

    req.user = user as User;
    return next();
  } catch (e) {
    const err = new ServerException(e.message);
    return next(err);
  }
};

import bcrypt from "bcryptjs";
import * as yup from "yup"
import { emailPattern } from "@validators/user";

export const hashPassword = async (password: string): Promise<string> => {
  return await bcrypt.hash(password, 10);
};

export const comparePassword = (plainPassword: string, hashedPassword: string): boolean => {
  return bcrypt.compareSync(plainPassword, hashedPassword);
};


export const loginValidator = yup.object({
  email: yup.string().email().required().matches(emailPattern),
  password: yup.string().trim().required()
});
import jwt, { JwtPayload } from "jsonwebtoken";
import { IJwtPayload } from "../types/jwtPayload";
import config from "../../config/index";
import { AuthException } from "@helpers/ErrorHandler";
import AppDataSource from "@database";
import { Sessions } from "../models/session";
import { User } from "../models/user";
import { Request, NextFunction } from "express";

export default class JWTToken {
  async create(payload: IJwtPayload) {
    return jwt.sign(payload, config.jwtSecret);
  }

  async verify(req: Request, next: NextFunction): Promise<User | void> {
    const authHeader = req.get("Authorization");
    if (!authHeader) {
      return next(new AuthException());
    }

    const token = authHeader.split(" ")[1];

    let data: IJwtPayload | null = null;
    try {
      const decoded = jwt.verify(token, config.jwtSecret as string);

      if (typeof decoded === "string") {
        return next(new AuthException("Invalid token format"));
      }

      data = decoded as IJwtPayload;
    } catch (error) {
      return next(new AuthException("Token verification failed"));
    }

    const sessionRepository = AppDataSource.getRepository(Sessions);
    if (!data.userId || !data.sessionId) {
      return next(new AuthException());
    }

    const session = await sessionRepository.findOne({
      where: {
        userId: data.userId as string,
        id: data.sessionId as string,
      },
    });

    if (!session) {
      return next(new AuthException());
    }

    const userRepository = AppDataSource.getRepository(User);
    try {
      const user = await userRepository.findOneOrFail({
        where: { email: data.email, id: data.userId },
      });

      return user;
    } catch (error) {
      return next(new AuthException("User not found"));
    }
  }
}

import { Request, Response, NextFunction } from "express";
import AppDataSource from "@database";
import { User } from "../../models/user";
import { createRoleValidator } from "@validators/user";

export default class RegisterController {
  public index = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const user = await createRoleValidator.validate(req.body, { stripUnknown: true });

      const userRepository = AppDataSource.getRepository(User);

      const newUser = userRepository.create({
        ...user,
        createdBy: user.role === 'Employee' 
          ? req.body.createdBy || "SYSTEM" 
          : user.id
      });

      await newUser.hashPassword();

      const data = await userRepository.save(newUser);

      res.status(201).json({
        status: "success",
        message: "User registered successfully",
        data
      });

    } catch (error) {
      return next(error);
    }
  };
}


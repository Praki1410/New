import AppDataSource from "@database";
import { Sessions } from "../../models/session";
import { User } from "../../models/user";
import JWTToken from "../../utils/createJwtToken";
import { loginValidator } from "@validators/auth";
import { RequestHandler } from "express";

export default class LoginController {
  public index: RequestHandler = async (req, res, next) => {
    try {
      const { email, password } = await loginValidator.validate(req.body);

      const userRepository = AppDataSource.getRepository(User);
      const data = await userRepository.findOne({
        where: { email },
        select: ["password", "id", "email", "role"],
      });

      if (!data) {
        res.status(404).json({ status: "error", message: "User not found with this email" });
        return;
      }

      const isPasswordValid = await data.checkIfPasswordMatch(password);
      console.log(isPasswordValid)
      if (!isPasswordValid) {
        res.status(401).json({ status: "error", message: "Invalid password" });
        return;
      }

      const sessionRepository = AppDataSource.getRepository(Sessions);
      const newSession = await sessionRepository.save({ userId: data.id });

      const jwtToken = new JWTToken();
      const token = await jwtToken.create({
        userId: data.id,
        email: data.email,
        sessionId: newSession.id,
      });

      if (!token) {
        res.status(500).json({ status: "error", message: "Token generation failed" });
        return;
      }

      const responseData = {
        status: "success",
        message: "Login successful",
        data: {
          type: "bearer",
          accessToken: token,
          user: {
            id: data.id,
            email: data.email,
            role: data.role
          }
        }
      };

      console.log("Response Data:", JSON.stringify(responseData, null, 2));
      res.status(200).json(responseData);
    } catch (error) {
      console.error("Error:", error);
      next(error); 
    }
  };
}

import RegisterController from "../controllers/auth/registerController";
import LoginController from "@controllers/auth/loginController";
import { Router } from "express";

const route = Router();
const registerController = new RegisterController();
const loginController = new LoginController()

route.post("/register",registerController.index);
route.post("/login",loginController.index)


export default route;


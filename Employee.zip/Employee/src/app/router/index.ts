import { Router } from "express";
import auth from "./authRouter";
const route = Router();



route.use("/auth", auth);

export default route;

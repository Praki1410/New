import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  OneToOne,
  JoinColumn,
  CreateDateColumn,
  UpdateDateColumn,
  BeforeInsert,
  BeforeUpdate
} from "typeorm";
import bcrypt from "bcryptjs";
import { Employee } from "./employeDetails";
import { IRole } from "../../enums/enums";

@Entity({ name: "users" })
export class User {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column({ unique: true })
  email: string;

  @Column({ select: true }) 
  password: string;

  @Column({ type: "enum", enum: IRole })
  role: IRole;

  @Column({ default: false })
  isVerified: boolean;

  @OneToOne(() => Employee, (employee) => employee.user)
  @JoinColumn({ name: "employeeId" })
  employee: Employee;

  @Column({ nullable: false, default: 'SYSTEM' }) 
  createdBy: string;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date | null;

  @BeforeInsert()
  @BeforeUpdate()
  async hashPassword() {
    if (this.password && !this.password.startsWith("$2b$")) {
      this.password = await bcrypt.hash(this.password.trim(), 10);
    }
  }

  async checkIfPasswordMatch(unencryptedPassword: string): Promise<boolean> {
    if (!this.password) {
      throw new Error("Password not found");
    }
    return await bcrypt.compare(unencryptedPassword.trim(), this.password.trim());
  }
}

import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToOne,
  OneToOne,
  JoinColumn,
  CreateDateColumn,
  UpdateDateColumn,
} from "typeorm";
import { IsEnum, IsNotEmpty, IsOptional, IsString, IsDate, IsUUID, IsPhoneNumber } from "class-validator";
import { Department } from "./department";
import { Salary } from "./salary";
import { User } from "./user"; 
import { EmployeeStatus } from "../../enums/enums";

@Entity({ name: "employees" })
export class Employee {
  @PrimaryGeneratedColumn("uuid")
  @IsUUID()
  id: string;

  @OneToOne(() => User, (user) => user.employee)
  @JoinColumn({ name: "userId" }) 
  user: User;

  @Column()
  @IsString()
  @IsNotEmpty()
  FullName: string;

  @Column()
  @IsPhoneNumber(null)
  contact: string;

  @ManyToOne(() => Department, (department) => department.employees)
  department: Department;

  @OneToOne(() => Salary, (salary) => salary.employee)
  @JoinColumn()
  salary: Salary;

  @Column()
  @IsString()
  @IsNotEmpty()
  position: string;

  @Column({ type: "date" })
  @IsDate()
  dateOfJoining: Date;

  @Column({ type: "enum", enum: EmployeeStatus, default: EmployeeStatus.ACTIVE })
  @IsEnum(EmployeeStatus)
  status: EmployeeStatus;

  @Column({ nullable: true })
  @IsOptional()
  @IsUUID()
  reportingManagerId: string | null;

  @Column()
  @IsString()
  @IsNotEmpty()
  createdBy: string;

  @Column({ nullable: true })
  @IsOptional()
  @IsString()
  updatedBy: string | null;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date | null;
}

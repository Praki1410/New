import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  OneToOne,
  ManyToOne,
  CreateDateColumn,
  UpdateDateColumn,
} from "typeorm";
import {
  IsNotEmpty,
  IsNumber,
  IsOptional,
  IsString,
  Min,
} from "class-validator";
import { Employee } from "./employeDetails";
import { Department } from "./department";

@Entity({ name: "salaries" })
export class Salary {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column({ type: "float" })
  @IsNumber()
  @Min(0)
  basicPay: number;

  @Column({ type: "float", default: 0 })
  @IsNumber()
  @Min(0)
  allowances: number;

  @Column({ type: "float", default: 0 })
  @IsNumber()
  @Min(0)
  deductions: number;

  @Column({ type: "float" })
  @IsNumber()
  @Min(0)
  netPay: number;

  @OneToOne(() => Employee, (employee) => employee.salary)
  employee: Employee;

  @ManyToOne(() => Department, (department) => department)
  department: Department;

  @Column()
  @IsString()
  @IsNotEmpty()
  createdBy: string;

  @Column({ nullable: true })
  @IsOptional()
  @IsString()
  updatedBy: string | null;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date | null;
}

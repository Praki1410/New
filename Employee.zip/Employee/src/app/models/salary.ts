import {
    Entity,
    PrimaryGeneratedColumn,
    Column,
    OneToOne,
  } from "typeorm";
  import { Employee } from "./employee";
  
  @Entity({ name: "salaries" })
  export class Salary {
    @PrimaryGeneratedColumn("uuid")
    id: string;
  
    @Column({ type: "float" })
    basicPay: number;
  
    @Column({ type: "float", default: 0 })
    allowances: number;
  
    @Column({ type: "float", default: 0 })
    deductions: number;
  
    @Column({ type: "float" })
    netPay: number;
  
    @OneToOne(() => Employee, (employee) => employee.salary)
    employee: Employee;
  }
  
import {
    Entity,
    PrimaryGeneratedColumn,
    Column,
    OneToMany,
  } from "typeorm";
  import { Employee } from "./employee";
  
  @Entity({ name: "departments" })
  export class Department {
    @PrimaryGeneratedColumn("uuid")
    id: string;
  
    @Column()
    name: string;
  
    @Column({ nullable: true })
    description: string;
  
    @OneToMany(() => Employee, (employee) => employee.department)
    employees: Employee[];
  }
  




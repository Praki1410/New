import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  OneToMany,
  CreateDateColumn,
  UpdateDateColumn,
} from "typeorm";
import { IsNotEmpty, IsOptional, IsString } from "class-validator";
import { Employee } from "./employeDetails";

@Entity({ name: "departments" })
export class Department {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column()
  @IsString()
  @IsNotEmpty()
  name: string;

  @Column({ nullable: true })
  @IsOptional()
  @IsString()
  description: string;

  @OneToMany(() => Employee, (employee) => employee.department)
  employees: Employee[];

  @Column()
  @IsString()
  @IsNotEmpty()
  createdBy: string;

  @Column({ nullable: true })
  @IsOptional()
  @IsString()
  updatedBy: string | null;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date | null;
}

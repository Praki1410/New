import {
    Entity,
    PrimaryGeneratedColumn,
    Column,
    ManyToOne,
    OneToOne,
    JoinColumn,
  } from "typeorm";
  import { User } from "./user";
  import { Department } from "./department";
  import { Salary } from "./salary";
  
  @Entity({ name: "employees" })
  export class Employee {
    @PrimaryGeneratedColumn("uuid")
    id: string;
  
    @Column()
    name: string;
  
    @Column()
    contact: string;
  
    @ManyToOne(() => User, (user) => user.employees)
    user: User;
  
    @ManyToOne(() => Department, (department) => department.employees)
    department: Department;
  
    @OneToOne(() => Salary, (salary) => salary.employee)
    @JoinColumn()
    salary: Salary;
  }
  
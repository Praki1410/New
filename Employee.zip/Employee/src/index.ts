import 'reflect-metadata';
import express from 'express';
import config from "./config/index";
import Allroute from "@router/index";
import AppDataSource from "./database/index";

const app = express();
const PORT = config.port;


app.use(express.json());
app.use("/api/", Allroute);

const start = async () => {
  try {
    await AppDataSource.initialize(); 
    console.log("Database successfully connected ✅");

    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });

  } catch (err) {
    console.error('Error:', err);
  }
};

start();

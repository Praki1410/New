import 'reflect-metadata';
import express from 'express';
import config from "./config/index"

const app = express();
const PORT = config.port;
const start = async () => {
  try {
    
    console.log('Database connected');
    
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (err) {
    console.error('Error:', err);
  }
};

start();



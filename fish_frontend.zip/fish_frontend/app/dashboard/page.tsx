"use client";
import { useEffect, useState, useMemo } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useRouter } from "next/navigation";
import { RootState, AppDispatch } from "@/lib/store/store";
import { getAllFishes } from "@/lib/store/slices/fishSlice";
import { getAllCategories } from "@/lib/store/slices/catrgorySlice";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Fish as FishIcon, X } from "lucide-react";
import { Button } from "@/components/ui/button";

const useFetchDashboardData = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { token } = useSelector((state: RootState) => state.auth);
  const { fishes, isLoading: fishLoading, error: fishError } = useSelector((state: RootState) => state.fish);
  const { categories, isLoading: categoryLoading, error: categoryError } = useSelector((state: RootState) => state.category);

  useEffect(() => {
    if (token) {
      dispatch(getAllFishes());
      dispatch(getAllCategories());
    }
  }, [dispatch, token]);

  return { fishes, fishLoading, fishError, categories, categoryLoading, categoryError };
};

const SummaryCard = ({ title, value }: { title: string; value: number }) => (
  <Card>
    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
      <CardTitle className="text-sm font-medium">{title}</CardTitle>
      <FishIcon className="h-4 w-4 text-muted-foreground" />
    </CardHeader>
    <CardContent>
      <div className="text-2xl font-bold">{value}</div>
    </CardContent>
  </Card>
);

const FishCard = ({ fish, onClick }: { fish: any; onClick: () => void }) => (
  <Card className="cursor-pointer hover:shadow-md transition-all duration-200">
    <CardHeader>
      <CardTitle>{fish.name}</CardTitle>
    </CardHeader>
    <CardContent>
      <div className="w-full h-48 bg-gray-200 flex justify-center items-center mb-4 cursor-pointer" onClick={onClick}>
        <img src={fish.image || "/default-fish-image.jpg"} alt={fish.name} className="object-contain w-full h-full rounded-lg" />
      </div>
      <p className="text-muted-foreground">{fish.description}</p>
    </CardContent>
  </Card>
);

const FishDetailModal = ({ fish, onClose }: { fish: any; onClose: () => void }) => (
  <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center p-4" onClick={onClose}>
    <div className="bg-white p-6 rounded-lg shadow-lg max-w-3xl w-full" onClick={(e) => e.stopPropagation()}>
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-3xl font-semibold">{fish.name}</h2>
        <button className="text-gray-500 hover:text-gray-700" onClick={onClose}>
          <X className="w-6 h-6" />
        </button>
      </div>
      <div className="flex flex-col md:flex-row gap-6">
        <div className="w-full md:w-1/3">
          <img src={fish.image || "/default-fish-image.jpg"} alt={fish.name} className="w-full rounded-lg" />
        </div>
        <div className="flex-1 space-y-2">
          {[
            ["Price", `$${fish.cost}`],
            ["Description", fish.description],
            ["Category", fish.category?.name || "N/A"],
            ["Size", fish.size],
            ["Weight", fish.weight],
            ["Habitat", fish.habitat],
            ["Diet", fish.diet],
            ["Temperament", fish.temperament],
            ["Care Difficulty", fish.careDifficulty],
            ["Water Conditions", fish.waterConditions],
            ["Tank Size", fish.minTankSize],
            ["Compatibility", fish.compatibility],
          ].map(([label, value]) => (
            <p key={label} className="text-lg">
              <strong>{label}:</strong> {value}
            </p>
          ))}
        </div>
      </div>
    </div>
  </div>
);

export default function Dashboard() {
  const { fishes, fishLoading, fishError, categories, categoryLoading, categoryError } = useFetchDashboardData();
  const [selectedFish, setSelectedFish] = useState<any | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const summaryCards = useMemo(() => [
    { id: "total-fish", title: "Total Fish", value: fishes?.length || 0 },
    { id: "categories", title: "Categories", value: categories?.length || 0 },
  ], [fishes, categories]);

  const filteredFish = useMemo(() => {
    if (!selectedCategory) return fishes || [];
    return fishes?.filter((fish: any) => {
      const fishCategoryId = typeof fish.category === "object" ? fish.category?._id : fish.category;
      return String(fishCategoryId) === String(selectedCategory);
    }) || [];
  }, [fishes, selectedCategory]);

  if (fishLoading || categoryLoading) return <div className="text-center font-semibold text-lg">Loading...</div>;
  if (fishError || categoryError) return <div className="text-center text-red-500 font-semibold">Error: {fishError || categoryError}</div>;

  return (
    <div className="container mx-auto p-6">
      <h1 className="text-3xl font-bold mb-6">Dashboard</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {summaryCards.map((card) => <SummaryCard key={card.id} title={card.title} value={card.value} />)}
      </div>

      <div className="mt-8">
        <h2 className="text-2xl font-semibold">Categories</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {categories?.map((category) => (
            <Card
              key={category._id}
              className={`cursor-pointer transition-all duration-200 ${selectedCategory === category._id ? 'ring-2 ring-blue-500 shadow-lg' : 'hover:shadow-md'}`}
              onClick={() => setSelectedCategory(selectedCategory === category._id ? null : category._id)}
            >
              <CardHeader>
                <CardTitle>{category.name}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">{category.description || "No description available"}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      <div className="mt-8">
        <h2 className="text-2xl font-semibold mb-4">
          {selectedCategory 
            ? `Fish in ${categories.find((c: any) => c._id === selectedCategory)?.name || 'Selected Category'}` 
            : 'All Available Fish'}
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredFish.map((fish) => (
            <FishCard key={fish._id} fish={fish} onClick={() => setSelectedFish(fish)} />
          ))}
        </div>
      </div>

      {selectedFish && <FishDetailModal fish={selectedFish} onClose={() => setSelectedFish(null)} />}
    </div>
  );
}

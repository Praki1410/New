
'use client';

import React from 'react';
import Register from './auth/register/page';

export default function Home() {
  return (
    <div>
     <Register/>
    </div>
  );
}

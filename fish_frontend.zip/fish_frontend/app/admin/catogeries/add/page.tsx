"use client";

import { useState, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { useDispatch, useSelector } from "react-redux";
import { createCategory, updateCategory } from '@/lib/store/slices/catrgorySlice'
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AppDispatch, RootState } from "@/lib/store/store";

export default function CategoryForm() {
  const dispatch = useDispatch<AppDispatch>();
  const router = useRouter();
  const searchParams = useSearchParams();
  const categoryId = searchParams.get("id"); 
  

  const existingCategory = useSelector((state: RootState) =>
    categoryId ? state.category.categories.find(cat => cat._id === categoryId) : null
  );

  const [name, setName] = useState(existingCategory?.name || "");
  const [description, setDescription] = useState(existingCategory?.description || "");
  const [error, setError] = useState("");


  useEffect(() => {
    if (existingCategory) {
      setName(existingCategory.name);
      setDescription(existingCategory.description);
    }
  }, [existingCategory]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
  
    try {
      if (categoryId) {
        await dispatch(updateCategory({ _id: categoryId, data: { name, description } })).unwrap();
      } else {
        await dispatch(createCategory({ name, description })).unwrap();
      }
      router.push("/admin/dashboard");
    } catch (error: any) {
      setError(error.message || "Failed to save category. Please try again.");
    }
  };
  

  return (
    <div className="container mx-auto p-6">
      <Card className="max-w-md mx-auto">
        <CardHeader>
          <CardTitle>{categoryId ? "Edit Category" : "Add New Category"}</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <div className="bg-red-50 text-red-500 p-3 rounded-md text-sm">
                {error}
              </div>
            )}

            <div className="space-y-2">
              <label className="text-sm font-medium">Category Name</label>
              <Input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
                placeholder="Enter category name"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Description</label>
              <Textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Enter category description"
              />
            </div>

            <div className="flex justify-end space-x-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => router.push("/admin/dashboard")}
              >
                Cancel
              </Button>
              <Button type="submit">{categoryId ? "Update Category" : "Add Category"}</Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}


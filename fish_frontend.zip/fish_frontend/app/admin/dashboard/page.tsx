"use client";
import { useEffect, useState } from "react";
import { useSelector, useDispatch } from "react-redux";
import { RootState, AppDispatch } from "@/lib/store/store";
import {
  getAllFishes,
  deleteFish,
  updateFish,
} from "@/lib/store/slices/fishSlice";
import {
  getAllCategories,
  deleteCategory,
  updateCategory,
} from "@/lib/store/slices/catrgorySlice";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Fish as FishIcon, Plus } from "lucide-react";
import { useRouter } from "next/navigation";
import FishDetailModal from "@/components/model/fishDetailModal";

export default function AdminDashboard() {
  const dispatch = useDispatch<AppDispatch>();
  const router = useRouter();

  const {
    fishes,
    isLoading: fishLoading,
    error: fishError,
  } = useSelector((state: RootState) => state.fish);
  const {
    categories,
    isLoading: categoryLoading,
    error: categoryError,
  } = useSelector((state: RootState) => state.category);

  const [isEditFishModalOpen, setIsEditFishModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [selectedFish, setSelectedFish] = useState<any>(null);
  const [selectedCategory, setSelectedCategory] = useState<any>(null);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [fishName, setFishName] = useState("");
  const [fishDescription, setFishDescription] = useState("");
  const [fishPrice, setFishPrice] = useState("");
  const [fishImage, setFishImage] = useState("");
  const [scientificName, setScientificName] = useState("");
  const [category, setCategory] = useState("");
  const [fishSize, setFishSize] = useState("");
  const [maxSize, setMaxSize] = useState("");
  const [weight, setWeight] = useState("");
  const [minTankSize, setMinTankSize] = useState("");
  const [waterConditions, setWaterConditions] = useState("");
  const [reefCompatible, setReefCompatible] = useState(false);
  const [isFishDetailModalOpen, setIsFishDetailModalOpen] = useState(false);
  const [diet, setDiet] = useState("");
  const [temperament, setTemperament] = useState("");
  const [careDifficulty, setCareDifficulty] = useState("");
  const [compatibility, setCompatibility] = useState("");
  const [habitat, setHabitat] = useState("");

  
  const openEditFishModal = (fish: any) => {
    setSelectedFish(fish);
    setFishName(fish.name);
    setFishDescription(fish.description);
    setFishPrice(fish.cost?.toString() || "100");
    setScientificName(fish.scientificName || "");
    setCategory(fish.category || "NA");
    setFishSize(fish.size || "");
    setMaxSize(fish.maxSize || "");
    setWeight(fish.weight || "");
    setMinTankSize(fish.minTankSize || "");
    setWaterConditions(fish.waterConditions || "");
    setReefCompatible(fish.reefCompatible || false);
    setFishImage(fish.image || "");
    setHabitat(fish.habitat || "");
    setDiet(fish.diet || "");
    setTemperament(fish.temperament || "");
    setCareDifficulty(fish.careDifficulty || "");
    setCompatibility(fish.compatibility || "");

    setIsEditFishModalOpen(true);
  }
  useEffect(() => {
    dispatch(getAllFishes());
    dispatch(getAllCategories());
  }, [dispatch]);

  const openEditModal = (category: any) => {
    setSelectedCategory(category);
    setName(category.name);
    setDescription(category.description);
    setIsEditModalOpen(true);
  };

  const openFishDetailModal = (fish: any) => {
    setSelectedFish(fish);
    setIsFishDetailModalOpen(true);
  };

  const handleUpdateCategory = async () => {
    if (!selectedCategory) return;

    try {
      await dispatch(
        updateCategory({
          _id: selectedCategory._id,
          data: { name, description },
        })
      ).unwrap();
      dispatch(getAllCategories());
      setIsEditModalOpen(false);
    } catch (error) {
      console.error("Failed to update category:", error);
    }
  };

  if (fishLoading || categoryLoading) {
    return <div className="text-center p-6">Loading...</div>;
  }

  if (fishError || categoryError) {
    return (
      <div className="text-red-500 text-center p-6">
        Error loading data. Please try again.
      </div>
    );
  }
  const summaryCards = [
    {
      id: "total-fish",
      title: "Total Fish",
      value: fishes.length,
      icon: <FishIcon className="h-4 w-4 text-muted-foreground" />,
    },
    {
      id: "total-categories",
      title: "Categories",
      value: categories.length,
      icon: <FishIcon className="h-4 w-4 text-muted-foreground" />,
    },
  ];

  const handleUpdateFish = async (): Promise<void> => {
    if (!selectedFish) return;

    try {
      await dispatch(
        updateFish({
          _id: selectedFish._id,
          data: {
            name: fishName,
            description: fishDescription,
            cost: Number(fishPrice),
            image: fishImage,
            scientificName,
            category,
            size: fishSize,
            maxSize,
            weight,
            minTankSize,
            waterConditions,
            reefCompatible,
            habitat,
            diet,
            temperament,
            careDifficulty,
            compatibility,
          },
        })
      ).unwrap();

      dispatch(getAllFishes());
      setIsEditFishModalOpen(false);
    } catch (error) {
      console.error("Failed to update fish:", error);
    }
  };


  if (fishLoading || categoryLoading) {
    return <div className="text-center p-6">Loading...</div>;
  }

  if (fishError || categoryError) {
    return (
      <div className="text-red-500 text-center p-6">
        Error loading data. Please try again.
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Admin Dashboard</h1>
        <div className="space-x-4">
          <Button onClick={() => router.push("/admin/fish/add")}>
            <Plus className="mr-2 h-4 w-4" /> Add Fish
          </Button>
          <Button
            onClick={() => router.push("/admin/catogeries/add")}
            variant="outline"
          >
            <Plus className="mr-2 h-4 w-4" /> Add Category
          </Button>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {summaryCards.map((card) => (
          <Card key={card.id}>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">
                {card.title}
              </CardTitle>
              {card.icon}
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{card.value}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="mt-8">
        <h2 className="text-2xl font-semibold mb-4">Manage Categories</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {categories.map((category) => (
            <Card key={category._id}>
              <CardHeader>
                <CardTitle>{category.name}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  {category.description || "No description available"}
                </p>
              </CardContent>
              <CardContent>
                <div className="mt-4 space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => openEditModal(category)}
                  >
                    Edit
                  </Button>
                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => {
                      if (
                        category._id &&
                        confirm(
                          "Are you sure you want to delete this category?"
                        )
                      ) {
                        dispatch(deleteCategory(category._id));
                      }
                    }}
                  >
                    Delete
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        <div className="mt-8">
          <h2 className="text-2xl font-semibold mb-4">Manage Fish</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {fishes.map((fish) => {
              const fishId = fish._id;
              return (
                <Card key={fishId}>
                  <CardHeader>
                    <CardTitle>{fish.name}</CardTitle>
                  </CardHeader>
                  <div className="w-full h-48 bg-gray-200 flex justify-center items-center mb-4">
                    <img
                      src={fish.image}
                      alt={fish.name}
                      className="object-contain w-full h-full rounded-lg"
                    />
                  </div>
                  <CardContent>
                    <p className="text-muted-foreground">
                      {fish.description || "No description available"}
                    </p>
                    <p className="mt-2 font-semibold">
                      Price: ${fish.cost || "100"}
                    </p>

                    <div className="mt-4 space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => openFishDetailModal(fish)}
                      >
                        View Details
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => openEditFishModal(fish)}
                      >
                        Edit
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => {
                          if (
                            fishId &&
                            confirm(
                              "Are you sure you want to delete this fish?"
                            )
                          ) {
                            dispatch(deleteFish(fishId));
                          }
                        }}
                      >
                        Delete
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
        {isEditModalOpen && selectedCategory && (
          <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
            <div className="bg-white p-6 rounded-md shadow-lg w-96">
              <h2 className="text-lg font-semibold mb-4">Edit Category</h2>

              <Input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Enter category name"
              />

              <Textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Enter category description"
              />

              <div className="flex justify-end mt-4 space-x-2">
                <Button
                  variant="outline"
                  onClick={() => setIsEditModalOpen(false)}
                >
                  Cancel
                </Button>
                <Button onClick={handleUpdateCategory}>Update</Button>
              </div>
            </div>
          </div>
        )}
{isEditFishModalOpen && selectedFish && (
  <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50 overflow-y-auto">
    <div className="bg-white p-6 rounded-md shadow-lg w-full max-w-3xl max-h-[90vh] overflow-y-auto">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold">Edit Fish: {fishName}</h2>
        <Button variant="ghost" onClick={() => setIsEditFishModalOpen(false)}>
        
        </Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
        {/* Basic Information */}
        <div className="md:col-span-2">
          <h3 className="text-lg font-medium mb-2">Basic Information</h3>
          <div className="border-b mb-4"></div>
        </div>
        
        <div className="space-y-1">
          <label className="text-sm font-medium">Fish Name</label>
          <Input type="text" value={fishName} onChange={(e) => setFishName(e.target.value)} />
        </div>
        
        <div className="space-y-1">
          <label className="text-sm font-medium">Scientific Name</label>
          <Input type="text" value={scientificName} onChange={(e) => setScientificName(e.target.value)} />
        </div>
        
        <div className="space-y-1">
          <label className="text-sm font-medium">Category</label>
          <select 
            value={category} 
            onChange={(e) => setCategory(e.target.value)} 
            className="w-full border rounded p-2 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="">Select a category</option>
            {categories.map((cat) => (
              <option key={cat._id} value={cat._id}>{cat.name}</option>
            ))}
          </select>
        </div>
        
        <div className="space-y-1">
          <label className="text-sm font-medium">Price ($)</label>
          <Input type="number" value={fishPrice} onChange={(e) => setFishPrice(e.target.value)} />
        </div>
        
        <div className="md:col-span-2">
          <label className="text-sm font-medium">Description</label>
          <Textarea 
            value={fishDescription} 
            onChange={(e) => setFishDescription(e.target.value)} 
            rows={3}
            className="mt-1"
          />
        </div>
        
        {/* Physical Characteristics */}
        <div className="md:col-span-2 mt-4">
          <h3 className="text-lg font-medium mb-2">Physical Characteristics</h3>
          <div className="border-b mb-4"></div>
        </div>
        
        <div className="space-y-1">
          <label className="text-sm font-medium">Size</label>
          <Input type="text" value={fishSize} onChange={(e) => setFishSize(e.target.value)} />
        </div>
        
        <div className="space-y-1">
          <label className="text-sm font-medium">Max Size</label>
          <Input type="text" value={maxSize} onChange={(e) => setMaxSize(e.target.value)} />
        </div>
        
        <div className="space-y-1">
          <label className="text-sm font-medium">Weight</label>
          <Input type="text" value={weight} onChange={(e) => setWeight(e.target.value)} />
        </div>
        
        <div className="space-y-1">
          <label className="text-sm font-medium">Habitat</label>
          <Input type="text" value={habitat} onChange={(e) => setHabitat(e.target.value)} />
        </div>
        
        {/* Care Information */}
        <div className="md:col-span-2 mt-4">
          <h3 className="text-lg font-medium mb-2">Care Information</h3>
          <div className="border-b mb-4"></div>
        </div>
        
        <div className="space-y-1">
          <label className="text-sm font-medium">Diet</label>
          <Input type="text" value={diet} onChange={(e) => setDiet(e.target.value)} />
        </div>
        
        {/* <div className="space-y-1">
          <label className="text-sm font-medium">Temperament</label>
          <Input type="text" value={temperament} onChange={(e) => setTemperament(e.target.value)} />
        </div>
         */}
        <div className="space-y-1">
          <label className="text-sm font-medium">Care Difficulty</label>
          <Input type="text" value={careDifficulty} onChange={(e) => setCareDifficulty(e.target.value)} />
        </div>
        
        <div className="space-y-1">
          <label className="text-sm font-medium">Compatibility</label>
          <Input type="text" value={compatibility} onChange={(e) => setCompatibility(e.target.value)} />
        </div>
        
        {/* Tank Requirements */}
        <div className="md:col-span-2 mt-4">
          <h3 className="text-lg font-medium mb-2">Tank Requirements</h3>
          <div className="border-b mb-4"></div>
        </div>
        
        <div className="space-y-1">
          <label className="text-sm font-medium">Water Conditions</label>
          <Input type="text" value={waterConditions} onChange={(e) => setWaterConditions(e.target.value)} />
        </div>
        
        <div className="space-y-1">
          <label className="text-sm font-medium">Minimum Tank Size</label>
          <Input type="text" value={minTankSize} onChange={(e) => setMinTankSize(e.target.value)} />
        </div>
        
        <div className="md:col-span-2 flex items-center space-x-2 mt-2">
          <input 
            type="checkbox" 
            id="reefCompatible"
            checked={reefCompatible} 
            onChange={(e) => setReefCompatible(e.target.checked)}
            className="h-4 w-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500"
          />
          <label htmlFor="reefCompatible" className="text-sm font-medium">Reef Compatible</label>
        </div>
        
        {/* Image */}
        <div className="md:col-span-2 mt-4">
          <h3 className="text-lg font-medium mb-2">Fish Image</h3>
          <div className="border-b mb-4"></div>
        </div>
        
        <div className="md:col-span-2 space-y-1">
          <label className="text-sm font-medium">Image URL</label>
          <Input type="text" value={fishImage} onChange={(e) => setFishImage(e.target.value)} />
        </div>
        
        {fishImage && (
          <div className="md:col-span-2 mt-2">
            <p className="text-sm font-medium mb-1">Preview:</p>
            <div className="w-full h-48 bg-gray-100 flex justify-center items-center rounded-md overflow-hidden">
              <img
                src={fishImage}
                alt={fishName}
                className="object-contain w-full h-full"
                onError={(e) => {
                  e.currentTarget.src = "/placeholder-fish.jpg";
                  e.currentTarget.alt = "Image not available";
                }}
              />
            </div>
          </div>
        )}
      </div>
      
      <div className="flex justify-end mt-6 space-x-2">
        <Button variant="outline" onClick={() => setIsEditFishModalOpen(false)}>Cancel</Button>
        <Button onClick={handleUpdateFish}>Save Changes</Button>
      </div>
    </div>
  </div>
)}
{" "}
        {isFishDetailModalOpen && selectedFish && (
          <FishDetailModal
            fish={selectedFish}
            onClose={() => setIsFishDetailModalOpen(false)}
          />
        )}
      </div>
    </div>
  );
}

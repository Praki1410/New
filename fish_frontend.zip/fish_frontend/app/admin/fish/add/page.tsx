'use client';
import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { useDispatch, useSelector } from 'react-redux';
import { createFish } from '@/lib/store/slices/fishSlice';
import { getAllCategories } from '@/lib/store/slices/catrgorySlice';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { AppDispatch, RootState } from '@/lib/store/store';

export default function AddFish() {
  const dispatch = useDispatch<AppDispatch>();
  const router = useRouter();
  const { categories, isLoading } = useSelector((state: RootState) => state.category);

  const [formData, setFormData] = useState({
    name: '',
    categoryId: '',
    scientificName: '',
    weight: '',
    diet: '',
    image: null as File | null,
    temperament: '',
    careDifficulty: '',
    reefCompatible: false,
    maxSize: '',
    cost: '',
    waterConditions: '',
    minTankSize: '',
    compatibility: '',
    description: '',
  });
  const [formError, setFormError] = useState('');
  const [imagePreview, setImagePreview] = useState<string>('');

  useEffect(() => {
    dispatch(getAllCategories());
  }, [dispatch]);

  const handleChange = useCallback((e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === 'checkbox' ? (e.target as HTMLInputElement).checked : value,
    }));
  }, []);

  const handleSelectChange = useCallback((name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }));
  }, []);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFormData((prev) => ({ ...prev, image: file }));
      const reader = new FileReader();
      reader.onload = () => setImagePreview(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!formData.image) {
      setFormError('Please select an image');
      return;
    }

    const submitData = new FormData();
    Object.entries(formData).forEach(([key, value]) => {
      if (value) {
        submitData.append(
          key === 'categoryId' ? 'category' : key,
          key === 'image' && value instanceof File ? value : value.toString()
        );
      }
    });

    try {
      await dispatch(createFish(submitData)).unwrap();
      router.push('/admin/dashboard');
    } catch (error: any) {
      setFormError(error.message || 'Failed to add fish. Please try again.');
    }
  };

  return (
    <div className="container mx-auto p-6">
      <Card className="max-w-3xl mx-auto shadow-lg rounded-lg">
        <CardHeader>
          <CardTitle className="text-xl font-semibold">Add New Fish</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {formError && <div className="bg-red-100 text-red-600 p-3 rounded-md text-sm">{formError}</div>}

            {/* General Details */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input label="Name *" name="name" value={formData.name} onChange={handleChange} required />
              <Input label="Scientific Name" name="scientificName" value={formData.scientificName} onChange={handleChange} />

              <div>
                <Label htmlFor="categoryId">Category *</Label>
                <Select value={formData.categoryId} onValueChange={(value) => handleSelectChange('categoryId', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder={isLoading ? 'Loading...' : 'Select a category'} />
                  </SelectTrigger>
                  <SelectContent>
                    {categories?.map(({ _id, name }) => (
                      <SelectItem key={_id} value={_id}>{name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="flex items-center space-x-2">
  <Checkbox 
    id="reefCompatible" 
    checked={formData.reefCompatible} 
    onCheckedChange={(checked) => setFormData((prev) => ({
      ...prev,
      reefCompatible: checked === true,
    }))}
  />
  <Label htmlFor="reefCompatible">Reef Compatible</Label>
</div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* <Input label="Size" name="size" value={formData.size} onChange={handleChange} /> */}
              <Input label="Max Size" name="maxSize" value={formData.maxSize} onChange={handleChange} />
              <Input label="Weight" name="weight" value={formData.weight} onChange={handleChange} />
              {/* <Input label="Habitat" name="habitat" value={formData.habitat} onChange={handleChange} /> */}
              <Input label="Diet" name="diet" value={formData.diet} onChange={handleChange} />
              <Input label="Tank Size" name="minTankSize" value={formData.minTankSize} onChange={handleChange} />
              <Input label="Water Conditions" name="waterConditions" value={formData.waterConditions} onChange={handleChange} />
              <Input label="Cost ($)" name="cost" type="number" step="0.01" value={formData.cost} onChange={handleChange} />
            </div>

       
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="compatibility">Compatibility</Label>
                <Select value={formData.compatibility} onValueChange={(value) => handleSelectChange('compatibility', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select compatibility" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Solo">Solo</SelectItem>
                    <SelectItem value="peacefully">peacefully</SelectItem>
                    <SelectItem value="Semi-Aggressive">Semi-Aggressive</SelectItem>
                    <SelectItem value="Aggressive">Aggressive</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="careDifficulty">Care Difficulty</Label>
                <Select value={formData.careDifficulty} onValueChange={(value) => handleSelectChange('careDifficulty', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select difficulty" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Easy">Easy</SelectItem>
                    <SelectItem value="Moderate">Moderate</SelectItem>
                    <SelectItem value="Difficult">Difficult</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

       
            <Input label="Image *" type="file" accept="image/*" onChange={handleImageChange} required />
            {imagePreview && <img src={imagePreview} alt="Preview" className="max-h-40 rounded-md mt-2" />}

      
            <Textarea label="Description *" name="description" value={formData.description} onChange={handleChange} required />


            <div className="flex justify-end space-x-4">
              <Button type="button" variant="outline" onClick={() => router.push('/admin/dashboard')}>Cancel</Button>
              <Button type="submit">Add Fish</Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}


// "use client";
// import { Button } from "@/components/ui/button";
// import { useEffect } from "react";
// import { useDispatch, useSelector } from "react-redux";
// import { getAllCategories } from "@/lib/store/slices/catrgorySlice";
// import { RootState, AppDispatch } from "@/lib/store/store";

// export default function FishDetailModal({ fish, onClose }: { fish: any; onClose: () => void }) {
//   if (!fish) return null;

//   const dispatch = useDispatch<AppDispatch>();
//   const { categories, isLoading } = useSelector((state: RootState) => state.category);

//   useEffect(() => {
//     if (categories.length === 0) {
//       dispatch(getAllCategories());
//     }
//   }, [dispatch, categories.length]);

//   const categoryId = typeof fish.category === "object" ? fish.category?._id : fish.category;
//   const category = categories?.find((c) => c._id.toString() === categoryId?.toString());
//   const categoryName = category ? category.name : "N/A";

//   return (
//     <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
//       <div className="bg-white p-6 rounded-md shadow-lg w-96 max-h-[90vh] overflow-y-auto">
//         <h2 className="text-lg font-semibold mb-4">{fish.name}</h2>
//         <img
//           src={fish.image || "/default-fish-image.jpg"}
//           alt={fish.name}
//           className="w-full h-48 object-contain mb-4"
//           onError={(e) => {
//             e.currentTarget.src = "/default-fish-image.jpg";
//           }}
//         />
//         <p><strong>Scientific Name:</strong> {fish.scientificName || "N/A"}</p>
//         <p><strong>Category:</strong> {isLoading ? "Loading..." : categoryName}</p>
//         <p><strong>Description:</strong> {fish.description || "No description available"}</p>
//         <p><strong>Price:</strong> ${fish.cost || "100"}</p>
//         <p><strong>Mini-Size:</strong> {fish.size || "Unknown"}</p>
//         <p><strong>Max Size:</strong> {fish.maxSize || "Unknown"}</p>
//         <p><strong>Weight:</strong> {fish.weight || "Unknown"}</p>
//         <p><strong>Tank Size:</strong> {fish.minTankSize || "Unknown"}</p>
//         <p><strong>Water Conditions:</strong> {fish.waterConditions || "Unknown"}</p>
//         <p><strong>Compatible:</strong> {fish.compatibility || "Unknown"}</p>
//         <p><strong>Care Difficulty:</strong> {fish.careDifficulty || "Unknown"}</p>
//         <p><strong>Diet:</strong> {fish.diet || "Unknown"}</p>
//         <p><strong>Habitat:</strong> {fish.habitat || "Unknown"}</p>
//         <p><strong>Reef Compatible:</strong> {fish.reefCompatible ? "Yes" : "No"}</p>
//         <div className="flex justify-end mt-4">
//           <Button variant="outline" onClick={onClose}>Close</Button>
//         </div>
//       </div>
//     </div>
//   );
// }
"use client";
import { Button } from "@/components/ui/button";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getAllCategories } from "@/lib/store/slices/catrgorySlice";
import { RootState, AppDispatch } from "@/lib/store/store";

export default function FishDetailModal({ fish, onClose }: { fish: any; onClose: () => void }) {
  console.log("FishDetailModal component rendered");

  if (!fish) {
    console.log("No fish data found");
    return null;
  }

  const dispatch = useDispatch<AppDispatch>();
  const { categories, isLoading } = useSelector((state: RootState) => state.category);

  useEffect(() => {
    console.log("useEffect triggered");

    if (categories.length === 0) {
      console.log("Fetching categories...");
      dispatch(getAllCategories())
        .unwrap()
        .then((res) => console.log("Categories fetched successfully:", res))
        .catch((err) => console.error("Error fetching categories:", err));
    }
  }, [dispatch, categories.length]);



  const categoryId = typeof fish.category === "object" ? fish.category?._id : fish.category;
  console.log("Fish category ID:", categoryId);

  const category = categories?.find((c) => c._id.toString() === categoryId?.toString());
  const categoryName = category ? category.name : "N/A";

  console.log("Category found:", category);

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
      <div className="bg-white p-6 rounded-md shadow-lg w-96 max-h-[90vh] overflow-y-auto">
        <h2 className="text-lg font-semibold mb-4">{fish.name}</h2>
        <img
          src={fish.image || "/default-fish-image.jpg"}
          alt={fish.name}
          className="w-full h-48 object-contain mb-4"
          onError={(e) => {
            e.currentTarget.src = "/default-fish-image.jpg";
          }}
        />
        <p><strong>Scientific Name:</strong> {fish.scientificName || "N/A"}</p>
        <p><strong>Category:</strong> {isLoading ? "Loading..." : categoryName}</p>
        <p><strong>Description:</strong> {fish.description || "No description available"}</p>
        <p><strong>Price:</strong> ${fish.cost || "100"}</p>
        <p><strong>Mini-Size:</strong> {fish.size || "Unknown"}</p>
        <p><strong>Max Size:</strong> {fish.maxSize || "Unknown"}</p>
        <p><strong>Weight:</strong> {fish.weight || "Unknown"}</p>
        <p><strong>Tank Size:</strong> {fish.minTankSize || "Unknown"}</p>
        <p><strong>Water Conditions:</strong> {fish.waterConditions || "Unknown"}</p>
        <p><strong>Compatible:</strong> {fish.compatibility || "Unknown"}</p>
        <p><strong>Care Difficulty:</strong> {fish.careDifficulty || "Unknown"}</p>
        <p><strong>Diet:</strong> {fish.diet || "Unknown"}</p>
        <p><strong>Habitat:</strong> {fish.habitat || "Unknown"}</p>
        <p><strong>Reef Compatible:</strong> {fish.reefCompatible ? "Yes" : "No"}</p>
        <div className="flex justify-end mt-4">
          <Button variant="outline" onClick={onClose}>Close</Button>
        </div>
      </div>
    </div>
  );
}

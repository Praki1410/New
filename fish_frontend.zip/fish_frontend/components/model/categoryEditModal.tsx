// "use client";
// import { useState } from "react";
// import { Button } from "@/components/ui/button";
// import { Input } from "@/components/ui/input";
// import { Textarea } from "@/components/ui/textarea";

// interface categoryEditModalProps {
//   category: any;
//   onClose: () => void;
//   onUpdate: (updatedData: { name: string; description: string }) => void;
// }

// const categoryEditModal = ({ category, onClose, onUpdate }: EditCategoryModalProps) => {
//   const [name, setName] = useState(category.name);
//   const [description, setDescription] = useState(category.description);

//   const handleUpdate = () => {
//     onUpdate({ name, description });
//     onClose();
//   };

//   return (
//     <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
//       <div className="bg-white p-6 rounded-md shadow-lg w-96">
//         <h2 className="text-lg font-semibold mb-4">Edit Category</h2>
//         <Input type="text" value={name} onChange={(e) => setName(e.target.value)} className="mb-3" />
//         <Textarea value={description} onChange={(e) => setDescription(e.target.value)} className="mb-3" />
//         <div className="flex justify-end mt-4 space-x-2">
//           <Button variant="outline" onClick={onClose}>Cancel</Button>
//           <Button onClick={handleUpdate}>Update</Button>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default categoryEditModal;

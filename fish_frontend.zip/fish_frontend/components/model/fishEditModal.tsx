// "use client";
// import { useState } from "react";
// import { Input } from "@/components/ui/input";
// import { Button } from "@/components/ui/button";
// import { Textarea } from "@/components/ui/textarea";

// export default function fishEditModal({ fish, categories, onClose, onUpdate }: { 
//   fish: any; 
//   categories: any[]; 
//   onClose: () => void; 
//   onUpdate: (updatedFish: any) => void;
// }) {
//   const [fishName, setFishName] = useState(fish.name);
//   const [scientificName, setScientificName] = useState(fish.scientificName || "");
//   const [category, setCategory] = useState(fish.category || "");
//   const [fishPrice, setFishPrice] = useState(fish.cost?.toString() || "100");
//   const [fishSize, setFishSize] = useState(fish.size || "");
//   const [maxSize, setMaxSize] = useState(fish.maxSize || "");
//   const [weight, setWeight] = useState(fish.weight || "");
//   const [minTankSize, setMinTankSize] = useState(fish.minTankSize || "");
//   const [waterConditions, setWaterConditions] = useState(fish.waterConditions || "");
//   const [reefCompatible, setReefCompatible] = useState(fish.reefCompatible || false);
//   const [fishImage, setFishImage] = useState(fish.image || "");

//   const handleUpdate = () => {
//     onUpdate({
//       _id: fish._id,
//       name: fishName,
//       scientificName,
//       category,
//       cost: Number(fishPrice),
//       size: fishSize,
//       maxSize,
//       weight,
//       minTankSize,
//       waterConditions,
//       reefCompatible,
//       image: fishImage,
//     });
//   };

//   return (
//     <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
//       <div className="bg-white p-6 rounded-md shadow-lg w-96">
//         <h2 className="text-lg font-semibold mb-4">Edit Fish</h2>

//         <Input type="text" value={fishName} onChange={(e) => setFishName(e.target.value)} placeholder="Enter fish name" className="mb-3" />
//         <Input type="text" value={scientificName} onChange={(e) => setScientificName(e.target.value)} placeholder="Enter scientific name" className="mb-3" />
        
//         <select value={category} onChange={(e) => setCategory(e.target.value)} className="mb-3 w-full border rounded p-2">
//           <option value="">Select a category</option>
//           {categories.map((cat) => (
//             <option key={cat._id} value={cat._id}>{cat.name}</option>
//           ))}
//         </select>

//         <Input type="number" value={fishPrice} onChange={(e) => setFishPrice(e.target.value)} placeholder="Enter fish price ($)" className="mb-3" />
//         <Input type="text" value={fishSize} onChange={(e) => setFishSize(e.target.value)} placeholder="Enter size (e.g., 2-3 inches)" className="mb-3" />
//         <Input type="text" value={maxSize} onChange={(e) => setMaxSize(e.target.value)} placeholder="Enter max size (e.g., 12 inches)" className="mb-3" />
//         <Input type="text" value={weight} onChange={(e) => setWeight(e.target.value)} placeholder="Enter weight (e.g., 500g)" className="mb-3" />
//         <Input type="text" value={minTankSize} onChange={(e) => setMinTankSize(e.target.value)} placeholder="Enter min tank size (e.g., 30 gallons)" className="mb-3" />
//         <Input type="text" value={waterConditions} onChange={(e) => setWaterConditions(e.target.value)} placeholder="Enter water conditions" className="mb-3" />
//         <Input type="text" value={fishImage} onChange={(e) => setFishImage(e.target.value)} placeholder="Enter fish image URL" className="mb-3" />

//         <div className="mb-3">
//           <label className="flex items-center space-x-2">
//             <input type="checkbox" checked={reefCompatible} onChange={(e) => setReefCompatible(e.target.checked)} />
//             <span>Reef Compatible</span>
//           </label>
//         </div>

//         <div className="flex justify-end mt-4 space-x-2">
//           <Button variant="outline" onClick={onClose}>Cancel</Button>
//           <Button onClick={handleUpdate}>Update</Button>
//         </div>
//       </div>
//     </div>
//   );
// }

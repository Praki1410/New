'use client';
import { useEffect, useState } from 'react';
import { useRouter, usePathname } from 'next/navigation'; // Import usePathname
import { useDispatch, useSelector } from 'react-redux';
import { logout } from '@/lib/store/slices/authSlice';
import { RootState, AppDispatch } from '@/lib/store/store';
import { Button } from '@/components/ui/button';
import Link from 'next/link';

export default function Navbar() {
  const dispatch = useDispatch<AppDispatch>();
  const router = useRouter();
  const pathname = usePathname(); // Get current route
  const { user, token } = useSelector((state: RootState) => state.auth);
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true); 
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('authToken');
    dispatch(logout());
    router.push('/auth/login');
  };

  return (
    <nav className="bg-blue-600 text-white py-4">
      <div className="container mx-auto flex justify-between items-center px-4">
        <Link href="/" className="text-2xl font-bold">
          FishaquariumMart
        </Link>

        <div className="space-x-4">
          {user?.role === 'admin' && (
            <Link href="/admin/dashboard" className="hover:underline">
              Admin Panel
            </Link>
          )}
        </div>

        <div>
          {isClient && token ? (
            <Button
              onClick={handleLogout}
              className="bg-red-500 text-white hover:bg-red-600"
            >
              Logout
            </Button>
          ) : (
            pathname !== '/auth/login' && ( // Hide login button if already on login page
              <Link href="/auth/login">
                <Button className="bg-white text-blue-600 hover:bg-gray-200">
                  Login
                </Button>
              </Link>
            )
          )}
        </div>
      </div>
    </nav>
  );
}

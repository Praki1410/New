export interface User {
  _id: string;
  email: string;
  role: 'user' | 'admin';
}

export interface Fish {
  // _id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  categoryId: string;
}


export interface Category {
  // id: string;
  _id?: string;
  name: string;
  description?: string; 
}


export interface AuthState {
  user: {
    name:string,
    email: string;
    role: 'user' | 'admin';
  } | null;
  token: string | null;
  isLoading: boolean;
  error: string | null;
}

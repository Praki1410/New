import axios from "axios";
import Cookies from "js-cookie";

const API_BASE_URL = "http://localhost:5000/api";


export const api = axios.create({
  baseURL: API_BASE_URL,
  headers: { "Content-Type": "application/json" },
});


export const getToken = (): string => {
  if (typeof window === "undefined") return "";
  return localStorage.getItem("token") || Cookies.get("token") || "";
};


export const attachAuthToken = (token: string | null) => {
  if (token) {
    api.defaults.headers.common["Authorization"] = `Bearer ${token}`;
  } else {
    delete api.defaults.headers.common["Authorization"];
  }
};


attachAuthToken(getToken());

import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { api, attachAuthToken, getToken } from "@/lib/api";
import Cookies from "js-cookie";
import { AuthState } from "@/lib/types";

const initialState: AuthState = {
  user: null,
  token: getToken(),
  isLoading: false,
  error: null,
};


export const register = createAsyncThunk(
  "auth/register",
  async (
    credentials: { name: string; email: string; password: string; role: "user" | "admin" },
    { rejectWithValue }
  ) => {
    try {
      const response = await api.post("/auth/register", credentials);
      return response.data;
    } catch (error: any) {
      console.error("Registration Error:", error.response?.data);
      return rejectWithValue(error.response?.data || "Registration failed");
    }
  }
);


export const login = createAsyncThunk(
  "auth/login",
  async (credentials: { email: string; password: string }, { rejectWithValue }) => {
    try {
      const response = await api.post("/auth/login", credentials);
      const { token, user } = response.data;
      if (typeof window !== "undefined") {
        localStorage.setItem("token", token);
      }
      Cookies.set("token", token,);
      attachAuthToken(token);
      return { user, token };
    } catch (error: any) {
      console.error("Login Error:", error.response?.data);
      return rejectWithValue(error.response?.data || "Login failed");
    }
  }
);


export const logout = createAsyncThunk("auth/logout", async () => {
  try {
    await api.post("/auth/logout");
  } catch (error) {
    console.warn("Logout API call failed");
  }
  if (typeof window !== "undefined") {
    localStorage.removeItem("token");
  }
  Cookies.remove("token");
  attachAuthToken(null);

});


export const checkAuth = createAsyncThunk("auth/checkAuth", async (_, { rejectWithValue }) => {
  try {
    const response = await api.get("/auth/me");
    return response.data;
  } catch (error: any) {
    return rejectWithValue(error.response?.data || "Not authenticated");
  }
});

const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    resetAuthState: (state) => {
      state.user = null;
      state.token = "";
      state.isLoading = false;
      state.error = null;

      if (typeof window !== "undefined") {
        localStorage.removeItem("token");
      }
      Cookies.remove("token");
      attachAuthToken(null);
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(register.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(register.fulfilled, (state, action) => {
        state.isLoading = false;
        state.user = action.payload.user;
        state.token = action.payload.token;
      })
      .addCase(register.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      .addCase(login.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(login.fulfilled, (state, action) => {
        state.isLoading = false;
        state.user = action.payload.user;
        state.token = action.payload.token;
      })
      .addCase(login.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      .addCase(logout.fulfilled, (state) => {
        state.user = null;
        state.token = "";
      })
      .addCase(checkAuth.fulfilled, (state, action) => {
        state.user = action.payload.user;
      })
      .addCase(checkAuth.rejected, (state) => {
        state.user = null;
        state.token = "";
      });
  },
});

// ✅ Export Actions & Reducer
export const { resetAuthState } = authSlice.actions;
export default authSlice.reducer;



import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import { RootState } from "@/lib/store/store";
import { api } from "@/lib/api"; 

export interface Fish {
  // id: string;
  _id?: string;
  name: string;
  category: string;
  scientificName?: string;
  size?: string;
  weight?: string;
  habitat?: string;
  diet?: string;
  price?: number;
  image?: string;
  temperament?: string;
  careDifficulty?: string;
  reefCompatible?: boolean;
  maxSize?: string;
  cost?: number;
  waterConditions?: string;
  minTankSize?: string;
  compatibility?: string;
  description?: string;
}

interface FishState {
  fishes: Fish[];
  isLoading: boolean;
  error: string | null;
}

const initialState: FishState = {
  fishes: [],
  isLoading: false,
  error: null,
};


const API_BASE_URL = "/fish";

export const getAllFishes = createAsyncThunk<Fish[], void>(
  "fish/getAllFishes",
  async (_, { rejectWithValue }) => {
    try {
      const response = await api.get(`${API_BASE_URL}`);
      return response.data.data.map((fish: any) => ({
        ...fish,
        id: fish._id?.$oid || fish._id || fish.id,
      }));
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.message || "Failed to fetch fishes");
    }
  }
);

export const getFishById = createAsyncThunk<Fish, string>(
  "fish/getFishById",
  async (id, { rejectWithValue }) => {
    try {
      const response = await api.get(`${API_BASE_URL}/${id}`);
      return response.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data || "Fish not found");
    }
  }
);

export const createFish = createAsyncThunk<Fish, FormData>(
  "fish/createFish",
  async (fishData, { rejectWithValue }) => {
    try {
      const response = await api.post(`${API_BASE_URL}/add-fish`, fishData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      return response.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data || "Failed to add fish");
    }
  }
);

export const updateFish = createAsyncThunk<Fish, { _id: string; data: Partial<Fish> }>(
  "fish/updateFish",
  async ({ _id, data }, { rejectWithValue }) => {
    try {
      const response = await api.put(`${API_BASE_URL}/editFish/${_id}`, data);
      return response.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data || "Failed to update fish");
    }
  }
);

export const deleteFish = createAsyncThunk<string, string>(
  "fish/deleteFish",
  async (fishId, { rejectWithValue }) => {
    try {
      await api.delete(`${API_BASE_URL}/deletefish/${fishId}`);
      return fishId;
    } catch (error: any) {
      return rejectWithValue(error.response?.data || "Error deleting fish");
    }
  }
);

const fishSlice = createSlice({
  name: "fish",
  initialState,
  reducers: {
    clearSelectedFish: (state) => {
      state.fishes = [];
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getAllFishes.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(getAllFishes.fulfilled, (state, action: PayloadAction<Fish[]>) => {
        state.isLoading = false;
        state.fishes = action.payload;
      })
      .addCase(getAllFishes.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      .addCase(getFishById.fulfilled, (state, action) => {
        state.fishes = [action.payload];
      })
      .addCase(createFish.fulfilled, (state, action) => {
        state.fishes.push(action.payload);
      })
      .addCase(updateFish.fulfilled, (state, action) => {
        const index = state.fishes.findIndex((fish) => fish._id === action.payload._id);
        if (index !== -1) state.fishes[index] = action.payload;
      })
      .addCase(deleteFish.fulfilled, (state, action) => {
        state.fishes = state.fishes.filter((fish) => fish._id !== action.payload);
      });
  },
});

export const { clearSelectedFish } = fishSlice.actions;
export default fishSlice.reducer;

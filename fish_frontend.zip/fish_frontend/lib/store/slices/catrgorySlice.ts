import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { RootState } from '@/lib/store/store';
import { api, attachAuthToken } from '@/lib/api'

interface Category {

  _id: string;
  name: string;
  description: string;
}
interface Fish {
  _id: string;
  name: string;
  category: string;
}

interface CategoryState {
  categories: Category[];
  fishList: Fish[]; 
  selectedCategory: Category | null;
  isLoading: boolean;
  error: string | null;
}

const initialState: CategoryState = {
  categories: [],
  fishList:[] ,
  selectedCategory: null,
  isLoading: false,
  error: null,
};


export const getAllCategories = createAsyncThunk(
  'category/getAllCategories',
  async (_, { rejectWithValue, getState }) => {
    try {
      const state = getState() as RootState;
      attachAuthToken(state.auth.token); 
      const response = await api.get('fish/getcategories');
      return response.data.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data?.message || 'Failed to fetch categories');
    }
  }
);

export const getFishByCategory = createAsyncThunk(
  'fish/getFishByCategory',
  async (categoryId: string, { rejectWithValue, getState }) => {
    try {
      const state = getState() as RootState;
      attachAuthToken(state.auth.token);
      const response = await api.get(`fish/category/${categoryId}`);
      return response.data.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data || 'Failed to fetch fish by category');
    }
  }
);

export const createCategory = createAsyncThunk(
  'category/createCategory',
  async (categoryData: { name: string; description: string }, { rejectWithValue, getState }) => {
    try {
      const state = getState() as RootState;
      attachAuthToken(state.auth.token); 
      const response = await api.post('fish/addCategory', categoryData);
      return response.data;
    } catch (error: any) {
      return rejectWithValue(error.response?.data || 'Failed to create category');
    }
  }
);




export const updateCategory = createAsyncThunk(
  'category/updateCategory',
  async ({ _id, data }: { _id: string; data: Partial<Category> }, { rejectWithValue, getState }) => {
    try {
      const state = getState() as RootState;
      attachAuthToken(state.auth.token);
      const response = await api.put(`fish/editCategory/${_id}`, data);
      return response.data.data; 
    } catch (error: any) {
      return rejectWithValue(error.response?.data || 'Failed to update category');
    }
  }
);

export const deleteCategory = createAsyncThunk(
  'category/deleteCategory',
  async (id: string, { rejectWithValue, getState }) => {
    try {
      const state = getState() as RootState;
      attachAuthToken(state.auth.token);
      await api.delete(`fish/deleteCategory/${id}`);
      return id;
    } catch (error: any) {
      return rejectWithValue(error.response?.data || 'Failed to delete category');
    }
  }
);

const categorySlice = createSlice({
  name: 'category',
  initialState,
  reducers: {
    clearSelectedCategory: (state) => {
      state.selectedCategory = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getAllCategories.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(getAllCategories.fulfilled, (state, action) => {
        state.categories = action.payload;
        state.isLoading = false;
      })
      .addCase(getAllCategories.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      .addCase(getFishByCategory.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(getFishByCategory.fulfilled, (state, action) => {
        state.fishList = action.payload;
        state.isLoading = false;
      })
      .addCase(getFishByCategory.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      })
      .addCase(createCategory.fulfilled, (state, action) => {
        state.categories.push(action.payload);
      })
      .addCase(updateCategory.fulfilled, (state, action) => {
        const index = state.categories.findIndex((category) => category._id === action.payload.id);
        if (index !== -1) {
          state.categories[index] = action.payload;
        }
      })
      .addCase(deleteCategory.fulfilled, (state, action) => {
        state.categories = state.categories.filter((category) => category._id !== action.payload);
      });
  },
});

export const { clearSelectedCategory } = categorySlice.actions;
export default categorySlice.reducer;









import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import Cookies from 'js-cookie';

const API_URL ='http://localhost:5000/api/v1/auth';


interface AuthFormData {
  email: string;
  password: string;
}

interface AuthResponse {
  token: string;
  role: string;
  userId: string;
}

interface ForgotPasswordResponse {
  message: string;
}

interface ResetPasswordResponse {
  message: string;
}

interface AuthState {
  isAuthenticated: boolean;
  userRole: string | null;
  userId: string | null;
  status: 'idle' | 'loading' | 'succeeded' | 'failed';
  error: string | null;
  forgotPasswordStatus: 'idle' | 'loading' | 'succeeded' | 'failed';
  resetPasswordStatus: 'idle' | 'loading' | 'succeeded' | 'failed';  
  resetPasswordMessage: string | null;  
}


const API_ERRORS = {
  forgotPassword: 'Failed to send reset link',
  resetPassword: 'Failed to reset password',
  invalidLogin: 'Invalid login credentials!',
  unknown: 'Unknown API error occurred.',
  network: 'Network error occurred, please try again later.',
};


interface ErrorResponse {
  message?: string;
}


function handleApiError(error: unknown): string {
  if (error instanceof Error) {
    return error.message;
  }
  if (isAxiosError(error)) {
    return error.response?.data?.message || API_ERRORS.unknown;
  }

  if (error instanceof TypeError) {
    return API_ERRORS.network;
  }

  return API_ERRORS.unknown;
}


function isAxiosError(error: unknown): error is { response: { data: ErrorResponse } } {
  return typeof error === 'object' && error !== null && 'response' in error;
}


export const forgotPassword = createAsyncThunk<
  ForgotPasswordResponse, 
  { email: string }, 
  { rejectValue: string }
>(
  'auth/forgotPassword',
  async ({ email }, { rejectWithValue }) => {
    try {
      const response = await fetch(`${API_URL}/forgot-password`, {  
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData?.message || API_ERRORS.forgotPassword);
      }

      const data: ForgotPasswordResponse = await response.json(); 
      return data;
    } catch (error: unknown) {
      const errorMessage = handleApiError(error);
      return rejectWithValue(errorMessage);
    }
  }
);

export const sendResetLink = createAsyncThunk<ResetPasswordResponse, { token: string; newPassword: string }, { rejectValue: string }>('auth/resetPassword',
  async ({ token, newPassword }, { rejectWithValue }) => {
    try {
      const response = await fetch(`${API_URL}/reset-password`, {  
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json', 
          'Authorization': `Bearer ${token}` 
        },
        body: JSON.stringify({ newPassword }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData?.message || API_ERRORS.resetPassword);
      }

      const data: ResetPasswordResponse = await response.json(); 
      return data;
    } catch (error: unknown) {
      const errorMessage = handleApiError(error);
      return rejectWithValue(errorMessage);
    }
  }
);

export const registerUser = createAsyncThunk<AuthResponse, AuthFormData, { rejectValue: string }>(
  'auth/registerUser',
  async (formData, { rejectWithValue }) => {
    try {
      const response = await fetch(`${API_URL}/register`, {  
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData?.message || API_ERRORS.unknown);
      }

      const data: AuthResponse = await response.json();
      return data;
    } catch (error: unknown) {
      const errorMessage = handleApiError(error);
      return rejectWithValue(errorMessage);
    }
  }
);


export const loginUser = createAsyncThunk<AuthResponse, AuthFormData, { rejectValue: string }>(
  'auth/loginUser',
  async (formData, { rejectWithValue }) => {
    try {
      const response = await fetch(`${API_URL}/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData?.message || API_ERRORS.invalidLogin);
      }

     
      const data: AuthResponse = await response.json();  
      
     
      return data;
    } catch (error: unknown) {
      const errorMessage = handleApiError(error);
      return rejectWithValue(errorMessage);
    }
  }
);


const authSlice = createSlice({
  name: 'auth',
  initialState: {
    isAuthenticated: !!Cookies.get('token'),
    userRole: Cookies.get('role') || null,
    userId: Cookies.get('userId') || null,
    status: 'idle',
    error: null,
    forgotPasswordStatus: 'idle', 
    resetPasswordStatus: 'idle',   
    resetPasswordMessage: null,    
  } as AuthState,
  reducers: {
    logout: (state) => {
      state.isAuthenticated = false;
      state.userRole = null;
      state.userId = null;
      Cookies.remove('token');
      Cookies.remove('role');
      Cookies.remove('userId');
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(registerUser.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(registerUser.fulfilled, (state, action) => {
        state.isAuthenticated = true;
        state.userRole = action.payload.role;
        state.userId = action.payload.userId;
        state.error = null;
        state.status = 'succeeded';
      })
      .addCase(registerUser.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.payload || null;
      })
      .addCase(loginUser.pending, (state) => {
        state.status = 'loading';
      })
      .addCase(loginUser.fulfilled, (state, action) => {
        state.isAuthenticated = true;
        state.userRole = action.payload.role;
        state.userId = action.payload.userId;
        state.error = null;
        state.status = 'succeeded';
      })
      .addCase(loginUser.rejected, (state, action) => {
        state.status = 'failed';
        state.error = action.payload || null;
      })
      .addCase(forgotPassword.pending, (state) => {
        state.forgotPasswordStatus = 'loading';
      })
      .addCase(forgotPassword.fulfilled, (state, action) => {
        state.forgotPasswordStatus = 'succeeded';
        state.resetPasswordMessage = action.payload.message;
      })
      .addCase(forgotPassword.rejected, (state, action) => {
        state.forgotPasswordStatus = 'failed';
        state.error = action.payload || null;
      })
      .addCase(sendResetLink.pending, (state) => {
        state.resetPasswordStatus = 'loading';
      })
      .addCase(sendResetLink.fulfilled, (state, action) => {
        state.resetPasswordStatus = 'succeeded';
        state.resetPasswordMessage = action.payload.message;
      })
      .addCase(sendResetLink.rejected, (state, action) => {
        state.resetPasswordStatus = 'failed';
        state.error = action.payload || null;
      });
  },
});

export const { logout } = authSlice.actions;
export default authSlice.reducer;

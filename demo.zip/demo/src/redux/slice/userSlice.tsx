import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import {fetchData} from "../../services/fetchData"

const API_URL = 'http://localhost:5000/api/v1/user'; 

export interface User {
  id: string | number;
  name: string;
  email: string;
  role: string;
}

export interface Pagination {
  currentPage: number;
  totalPages: number;
  totalItems: number;
  itemsPerPage: number;
  hasNextPage: boolean;
  hasPreviousPage: boolean;
}

export interface UsersResponse {
  data: User[];
  pagination: Pagination;
  success: boolean;
}

export interface UsersState {
  users: User[];
  pagination: Pagination;
  usersStatus: 'idle' | 'loading' | 'succeeded' | 'failed';
  usersError: string | null;
  roleFilter: string;
}

const initialState: UsersState = {
  users: [],
  pagination: {
    currentPage: 1,
    totalPages: 1,
    totalItems: 0,
    itemsPerPage: 5,
    hasNextPage: false,
    hasPreviousPage: false,
  },
  usersStatus: 'idle',
  usersError: null,
  roleFilter: '', 
};


export const fetchAllUsers = createAsyncThunk<UsersResponse, { page: number; role?: string; status?: string }, { rejectValue: string }>(
  'users/fetchAll',
  async ({ page, role, status }, { rejectWithValue }) => {
    let url = `${API_URL}/users?page=${page}`;
    if (role) url += `&role=${role}`;
    if (status) url += `&status=${status}`;

    try {
      return await fetchData(url, 'GET');
    } catch (error: unknown) {
      return rejectWithValue(error instanceof Error ? error.message : 'Failed to fetch users');
    }
  }
);

export const editUser = createAsyncThunk<User, { id: string | number; email: string; role: string; name?: string }, { rejectValue: string }>(
  'users/edit',
  async (user, { rejectWithValue }) => {
    const { id, email, role } = user;
    const body: { email: string; role: string; } = { email, role };

    try {
      const url = `${API_URL}/users/${id}`;
      return await fetchData(url, 'PATCH', body);
    } catch (error: unknown) {
      return rejectWithValue(error instanceof Error ? error.message : 'Failed to edit user');
    }
  }
);

export const deleteUser = createAsyncThunk<string, string, { rejectValue: string }>(
  'users/delete',
  async (userId, { rejectWithValue }) => {
    try {
      const url = `${API_URL}/users/${userId}`;
      await fetchData(url, 'DELETE');
      return userId;
    } catch (error: unknown) {
      return rejectWithValue(error instanceof Error ? error.message : 'Failed to delete user');
    }
  }
);



const usersSlice = createSlice({
  name: 'users',
  initialState,
  reducers: {
    setRoleFilter: (state, action) => {
      state.roleFilter = action.payload;
    },
    setPagination: (state, action) => {
      state.pagination = action.payload;
    },
    setPage: (state, action) => {
      state.pagination.currentPage = action.payload;
    },
    setUsers(state, action) {
      state.users = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchAllUsers.pending, (state) => {
        state.usersStatus = 'loading';
      })
      .addCase(fetchAllUsers.fulfilled, (state, action) => {
        state.users = action.payload.data || [];
        state.pagination = action.payload.pagination;
        state.usersStatus = 'succeeded';
        state.usersError = null;
      })
      .addCase(fetchAllUsers.rejected, (state, action) => {
        state.usersStatus = 'failed';
        state.usersError = action.payload as string;
      })
      .addCase(editUser.fulfilled, (state, action) => {
        const updatedUser = action.payload;
        state.users = state.users.map((user) =>
          user.id === updatedUser.id ? updatedUser : user
        );
      })
      .addCase(deleteUser.fulfilled, (state, action) => {
        const userId = action.payload;
        state.users = state.users.filter((user) => user.id !== userId);
      });
  },
});

export const { setRoleFilter, setPagination, setPage ,setUsers} = usersSlice.actions;

export default usersSlice.reducer;



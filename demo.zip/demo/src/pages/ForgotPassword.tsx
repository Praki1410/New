import { useState, ChangeEvent, FormEvent } from "react";
import { useDispatch, useSelector } from "react-redux";
import { AppDispatch, RootState } from "../redux/store";
import { forgotPassword } from "../redux/slice/authSlice";

const ForgotPassword = () => {
  const dispatch = useDispatch<AppDispatch>();
  const [email, setEmail] = useState<string>("");
  const [message, setMessage] = useState<string>("");
  const forgotPasswordStatus = useSelector((state: RootState) => state.auth.forgotPasswordStatus);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();

    try {
      const response = await dispatch(forgotPassword({ email })).unwrap();
      setMessage(response.message);
    } catch (error) {
      setMessage((error as Error).message || "Something went wrong");
    }
  };

  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    setEmail(e.target.value);
  };

  return (
    <div>
      <h2>Forgot Password</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="email"
          placeholder="Enter your email"
          value={email}
          onChange={handleChange}
          required
        />
        <button type="submit" disabled={forgotPasswordStatus === "loading"}>
          {forgotPasswordStatus === "loading" ? "Sending..." : "Send Reset Link"}
        </button>
      </form>
      <p>{message}</p>
    </div>
  );
};

export default ForgotPassword;

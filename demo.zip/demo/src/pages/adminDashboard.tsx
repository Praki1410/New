import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchAllUsers, setRoleFilter, deleteUser, setUsers, editUser } from '../redux/slice/userSlice';
import { AppDispatch, RootState } from '../redux/store';
import './AdminDashboard.css';

const AdminDashboard: React.FC = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { users, usersStatus, usersError, pagination, roleFilter } = useSelector(
    (state: RootState) => state.users
  );

  const [deleteMessage, setDeleteMessage] = useState<string>('');
  const [editingUserId, setEditingUserId] = useState<string | number | null>(null);
  const [editedUserData, setEditedUserData] = useState<{ email: string; role: string }>({
    email: '',
    role: 'user', 
  });

  const handlePrevPage = () => {
    if (pagination.currentPage > 1) {
      const prevPage = pagination.currentPage - 1;
      dispatch(fetchAllUsers({ page: prevPage, role: roleFilter }));
    }
  };

  const handleNextPage = () => {
    if (pagination.currentPage < pagination.totalPages) {
      const nextPage = pagination.currentPage + 1;
      dispatch(fetchAllUsers({ page: nextPage, role: roleFilter }));
    }
  };

  const handleEditUser = (userId: string | number) => {
    const userToEdit = users.find((user) => user.id === userId);
    if (userToEdit) {
      setEditingUserId(userId);
      setEditedUserData({
        email: userToEdit.email,
        role: userToEdit.role, 
      });
    }
  };

  const handleDeleteUser = async (userId: string | number) => {
    const stringId = String(userId);
    try {
      await dispatch(deleteUser(stringId));
      setDeleteMessage('User deleted successfully!');

      // Remove the deleted user from the local state
      const updatedUsers = users.filter((user) => user.id !== userId);
      dispatch(setUsers(updatedUsers)); // Update users in the global state

    } catch (error: unknown) {
      setDeleteMessage(`Error deleting user: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
  };

  const handleRoleFilterChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    const selectedRole = event.target.value;
    dispatch(setRoleFilter(selectedRole));
    dispatch(fetchAllUsers({ page: 1, role: selectedRole }));
  };

  const handleUpdateUser = async () => {
    if (editingUserId !== null) {
      const userToUpdate = users.find((user) => user.id === editingUserId);
      if (userToUpdate) {
        const updatedUser = {
          email: editedUserData.email,
          role: editedUserData.role,
        };
  
        try {
        
          await dispatch(editUser({ ...updatedUser, id: editingUserId }));
          
         
          const updatedUsersList = users.map(user =>
            user.id === editingUserId ? { ...user, ...updatedUser } : user
          );
          dispatch(setUsers(updatedUsersList))
  
          setEditingUserId(null); 
          setDeleteMessage('User updated successfully!');
        } catch (error: unknown) {
          setDeleteMessage(`Error updating user: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
      }
    }
  };
  

  useEffect(() => {
    if (usersStatus === 'idle') {
      dispatch(fetchAllUsers({ page: 1, role: roleFilter }));
    }
  }, [dispatch, usersStatus, roleFilter]);

  return (
    <div className="admin-dashboard">
      <div className="role-filter">
        <label htmlFor="role-filter" className="role-filter-label">Filter by Role:</label>
        <select
          id="role-filter"
          value={roleFilter}
          onChange={handleRoleFilterChange}
          className="role-filter-select"
        >
          <option value="">All Roles</option>
          <option value="admin">Admin</option>
          <option value="user">User</option>
        </select>
      </div>

      {usersStatus === 'loading' && <p className="loading-text">Loading users...</p>}
      {usersStatus === 'failed' && <p className="error-text">Error: {usersError}</p>}
      {deleteMessage && <p className="delete-message">{deleteMessage}</p>}

      {usersStatus === 'succeeded' && (
        <div className="user-table-container">
          <table className="user-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Email</th>
                <th>Role</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {(users || []).map((user) => (
                <tr key={user.id}>
                  <td>{user.id}</td>
                  <td>{user.email}</td>
                  <td>{user.role}</td>
                  <td className="actions">
                    {editingUserId === user.id ? (
                      <>
                        <input
                          type="email"
                          value={editedUserData.email}
                          onChange={(e) =>
                            setEditedUserData({ ...editedUserData, email: e.target.value })
                          }
                          placeholder="Enter email"
                          className="edit-input"
                        />
                        <select
                          value={editedUserData.role}
                          onChange={(e) =>
                            setEditedUserData({ ...editedUserData, role: e.target.value })
                          }
                          className="edit-input"
                        >
                          <option value="admin">Admin</option>
                          <option value="user">User</option>
                        </select>
                        <button
                          onClick={handleUpdateUser}
                          className="update-button"
                        >
                          Update
                        </button>
                      </>
                    ) : (
                      <>
                        <button
                          onClick={() => handleEditUser(Number(user.id))}
                          className="edit-button"
                        >
                          Edit
                        </button>
                        <button
                          onClick={() => handleDeleteUser(user.id)}
                          className="delete-button"
                        >
                          Delete
                        </button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          <div className="pagination-container">
            <button
              onClick={handlePrevPage}
              disabled={pagination.currentPage <= 1}
              className="px-4 py-2 bg-blue-500 text-white rounded disabled:bg-gray-300 disabled:cursor-not-allowed"
            >
              Previous
            </button>
            <span className="pagination-info">
              Page {pagination.currentPage} of {pagination.totalPages}
            </span>
            <button
              onClick={handleNextPage}
              disabled={pagination.currentPage >= pagination.totalPages}
              className="px-4 py-2 bg-blue-500 text-white rounded disabled:bg-gray-300 disabled:cursor-not-allowed"
            >
              Next
            </button>
          </div>
        </div>
      )}

      {usersStatus === 'succeeded' && users.length === 0 && (
        <p className="no-users-text">No users found.</p>
      )}
    </div>
  );
};

export default AdminDashboard;

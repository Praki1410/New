import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { registerUser } from "../redux/slice/authSlice";
import { useNavigate } from "react-router-dom";
import { AppDispatch } from "../redux/store";
import { Link } from "react-router-dom"; 

interface FormData {
  email: string;
  password: string;
  role: "user" | "admin";
}

interface AuthState {
  status: "idle" | "loading" | "succeeded" | "failed";
  error: string | null;
}

const Signup: React.FC = () => {
  const [formData, setFormData] = useState<FormData>({
    email: "",
    password: "",
    role: "user",
  });

  const dispatch = useDispatch<AppDispatch>();
  const navigate = useNavigate();
  const { status, error } = useSelector((state: { auth: AuthState }) => state.auth);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleRoleToggle = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData((prev) => ({
      ...prev,
      role: e.target.checked ? "admin" : "user",
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const action = await dispatch(registerUser(formData));
      if (registerUser.fulfilled.match(action)) {
   
        setFormData({
          email: "",
          password: "",
          role: "user",
        });
        navigate("/");
      }
    } catch (error) {
      console.error("Registration failed:", error);
    }
  };

  return (
    <div style={{ display: "flex", justifyContent: "center", alignItems: "center", height: "100vh", backgroundColor: "#f0f0f0" }}>
      <div style={{ width: "400px", padding: "20px", borderRadius: "8px", backgroundColor: "#ffffff", boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)" }}>
        <h2 style={{ textAlign: "center" }}>🚀 Create Your Account</h2>
        <p style={{ textAlign: "center", color: "#777" }}>Join the platform today!</p>

        {error && (
          <p style={{ color: "red", textAlign: "center", marginBottom: "10px" }}>
            {error}
          </p>
        )}


        {status === "succeeded" && !error && (
          <p style={{ color: "green", textAlign: "center", marginBottom: "10px" }}>
            Registration Successful! Redirecting...
          </p>
        )}

        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: "16px" }}>
            <label htmlFor="email" style={{ display: "block", marginBottom: "8px" }}>Email</label>
            <input
              id="email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              style={{ width: "100%", padding: "10px", borderRadius: "4px", border: "1px solid #ddd" }}
              required
            />
          </div>
          
          <div style={{ marginBottom: "16px" }}>
            <label htmlFor="password" style={{ display: "block", marginBottom: "8px" }}>Password</label>
            <input
              id="password"
              name="password"
              type="password"
              value={formData.password}
              onChange={handleChange}
              style={{ width: "100%", padding: "10px", borderRadius: "4px", border: "1px solid #ddd" }}
              required
            />
          </div>

          <div style={{ marginBottom: "16px" }}>
            <label style={{ display: "block", marginBottom: "8px" }}>
              <input
                type="checkbox"
                checked={formData.role === "admin"}
                onChange={handleRoleToggle}
                style={{ marginRight: "8px" }}
              />
              Register as Admin
            </label>
          </div>

          <div style={{ textAlign: "center" }}>
            <button
              type="submit"
              style={{
                padding: "10px 20px",
                backgroundColor: "#1976d2",
                color: "#fff",
                borderRadius: "4px",
                border: "none",
                cursor: "pointer",
                fontSize: "16px",
                width: "100%",
              }}
              disabled={status === "loading"}
            >
              {status === "loading" ? "Loading..." : "Sign Up"}
            </button>
          </div>
        </form>

        <div style={{ textAlign: "center", marginTop: "16px" }}>
          <p>Already have an account? <Link to="/login" style={{ color: "#1976d2" }}>Login here</Link></p>
        </div>
      </div>
    </div>
  );
};

export default Signup;

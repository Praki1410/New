import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { loginUser } from "../redux/slice/authSlice";
import { useNavigate } from "react-router-dom";
import { AppDispatch } from "../redux/store";
import Cookies from "js-cookie";

interface FormData {
  email: string;
  password: string;
}

interface AuthState {
  status: "idle" | "loading" | "succeeded" | "failed";
  error: string | null;
  popupMessage: string;
  popupOpen: boolean;
}

const Login: React.FC = () => {
  const [formData, setFormData] = useState<FormData>({ email: "", password: "" });
  const dispatch = useDispatch<AppDispatch>();
  const navigate = useNavigate();
  const { status, error, popupMessage, popupOpen } = useSelector((state: { auth: AuthState }) => state.auth);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const action = await dispatch(loginUser(formData));
      if (loginUser.fulfilled.match(action)) {
        const role = Cookies.get("role");
        if (role === "admin") {
          navigate("/admin-dashboard");
        } else if (role === "user") {
          navigate("/user-profile");
        }
      }
    } catch (err) {
      console.error("Login failed:", err);
    }
  };

  return (
    <div style={{ display: "flex", justifyContent: "center", alignItems: "center", height: "100vh", backgroundColor: "#f0f0f0" }}>
      <div style={{
        width: "400px",
        padding: "20px",
        backgroundColor: "#ffffff",
        borderRadius: "8px",
        boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)"
      }}>
        <h2 style={{ textAlign: "center" }}>🚪 Welcome Back</h2>
        <p style={{ textAlign: "center", color: "#777" }}>Please login to your account.</p>

        {error && <p style={{ color: "red", textAlign: "center", marginBottom: "10px" }}>{error}</p>}
        
        {popupOpen && popupMessage && <p style={{ color: "green", textAlign: "center", marginBottom: "10px" }}>{popupMessage}</p>}

        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: "16px" }}>
            <label htmlFor="email" style={{ display: "block", marginBottom: "8px" }}>Email</label>
            <input
              id="email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              style={{ width: "100%", padding: "10px", borderRadius: "4px", border: "1px solid #ddd" }}
              required
            />
          </div>

          <div style={{ marginBottom: "16px" }}>
            <label htmlFor="password" style={{ display: "block", marginBottom: "8px" }}>Password</label>
            <input
              id="password"
              name="password"
              type="password"
              value={formData.password}
              onChange={handleChange}
              style={{ width: "100%", padding: "10px", borderRadius: "4px", border: "1px solid #ddd" }}
              required
            />
          </div>

          <div style={{ marginBottom: "16px", textAlign: "right" }}>
            <a href="/forgot" style={{ color: "#1976d2", fontSize: "14px" }}>
              Forgot your password?
            </a>
          </div>

          <div style={{ marginBottom: "16px", textAlign: "center" }}>
            <p style={{ fontSize: "14px" }}>
              Don't have an account?{" "}
              <a href="/" style={{ color: "#1976d2" }}>
                Sign up
              </a>
            </p>
          </div>

          <div style={{ textAlign: "center" }}>
            <button
              type="submit"
              style={{
                padding: "10px 20px",
                backgroundColor: "#1976d2",
                color: "#fff",
                borderRadius: "4px",
                border: "none",
                cursor: "pointer",
                fontSize: "16px",
                width: "100%",
              }}
              disabled={status === "loading"}
            >
              {status === "loading" ? (
                <div style={{ display: "inline-block", width: "24px", height: "24px", border: "4px solid #fff", borderTop: "4px solid #1976d2", borderRadius: "50%", animation: "spin 1s linear infinite" }} />
              ) : (
                "Login"
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Login;

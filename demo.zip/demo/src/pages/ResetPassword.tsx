import { useState, FormEvent } from "react";
import { useDispatch } from "react-redux";
import { sendResetLink } from "../redux/slice/authSlice";
import { useParams, useNavigate } from "react-router-dom";
import { AppDispatch } from "../redux/store"; 
interface Params extends Record<string, string | undefined> {
    token: string;
}
interface ErrorResponse {
    response?: {
        data: {
            message: string;
        };
    };
}

const ResetPassword = () => {
    const [newPassword, setNewPassword] = useState<string>("");
    const [confirmPassword, setConfirmPassword] = useState<string>("");
    const [message, setMessage] = useState<string>("");
    const [loading, setLoading] = useState<boolean>(false); 
    const { token } = useParams<Params>();
    const dispatch = useDispatch<AppDispatch>(); 
    const navigate = useNavigate();

    const handleSubmit = async (e: FormEvent) => {
        e.preventDefault();

        if (newPassword !== confirmPassword) {
            setMessage("Passwords do not match!");
            return;
        }

        if (!token) {
            setMessage("Invalid or missing token!");
            return;
        }

        setLoading(true); 

        try {
            const response = await dispatch(sendResetLink({ token, newPassword }));
            if (response.meta.requestStatus === 'fulfilled' && response.payload) {
                if (typeof response.payload === 'object' && 'message' in response.payload) {
                    setMessage(response.payload.message); 
                    alert(response.payload.message); 
                    navigate("/login");
                } else {
                    setMessage("Password reset failed!");
                    alert("Password reset failed!");
                }
            } else {
                setMessage("Password reset failed!");
                alert("Password reset failed!");
            }
        } catch (error: unknown) {
            const err = error as ErrorResponse;
            setMessage(err.response ? err.response.data.message : "Something went wrong");
            alert(err.response ? err.response.data.message : "Something went wrong");
        } finally {
            setLoading(false); 
        }
    };

    return (
        <div>
            <h2>Reset Password</h2>
            <form onSubmit={handleSubmit}>
                <input
                    type="password"
                    placeholder="New Password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    required
                />
                <input
                    type="password"
                    placeholder="Confirm Password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    required
                />
                <button type="submit" disabled={loading}>
                    {loading ? "Loading..." : "Reset Password"}
                </button>
            </form>
            <p>{message}</p>
        </div>
    );
};

export default ResetPassword;

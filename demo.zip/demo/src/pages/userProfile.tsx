
import React from 'react'
const    UserProfile: React.FC = () => {
  return (
    <div>
      <h1>Hello User </h1>
      <p>This is an empty page!</p>
    </div>
  );
};

export default UserProfile;

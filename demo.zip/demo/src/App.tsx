import React from "react";

import AllRoute from "./router/Allroutes"


const App: React.FC = () => {
  return (
    <>
      <AllRoute />
    </>
  );
};

export default App;

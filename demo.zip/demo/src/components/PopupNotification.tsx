import React from "react";
import { useSelector, useDispatch } from "react-redux";
import { Snackbar, Alert } from "@mui/material";
import { hidePopup } from "../redux/slice/authSlice"

interface RootState {
  auth: {
    popupMessage: string;
    popupOpen: boolean;
  };
}

const PopupNotification: React.FC = () => {
  const dispatch = useDispatch();
  const { popupMessage, popupOpen } = useSelector(
    (state: RootState) => state.auth
  );

  const handleClose = () => {
    dispatch(hidePopup());
  };

  return (
    <Snackbar
      open={popupOpen}
      autoHideDuration={6000} 
      onClose={handleClose}
    >
      <Alert
        onClose={handleClose}
        severity={popupMessage.includes("error") ? "error" : "success"}
        sx={{ width: "100%" }}
      >
        {popupMessage}
      </Alert>
    </Snackbar>
  );
};

export default PopupNotification;

import Cookies from 'js-cookie'; 
export const fetchData = async (url: string, method: string, body?: object) => {
  const token = Cookies.get('token');
  if (!token) {
    throw new Error('Authorization token is missing');
  }

  try {
    const response = await fetch(url, {
      method,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
      },
      body: body ? JSON.stringify(body) : undefined,
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData?.message || 'API request failed');
    }

    return await response.json();
  } catch (error: unknown) {
    console.error('Error in fetchData:', error);
    throw error instanceof Error ? error.message : 'An error occurred';
  }
};

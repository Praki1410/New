import React from "react";
import { Route, Routes } from "react-router-dom";
import Login from "../pages/login";
import Signup from "../pages/signup";
import ForgotPassword from "../pages/ForgotPassword";
import ResetPassword from "../pages/ResetPassword";
import AdminDashboard from "../pages/adminDashboard";
import UserProfile from "../pages/userProfile";
import Cookies from "js-cookie";

const Allroutes: React.FC = () => {
  const userRole = Cookies.get("role");
  return (
    <Routes>
      <Route path="/" element={<Signup />} />
      <Route path="/login" element={<Login />} />
      <Route path="/forgot" element={<ForgotPassword />} />
      <Route path="/reset-password/:token" element={<ResetPassword />} />
      {userRole === "admin" && (
        <Route path="/admin-dashboard" element={<AdminDashboard />} />
      )}
      {userRole === "user" && (
        <Route path="/user-profile" element={<UserProfile />} />
      )}
    </Routes>
  );
};

export default Allroutes;

import config from "@config";
import { Response } from "express";
import { EntityNotFoundError, QueryFailedError, TypeORMError } from "typeorm";
import { ValidationError } from "yup";

export class ErrorHandler extends Error {
  public status: number;
  public message: string;
  constructor(status: number, message: string) {
    super();
    this.status = status;
    this.message = message;
  }
}

export class BadRequestException {
  status = 400;
  constructor(public message: string = "Bad request") {}
}


export class AuthorizationException {
  status = 403;
  constructor(public message: string = "Permission denied.") {}
}

export class ServerException {
  status = 500;
  constructor(public message: string = "Internal server error") {
    this.message = message;
  }
}

export class ExpiredException {
  status = 401;
  message: string;

  constructor(entity: string = "Link") {
    this.message = `${entity} has expired`;
  }
}

export class AuthException {
  status = 401;
  constructor(public message: string = "User is not authorized") {}
}
export class AuthExpiredException {
  status = 410;
  constructor(
    public message: string = "The entered date has expired. You cannot log in."
  ) {}
}
export class NotMatchException {
  status = 422;
  message: string;

  constructor(entity: string = "Record") {
    this.message = `${entity} does not match`;
  }
}

export class InternalServerException {
  status = 500;
  message: string;

  constructor(message: string = "An unexpected error occurred.") {
    this.message = message;
  }
}


export class NotFoundException {
  status = 404;
  message: string;

  constructor(entity: string = "Record") {
    this.message = `${entity} not found`;
  }
}



export class InvalidFileException {
  status = 422;
  message: string;

  constructor() {
    this.message = `Invalid file extension`;
  }
}

export class AcceptedException {
  status = 403;
  constructor(
    public message: string = "This conversation is already accepted by other agent"
  ) {}
}

export class ExistException {
  status = 409;
  message: string;

  constructor(entity: string = "Record") {
    this.message = `This ${entity} already exists`;
  }
}

export class VerifiedException {
  status = 401;
  constructor(
    public message: string = "Your profile is not verified, contact with admin."
  ) {}
}

export const handleError = (err: ErrorHandler, res: Response) => {
  const { status = 500, message } = err;
  if (err instanceof ValidationError) {
    return res.status(422).json({ error: message });
  }
  if (err instanceof EntityNotFoundError) {
    return res.status(404).json({ error: message });
  }

  if (err instanceof QueryFailedError && err["code"] === "23505") {
    const message = err["detail"].replace(
      /^Key \((.*)\)=\((.*)\) (.*)/,
      (_match, key, value) =>
        `This ${key === "slug" ? "category" : key} ${value} already exists.`
    );
    return res.status(422).json({ error: message });
  }

  if (err instanceof TypeORMError) {
    return res.status(500).json({ error: err.stack });
  }

  res.status(status).json({
    error: err.stack || message,
  });
};

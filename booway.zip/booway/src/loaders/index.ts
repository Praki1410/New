import { Application } from 'express';
import Logger from '../logger';
import expressLoader from './express';
import AppDataSource from '@database';

export default async (app: Application): Promise<void> => {
  try {
    await AppDataSource.initialize()
  } catch (err) {
    Logger.error(err);
    throw err;
  }
  Logger.info('Database loaded and connected!');

  expressLoader(app);
  Logger.info('Express loaded!');
};
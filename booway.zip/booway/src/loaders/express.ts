// import bodyParser from "body-parser";
// import cors from "cors";
// import { Application, NextFunction, Request, Response } from "express";
// import apiRoutes from "@router";
// import config from "@config";
// import { ErrorHandler, handleError } from "@helpers/ErrorHandler";
// import Logger from "../logger";
// import fileUpload from "express-fileupload";
// import express from "express";

// export default (app: Application): void => {
//   app.use(
//     cors({
//       origin: config.appUrl,
//     }),
//   );

//   // app.use(bodyParser.json());
//   // app.use(bodyParser.urlencoded({ extended: false }));

//   app.use(express.json());  
//   app.use(express.urlencoded({ extended: true }))
//   app.use('/uploads', express.static('uploads'));
//   app.use(fileUpload({ limits: { fileSize: 10 * 1024 * 1024 } })); 


//   app.use(`/${config.endpointPrefix}`, apiRoutes);
//   app.use((err: Error, req: Request, res: Response, next: NextFunction) => {
//     if (err.name === "UnauthorizedError") {

//       return res.status(401).json({ error: err.message });
//     } else {
//       next(err);
//     }
//   });

//   app.use(
//     (err: ErrorHandler, _req: Request, res: Response, _next: NextFunction) => {
//       Logger.error("Error: %o", err.message);
//       handleError(err, res);
//     },
//   );
// };


import bodyParser from "body-parser";
import cors from "cors";
import { Application, NextFunction, Request, Response } from "express";
import apiRoutes from "@router";
import config from "@config";
import { ErrorHandler, handleError } from "@helpers/ErrorHandler";
import Logger from "../logger";
import express from "express";

export default (app: Application): void => {
  app.use(
    cors({
      origin: config.appUrl,
    }),
  );

  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));
  app.use('/uploads', express.static('uploads'));
  app.use(`/${config.endpointPrefix}`, apiRoutes);

  app.use((err: Error, req: Request, res: Response, next: NextFunction) => {
    if (err.name === "UnauthorizedError") {
      return res.status(401).json({ error: err.message });
    } else {
      next(err);
    }
  });

  app.use(
    (err: ErrorHandler, _req: Request, res: Response, _next: NextFunction) => {
      Logger.error("Error: %o", err.message);
      handleError(err, res);
    },
  );
};

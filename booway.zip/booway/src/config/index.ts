import dotenv from "dotenv";

dotenv.config();

export default {
  port: process.env.PORT || 8000,
  jwtSecret: process.env.JWT_SECRET,
  logs: {
    level: process.env.LOG_LEVEL,
  },
  database: {
    host: process.env.DB_HOST || "127.0.0.1",
    port: process.env.DB_PORT ? Number(process.env.DB_PORT) : 5432,
    username: process.env.DB_USER || "postgres",
    password: process.env.DB_PASSWORD,
    database: process.env.DB_DATABASE || "pg_db",
  },
  mail: {
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT),
    auth: {
      user: process.env.SMTP_USERNAME,
      pass: process.env.SMTP_PASSWORD,
    },
    from: process.env.SMTP_FROM,
  },
  endpointPrefix: "api",
  baseUrl: process.env.BASE_URL,
  expiresInMinutes: parseInt(process.env.EXPIRES_IN_MINUTES || "120"),
  appUrl: process.env.APP_URL,
  environment: process.env.NODE_ENV || "development",
  companyName: "Booway",
};

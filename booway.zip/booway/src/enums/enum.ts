export enum ActivityStatus {
    PENDING = "Pending",
    VERIFIED = "Verified",
    REJECTED = "Rejected",
    ACTIVE = "Active"
}

export enum IRole {
  USER = "USER",
  PROVIDER = "PROVIDER",
  ADMIN = "ADMIN",
}

export enum UserRole {
    USER = "USER",
    PROVIDER = "PROVIDER",
    ADMIN = "ADMIN",
  }
  export  enum ActivityLevel {
    EASY = "easy",
    MODERATE = "moderate",
    HARD = "hard",
    EXTREMELY_HARD = "extremely hard",
  }
  export   enum ActivityType {
    BIKE_TOUR = "bike tour",
    BIKE_RENT = "bike rent",
    TREKKING = "trekking",
    CARVING = "carving",
    CLIMBING = "climbing",
  }

  export enum Language {
    DUTCH = "dutch",
    GERMAN = "german",
    ENGLISH = "english",
    FRENCH = "french",
  }
  
import config from "@config";
import { createTransport } from "nodemailer";
import hbs from "@utils/template";

interface Config {
  email: string;
  subject: string;
  template: string;
  data: { [key: string]: string };
}
const transport = createTransport(config.mail);

export default class Mail {
  async send({ email, subject, template, data }: Config) {
    const html = await hbs.render(template, data);
    return await transport.sendMail({
      to: email,
      from: config.mail.from,
      subject,
      html,
    });
  }
}

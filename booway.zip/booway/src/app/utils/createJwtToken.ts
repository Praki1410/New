import jwt from "jsonwebtoken";

import { IJwtPayload } from "../types/jwtPayload";
import config from "@config";
import { AuthException } from "@helpers/ErrorHandler";
import AppDataSource from "@database";
import { Sessions } from "@models/session";
import { User } from "@models/user";
import { Request, NextFunction } from "express";

export default class JWTToken {
  async create(payload: IJwtPayload) {
    return jwt.sign(payload, config.jwtSecret);
  }

  async verify(req: Request, next: NextFunction): Promise<User | void> {
    const authHeader = req.get("Authorization");
    if (!authHeader) {
      const err = new AuthException();
      return next(err);
    }

    const token = authHeader.split(" ")[1];
    const data: IJwtPayload = await jwt.verify(
      token,
      config.jwtSecret as string
    );
    const sessionRepository = AppDataSource.getRepository(Sessions);
    if (!data.userId || !data.sessionId) {
      const err = new AuthException();
      return next(err);
    }
    const session = await sessionRepository.findOne({
      where: {
        userId: data.userId as string,
        id: data.sessionId as string,
      },
    });
    if (!session) {
      const err = new AuthException();
      return next(err);
    }
    const userRepository = AppDataSource.getRepository(User);
    const user = await userRepository.findOneOrFail({
      where: { email: data.email, id: data.userId },
    });
    return user;
  }
}

import { PasswordReset } from "@models/passwordReset";
import crypto from "node:crypto";

interface IData {
  expiresTime: number;
  resetEntry: PasswordReset;
  token: string;
}
export default class Token {
  async create(email: string) {
    const randomStr = crypto.randomBytes(20).toString("hex");
    const baseStr = Buffer.from(`${randomStr}|${email}`, "utf-8");

    const uniqueStr = baseStr.toString("base64");
    const token = crypto.createHash("sha256").update(uniqueStr).digest("hex");

    return {
      uniqueStr,
      token,
    };
  }

  async expired(resetEntry: PasswordReset, expiresTime: number) {
    const MINUTE = 1000 * 60;

    const milliseconds = MINUTE * expiresTime;
    const tokenValid = Date.now() - milliseconds;
    return resetEntry.updatedAt.getTime() <= tokenValid;
  }

  async verify({ resetEntry, token, expiresTime }: IData) {
    let validatedToken = true;
    if (resetEntry) {
      const uniqueToken = crypto
        .createHash("sha256")
        .update(token)
        .digest("hex");
      validatedToken = resetEntry.token === uniqueToken;
      if (validatedToken && (await this.expired(resetEntry, expiresTime))) {
        validatedToken = false;
      }
    } else {
      validatedToken = false;
    }

    return validatedToken;
  }
}

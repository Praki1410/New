

import config from "@config";
import fs from "node:fs";
import path from "node:path";
import { InvalidFileException } from "@helpers/ErrorHandler";
import { validateFile } from "@validators/activity";

export default class Storage {
  

  async store(file: any, folderName: string) {
    const folderPath = path.resolve(__dirname, "..", "..", "..");

    const uploadPath = path.join(folderPath, `public/uploads/${folderName}`);
    if (!fs.existsSync(uploadPath)) {
      fs.mkdirSync(uploadPath, { recursive: true });
    }

    const [type, extension] = file.mimetype.split("/");
    const name = `${Date.now()}_${file.name.replace(/[()\s]/g, "_")}`;
    const newpath = `./public/uploads/${folderName}/${name}`;

    try {
      await file.mv(newpath);
      return {
        path: `${folderName}/${name}`,
        type,
        name,
      };
    } catch (err) {
      console.error("Error uploading file.", err);
      return null;
    }
  }


  async storeMultiple(files: any[], folderName: string) {
    if (!Array.isArray(files) || files.length === 0) {
      return [];
    }

    const results = await Promise.all(
      files.map(async (file) => {
        if (!validateFile(file)) {
          throw new InvalidFileException();
        }
        return this.store(file, folderName);
      })
    );


    return results.filter((result) => result !== null);
  }

  async handleMultipleFileUpload(files: any[], folder: string) {
    if (!Array.isArray(files) || files.length === 0) {
      return [];
    }

    const uploadedFiles = await Promise.all(
      files.map(async (file) => {
        if (!validateFile(file)) {
          throw new InvalidFileException();
        }

        const storedFile = await this.store(file, folder);
        return typeof storedFile === "string" ? storedFile : storedFile.path;
      })
    );

    return uploadedFiles;
  }

  async delete(name: string) {
    const rootDirectory = path.resolve(__dirname, "..", "..", "..");
    const filePath = path.join(rootDirectory, "public/uploads", name);

    fs.unlink(filePath, (err) => {
      if (err) console.error("Error deleting file:", err);
    });
  }

  // ✅ Get File URL
  get(value: string) {
    return `${config.baseUrl}/uploads/${value}`;
  }
}

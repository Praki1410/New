import { IRole } from "../../enums/enum";


export const permissions = {
  categories: {
    list: "categories.list",
    show: "categories.show",
    create: "categories.create",
    update: "categories.update",
    delete: "categories.delete",
  },
  users: {
    list: "users.list",
    delete: "users.delete",
  },
  activity: {
    list: "activity.list",
    show: "activity.show",
    create: "activity.create",
    update: "activity.update",
    delete: "activity.delete",
  },
  booking: {
    list: "booking.list",
    show: "booking.show",
    create: "booking.create",
    update: "booking.update",
    delete: "booking.delete",
  },
};

const userPermission = [permissions.booking.create, permissions.booking.list];
const providerPermission = [
  permissions.categories.list,
  permissions.activity.create,
  permissions.activity.delete,
  permissions.activity.update,
  permissions.booking.list
];
const adminPermission = [
  ...Object.values(permissions.activity),
  ...Object.values(permissions.categories),
  ...Object.values(permissions.users),
];

export const deniedPermission = (role, permission) => {
  return !(role === IRole.USER
    ? userPermission.includes(permission)
    : role === IRole.PROVIDER
      ? providerPermission.includes(permission)
      : role === IRole.ADMIN
        ? adminPermission.includes(permission)
        : true);
};

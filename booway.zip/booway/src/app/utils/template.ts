import { create } from "express-handlebars";
const hbs = create({
  helpers: {
    appUrl() {
      return process.env.APP_URL;
    },
  },
  defaultLayout: false,
  extname: '.html'
});

export default hbs;

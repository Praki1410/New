import { DateTime } from "luxon";

export const parseDateString = (dateString: string) => {
  return DateTime.fromFormat(dateString, "yyyy-MM-dd");
};

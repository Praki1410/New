import {
  Equal,
  FindOperator,
  FindOptionsOrder,
  FindOptionsWhere,
  ILike,
  Not,
  Repository,
} from "typeorm";

export interface IKey {
  key: string;
  value: string;
}

const mapOperator = (operator: string, value: string): FindOperator<string> => {
  switch (operator) {
    case "like":
      return ILike(`%${value}%`);
    case "not":
      return Not(value);
    default:
      return Equal(value);
  }
};

const generateSort = (sort: string, order: string) => {
  if (!sort) return [];
  const sortables = sort.split(",");
  const sortableOrders = order.split(",") as Array<"asc" | "desc">;
  const obj = {};
  sortables.forEach((field: string, index: number) => {
    obj[field] = sortableOrders[index];
  });
  return obj;
};

const generateFilters = (filters: Record<string, any>) => {
  const obj = {};
  Object.keys(filters).forEach((key) => {
    const [field, operator = ""] = key.split("_");
    obj[field] = mapOperator(operator, filters[key]);
  });
  return obj;
};

const calculatePaginationInfo = (
  total: number,
  currentPage: number,
  perPage: number
) => {
  const lastPage = Math.ceil(total / perPage);
  return {
    currentPage,
    lastPage,
    total,
    limit: perPage,
    // hasNextPage: currentPage < lastPage,
    // hasPreviousPage: currentPage > 1,
  };
};

export const filterSortingList = async <EntitySchema>(
  model: Repository<EntitySchema>,
  query: Record<string, any>,
  keys?: IKey[]
) => {
  const {
    page = 1,
    perPage = 10,
    _order: order,
    _sort: sort,
    ...filters
  } = query;
  // filters
  const whereClauses = generateFilters(filters);

  const relations: Set<string> = new Set();

  if (keys && keys.length) {
    keys.forEach((k) => {
      if (k.key.includes(".")) {
        // Handle relations (e.g., "activity.user_id")
        const keysArray = k.key.split(".");
        const relation = keysArray.slice(0, -1).join("."); // Extract relation path
        const field = keysArray[keysArray.length - 1]; // Get final field name

        relations.add(relation); // Add relation dynamically

        (whereClauses as Record<string, any>)[relation] = {
          ...((whereClauses as Record<string, any>)[relation] || {}),
          [field]: k.value,
        };
      } else {
        // Normal filters
        (whereClauses as Record<string, any>)[k.key] = k.value;
      }
    });
  }
  //sorting
  const sorting = generateSort(sort, order);

  const total = await model.count({
    where: whereClauses as FindOptionsWhere<EntitySchema>,
    order: sorting as FindOptionsOrder<EntitySchema>,
    relations: [...relations]
  });
  const paginationInfo = calculatePaginationInfo(
    total,
    parseInt(page),
    parseInt(perPage)
  );

  const data = await model.find({
    take: perPage,
    skip: (page - 1) * perPage,
    where: whereClauses as FindOptionsWhere<EntitySchema>,
    order: sorting as FindOptionsOrder<EntitySchema>,
    relations: [...relations]
  });
  return {
    meta: { paginationInfo },
    data,
  };
};

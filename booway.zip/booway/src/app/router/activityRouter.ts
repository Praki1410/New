import express from "express";
import ActivityController from "../controllers/activites/activitycontroller";
import { checkVerifiedProvider } from "../middleware/checkVerified";
import {upload} from "../middleware/upload"; 

const router = express.Router();
const activityController = new ActivityController();


router.post(
  "/activity",
  upload.single("avatar"), 
  upload.single("bannerImage"), 
  upload.array("gallery", 10), 
  activityController.create
);


router.get("/activities", checkVerifiedProvider, activityController.getAll);
router.put("/activities/:id", checkVerifiedProvider, activityController.update);
router.delete("/activities/:id", checkVerifiedProvider, activityController.delete);

export default router;

import express from "express";
import ActivityController from "../controllers/activites/activitycontroller";
import { checkVerifiedProvider } from "../middleware/checkVerified";
import { checkJwt } from "@middleware/checkJwt";
const activityController = new ActivityController();
const router = express.Router();
router.use(checkJwt);
router.use(checkVerifiedProvider)



router.post("/activities-create", activityController.create);
router.get("/activities", activityController.getAll);
router.get("/activities/:id",activityController.getById)
router.put("/activities/:id",activityController.update)
router.delete("/activities/:id", activityController.delete);


export default router;

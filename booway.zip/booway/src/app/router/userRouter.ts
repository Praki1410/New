import UsersController from "@controllers/user/usersController";
import { checkUserRole } from "@middleware/checkUserRole";
import { Router } from "express";

const usersController = new UsersController();

const router = Router();
router.use(checkUserRole);

//only for user
router.get("/activities",checkUserRole, usersController.getAll); 

router.get("/", usersController.index);
router.get("/:id", usersController.show);
router.patch("/:id", usersController.update);
router.put("/:id", usersController.update);
router.delete("/:id", usersController.delete);

export default router;

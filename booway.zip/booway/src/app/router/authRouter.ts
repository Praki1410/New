import LoginController from "@controllers/auth/loginController";
import { Router } from "express";
import ChangePasswordController from "@controllers/auth/changePasswordController";
import { checkJwt } from "@middleware/checkJwt";
import ForgetPasswordController from "@controllers/auth/forgetPasswordController";
import ResetPasswordController from "@controllers/auth/resetPasswordController";
import RegisterController from "@controllers/auth/registerController";


const route = Router();

const registerController = new RegisterController();
const loginController = new LoginController();
const forgetPasswordController = new ForgetPasswordController();
const resetPasswordController = new ResetPasswordController();
const changePasswordController = new ChangePasswordController();

route.post("/register", registerController.index);
route.post("/login", loginController.index);
route.post("/forget-password", forgetPasswordController.forgetPassword);
route.post("/change-password", [checkJwt], changePasswordController.index);
route.post("/reset-password", resetPasswordController.resetPassword);
route.get("/logout", [checkJwt], loginController.logout);

export default route;

import { Router } from "express";
import fileUpload from "express-fileupload";
import auth from "@router/authRouter";
import user from "@router/userRouter";
import category from "@router/categoryRouter";
import activity from "@router/activityRouter";
import admin from "@router/adminRouter";

const route = Router();
route.use(fileUpload());


route.use("/auth", auth);
route.use("/users", user);
route.use("/categories", category);
route.use("/activity", activity);
route.use("/admin", admin);

export default route;

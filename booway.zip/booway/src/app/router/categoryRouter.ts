import CategoriesController from "@controllers/category/categoriesController";
import { checkJwt } from "@middleware/checkJwt";
import { checkVerifiedProvider } from "@middleware/checkVerified";
import { Router } from "express";

const categoriesController = new CategoriesController();

const router = Router();
router.use(checkJwt);
router.use(checkVerifiedProvider);
router.get("/", categoriesController.index);
router.get("/:id", categoriesController.show);
router.post("/", categoriesController.create);
router.patch("/:id", categoriesController.update);
router.put("/:id", categoriesController.update);
router.delete("/:id", categoriesController.delete);

export default router;

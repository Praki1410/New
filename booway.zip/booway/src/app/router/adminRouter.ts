import express from "express";
import UsersController from "@controllers/user/usersController";
import ActivityController from "@controllers/activites/activitycontroller";
import { checkAdmin } from "../middleware/checkAdmin";

const activityController=new ActivityController()
const usersController = new UsersController();
const router = express.Router();

//admin can check activities 
router.get("/admin-check-activities", checkAdmin, activityController.getAll);
router.get("/admin-check-activities/:id", checkAdmin,activityController.getById)

// Admin can verify activities
router.patch("/admin-activities-verify/:id", checkAdmin, usersController.verify);  

export default router;

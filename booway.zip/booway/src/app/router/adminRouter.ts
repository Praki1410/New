import express from "express";
import UsersController from "@controllers/user/usersController";
import ActivityController from "@controllers/activites/activitycontroller";
import { checkAdmin } from "../middleware/checkAdmin";
import { checkJwt } from "@middleware/checkJwt";

const activityController=new ActivityController()
const usersController = new UsersController();
const router = express.Router();
router.use(checkJwt)
router.use(checkAdmin)

//admin can check activities 
router.get("/admin-check-activities", activityController.getAll);
router.get("/admin-check-activities/:id",activityController.getById)

// Admin can verify activities
router.patch("/admin-activities-verify/:id", usersController.verify);  

export default router;

import * as yup from "yup";
import { emailPattern } from "@validators/user";
import { IRole } from "@models/user";

export const registerUserValidator = yup.object({
  firstName: yup.string().trim().required(),
  lastName: yup.string().trim().required(),
  email: yup.string().email().required().matches(emailPattern),
  password: yup.string().trim().required().min(6),
  role: yup
    .string()
    .trim()
    .oneOf([IRole.USER, IRole.PROVIDER])
    .default(IRole.USER),
  isVerified: yup.boolean().default(false),
});

export const loginValidator = yup.object({
  email: yup.string().email().required().matches(emailPattern),
  password: yup.string().trim().required().min(6),
});

export const changePasswordValidator = yup.object({
  oldPassword: yup.string().trim().required().min(6),
  newPassword: yup.string().trim().required().min(6),
});

export const forgetPasswordValidator = yup.object({
  email: yup.string().email().required().matches(emailPattern),
});

export const resetPasswordValidator = yup.object({
  token: yup.string().trim().required(),
  password: yup.string().trim().required().min(6),
});

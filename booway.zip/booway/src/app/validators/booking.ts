import * as yup from "yup";

// Define the validation schema
export const createValidator = yup.object({
  activity_id: yup
    .string()
    .uuid("Invalid activity ID format.")
    .required("Activity ID is required."),
  check_in_time: yup
    .string()
    .matches(
      /^\d{4}-\d{2}-\d{2}$/,
      "Check in date must be in YYYY-MM-DD format"
    )
    .required("Check In date is required"),
  amount: yup
    .number()
    .positive("Amount must be a positive number.")
    .required("Amount is required."),
});

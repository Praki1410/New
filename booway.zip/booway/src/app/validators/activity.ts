import { emailRegex } from "utils";
import * as yup from "yup";
import { parseDateString } from "@utils/date";
import { ActivityStatus, Language, ActivityLevel } from "../../enums/enum";
import {
    BadRequestException,
  } from "@helpers/ErrorHandler";

const baseValidator = {
    guide_name: yup.string().required("Guide name is required"),
    guide_description: yup.string().required("Guide description is required"),
    avatar: yup.string().optional(),
    banner_image: yup.string().optional(),
    gallery: yup.array().of(yup.string()).optional(),
    language: yup
        .array()
        .transform((value, originalValue) => typeof originalValue === "string" ? [originalValue] : originalValue)
        .of(yup.string().trim().required("Language cannot be empty"))
        .min(1, "At least one language is required")
        .required("At least one language is required")
        .default([]),
    categories: yup
        .array()
        .transform((value, originalValue) => typeof originalValue === "string" ? [originalValue] : originalValue)
        .min(1, "Activity type is required")
        .required("Activity type is required")
        .default([]),
        price: yup
        .number()
        .positive("Price must be a positive number")
        .required("Price is required"),
        description: yup
        .string()
        .required("Description is required"),
        duration_of_activity: yup
        .string()
        .required("Duration of activity is required"),
        level_of_activity: yup
        .string()
        .oneOf(Object.values(ActivityLevel), "Invalid activity level")
        .required("Level of activity is required"),
        status: yup
        .string()
        .oneOf(Object.values(ActivityStatus), "Invalid status")
        .optional(), 
    max_people: yup.number().integer().positive("Must be a positive integer").required("Max people is required"),
    min_people: yup.number().integer().positive("Must be a positive integer").required("Min people is required"),
    activity_include: yup.string().required("Activity include is required"),
    activity_exclude: yup.string().required("Activity exclude is required"),
    activity_highlight: yup.string().required("Activity highlight is required"),
    youtube_url: yup.string().url("Invalid YouTube URL").nullable(),
    booking_period_start: yup
        .string()
        .matches(/^\d{4}-\d{2}-\d{2}$/, "Booking period start must be in YYYY-MM-DD format")
        .required("Booking period start is required"),
    booking_period_end: yup
        .string()
        .matches(/^\d{4}-\d{2}-\d{2}$/, "Booking period end must be in YYYY-MM-DD format")
        .required("Booking period end is required")
        .test("is-after-start", "End date must be after start date", function (value) {
            return parseDateString(value) > parseDateString(this.parent.booking_period_start);
        }),
    cancel_booking_deadline: yup
        .string()
        .matches(/^\d{4}-\d{2}-\d{2}$/, "Cancel booking deadline must be in YYYY-MM-DD format")
        .required("Cancel booking deadline is required")
        .test("is-before-end", "Cancel booking deadline must be before end date", function (value) {
            return parseDateString(value) <= parseDateString(this.parent.booking_period_end);
        }),
    availability: yup
        .array()
        .transform((value, originalValue) => typeof originalValue === "string" ? [originalValue] : originalValue)
        .of(
            yup.string()
                .matches(/^\d{4}-\d{2}-\d{2}$/, "Availability dates must be in YYYY-MM-DD format")
                .test("is-within-range", "Availability must be within start and end date", function (value, context) {
                    const { booking_period_start, booking_period_end } = context.from[0]?.value || {};

                    return parseDateString(value) >= parseDateString(booking_period_start) &&
                        parseDateString(value) <= parseDateString(booking_period_end);
                })
        )
        .default([]),
    real_address: yup.string().required("Real address is required"),
    map_latitude: yup.number().required("Map latitude is required"),
    map_longitude: yup.number().required("Map longitude is required"),
    website: yup.string().url("Invalid website URL").optional(),
    email: yup.string().matches(emailRegex, "Invalid email format").required("Email is required"),
    phone: yup.string().required("Phone is required"),
};


export const createValidator = yup.object(baseValidator);
export const updateValidator = yup.object({
    ...baseValidator,
});

export const AdminupdateValidator = yup.object({
    status: yup
        .string()
        .oneOf(Object.values(ActivityStatus), "Invalid status")
        .required("Status is required"),
});

export const validateFile = (fileList: any, type: string = "file") => {
    const allowedExtensions = ["jpeg", "jpg", "png"];

    const files = Array.isArray(fileList) ? fileList : [fileList];

    if (
        files.some((file) => {
            const fileExtension = file.name.split(".").pop()?.toLowerCase();
            return !fileExtension || !allowedExtensions.includes(fileExtension);
        })
    ) {
        throw new BadRequestException(`Invalid ${type} file type. Allowed formats: jpeg, jpg, png.`);
    }

    return files;
};

export const deleteValidator = yup.object({
    id: yup.string().required("Activity ID is required"),
  });
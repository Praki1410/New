import { emailRegex } from "utils";
import * as yup from "yup";
import { ActivityModel } from "../models/activity";
import { parseDateString } from "@utils/date";

export const createValidator = yup.object({
    name: yup.string().required("Name is required"),
    price: yup.number().positive("Price must be a positive number").required("Price is required"),
    description: yup.string().required("Description is required"),
    website: yup.string().url("Invalid website URL").required("Website is required"),
    email: yup.string().matches(emailRegex, "Invalid email format").required("Email is required"),
    phone: yup.string().required("Phone is required"),
    language: yup
        .array()
        .transform((value, originalValue) =>
            typeof originalValue === "string" ? [originalValue] : originalValue
        )
        .of(yup.string().trim().required("Language cannot be empty"))
        .min(1, "At least one language is required")
        .required("At least one language is required")
        .default([]),
    categories: yup
        .array()
        .transform((value, originalValue) =>
            typeof originalValue === "string" ? [originalValue] : originalValue
        )
        .of(yup.string().uuid("Invalid category ID"))
        .min(1, "Activity type is required")
        .required("Activity type is required")
        .default([]),
    maxPeople: yup.number().integer().positive("Must be a positive integer").required("Max people is required"),
    activityInclude: yup.string().required("Activity include is required"),
    activityExclude: yup.string().required("Activity exclude is required"),
    activityHighlight: yup.string().required("Activity highlight is required"),
    youtubeUrl: yup.string().url("Invalid YouTube URL").nullable(),
    bookingStartDate: yup
        .string()
        .matches(/^\d{4}-\d{2}-\d{2}$/, "Booking start date must be in YYYY-MM-DD format")
        .required("Booking start date is required"),

    bookingEndDate: yup
        .string()
        .matches(/^\d{4}-\d{2}-\d{2}$/, "Booking end date must be in YYYY-MM-DD format")
        .required("Booking end date is required")
        .test("is-after-start", "End date must be after start date", function (value) {
            return parseDateString(value) > parseDateString(this.parent.bookingStartDate);
        }),

    cancelBookingDate: yup
        .string()
        .matches(/^\d{4}-\d{2}-\d{2}$/, "Cancel booking date must be in YYYY-MM-DD format")
        .required("Cancel booking date is required")
        .test("is-before-end", "Cancel booking date must be before end date", function (value) {
            return parseDateString(value) <= parseDateString(this.parent.bookingEndDate);
        }),
    availability: yup
        .array()
        .transform((value, originalValue) => (typeof originalValue === "string" ? [originalValue] : originalValue))
        .of(
            yup
                .string()
                .matches(/^\d{4}-\d{2}-\d{2}$/, "Availability dates must be in YYYY-MM-DD format")
                .test("is-within-range", "Availability must be within start and end date", function (value, context) {
                    const { bookingStartDate, bookingEndDate } = context.from[0].value;

                    return parseDateString(value) >= parseDateString(bookingStartDate) &&
                        parseDateString(value) <= parseDateString(bookingEndDate);
                })
        )
        .default([])
        .min(0),
    location: yup.string().required("Location is required"),
});

export const updateValidator = createValidator.shape({
    status: yup
      .string()
      .oneOf(Object.values(ActivityModel), "Invalid status")
      .required("Status is required"),
  });
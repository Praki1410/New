import * as yup from "yup";

export const createOrUpdateValidator = yup.object({
  name: yup.string().trim().required(),
});

import * as yup from "yup";
import bcrypt from "bcryptjs";

export const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

export const updateUserValidator = yup.object({
  firstName: yup.string().trim().optional(),
  lastName: yup.string().trim().optional(),
  isVerified: yup.boolean(),
});

export const validateFile = (file) => {
  const allowedExtensions = ["jpeg", "jpg", "png"];
  const parts = file.name.split(".");

  return allowedExtensions.includes(parts[parts.length - 1]);
};

export const hashPassword = (password: string) => {
  return bcrypt.hashSync(password, 8);
};

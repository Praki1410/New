import { IRole, User } from "@models/user";
import { ActivityModel } from "@models/activity";
import { ActivityStatus } from "../../../enums/enum";
import AppDataSource from "@database";
import {
  AuthorizationException,
  InvalidFileException,
  NotFoundException,
  ServerException,
} from "@helpers/ErrorHandler";
import { updateUserValidator, validateFile, } from "@validators/user";
import {AdminupdateValidator} from "@validators/activity"
import Storage from "@utils/storage";
import { NextFunction, Request, Response } from "express";
import { filterSortingList } from "@utils/filterSortingList";
import { deniedPermission, permissions } from "@utils/permission";

export default class UsersController {
  /**
   * Admin and Provider Only
   * Get User/provider list
   * @route GET /users
   * @query page, perPage
   * implement pagination, sorting and filter on all fields except avatar, created and updated
   */
  async index(req: Request, res: Response, next: NextFunction) {
    try {
      if (deniedPermission(req.user.role, permissions.users.list)) {
        const err = new AuthorizationException();
        return next(err);
      }
      if (!Object.keys(req.query).includes("role"))
        req.query.role_not = IRole.ADMIN;
      const userRepository = AppDataSource.getRepository(User);
      const data = await filterSortingList(userRepository, req.query);
      return res.send({ data });
    } catch (e) {
      return next(e);
    }
  }


  /**
   * Get All Activities only for Users only Active activities can be get
   * @route GET /activities
   */

  async getAll(req: Request, res: Response, next: NextFunction) {
    try {
      const activityRepository = AppDataSource.getRepository(ActivityModel);
      let activities;
  
      if (req.user.role === IRole.USER) {
        activities = await activityRepository.find({
          where: { status: ActivityStatus.ACTIVE },
          relations: ["categories"],
        });
      } else {
        activities = await activityRepository.find({ relations: ["categories"] });
      }
  
      return res.status(200).json({ data: activities });
    } catch (e) {
      return next(new ServerException(e.message));
    }
  }



  

  /**
   * Get logged user detail OR
   * If the logged-in user is an admin and provides an ID in the parameters, they can access other users' profiles.
   * @route GET /users/:id
   *
   */
  async show(req: Request, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;
      const userId =
        id === "me" || [IRole.USER, IRole.PROVIDER].includes(req.user!.role)
          ? req.user!.id
          : id;
      const userRepository = AppDataSource.getRepository(User);
      const data = await userRepository.findOne({
        where: { id: userId },
      });
      if (!data) {
        const err = new NotFoundException("User");
        return next(err);
      }
      return res.send({ data });
    } catch (e) {
      return next(e);
    }
  }

  /**
   * Update logged user profile OR
   * If the logged-in user is an admin and provides an ID in the parameters, they can modify other users' profiles.
   * @route PATCH /users/:id
   * @route PUT /users/:id
   * @param req.body - Request payload
   * lastName, firstName, avatar("jpeg", "jpg", "png" files), isVerified (only admin can modify it)
   *
   */
  async update(req: Request, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;
      const userId =
        id === "me" || [IRole.USER, IRole.PROVIDER].includes(req.user!.role)
          ? req.user!.id
          : id;
      const user = await updateUserValidator.validate(req.body, {
        stripUnknown: true,
      });
      const file = req.files;
      const userRepository = AppDataSource.getRepository(User);
      const existUser = await userRepository.findOne({
        where: { id: userId },
      });
      if (!existUser) {
        const err = new NotFoundException("User");
        return next(err);
      }
      if (file && file.avatar) {
        if (!validateFile(file.avatar)) {
          const err = new InvalidFileException();
          return next(err);
        }
        const storage = new Storage();
        if (existUser.avatar)
          await storage.delete(existUser.avatar.split("uploads")[1]);
        const name = await storage.store(file.avatar, "avatars");
        (user as User).avatar = name?.path || "";
      }
      if ([IRole.USER, IRole.PROVIDER].includes(req.user!.role))
        delete user.isVerified;
      await AppDataSource.getRepository(User).update(
        { id: userId },
        { ...user }
      );
      const data = await userRepository.findOne({
        where: { id: userId },
      });
      return res.send({ data });
    } catch (e) {
      return next(e);
    }
  }

  /**
   * Admin Only
   * Delete User/provider
   * @route DELETE /users/:id
   *
   */
  async delete(req: Request, res: Response, next: NextFunction) {
    try {
      if (deniedPermission(req.user.role, permissions.users.delete)) {
        const err = new AuthorizationException();
        return next(err);
      }
      const { id } = req.params;
      const userRepository = AppDataSource.getRepository(User);
      const data = await userRepository.delete(id);
      return res.send({ data: Boolean(data.affected) });
    } catch (e) {
      return next(e);
    }
  }

    /**
   * Verify Activity only for admin
   * @route PATCH /activities/:id/verify
   */

  async verify(req: Request, res: Response, next: NextFunction) {
    try {

      if (deniedPermission(req.user.role, permissions.activity.verify)) {
        return next(new AuthorizationException("You do not have permission to verify this activity."));
    }
        const { id } = req.params;
        const status = req.body.status?.trim();

      //  const adminValidation = await AdminupdateValidator.validate(req.body, { abortEarly: false });
        const activityRepository = AppDataSource.getRepository(ActivityModel);
        const activity = await activityRepository.findOne({ where: { id } });

        if (!activity) {
            return next(new NotFoundException("Activity not found."));
        }

        activity.status = status as ActivityStatus
        const data = await activityRepository.save(activity);

        return res.status(200).json({ data });
    } catch (e) {
        if (e.name === "ValidationError") {
            return next(new ServerException(e.errors.join(", ")));
        }
        return next(new ServerException(e.message));
    }
}


}

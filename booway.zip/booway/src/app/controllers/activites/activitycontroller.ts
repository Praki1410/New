import { Request, Response, NextFunction } from "express";
import AppDataSource from "@database";
import { ActivityModel } from "@models/activity";
import { ActivityStatus } from "../../../enums/enum";
import { Categories } from "@models/category";
import {IRole} from "../../../enums/enum"



import {
  NotFoundException,
  BadRequestException,
  ServerException,
} from "@helpers/ErrorHandler";

export default class ActivityController {

  /**
   * Get All Activities for only provider/admin
   * @route GET /activities
   */
  async getAll(req: Request, res: Response, next: NextFunction) {
    try {
      const activityRepository = AppDataSource.getRepository(ActivityModel);
      const activities = await activityRepository.find({ relations: ["categories"] });
      return res.status(200).json({ data: activities });
    } catch (e) {
      return next(new ServerException(e.message));
    }
  }

    /**
   * Get All Activities for only provider/admin
   * @route GET /activities/:id
   */

  async getById(req: Request, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;
      const activityRepository = AppDataSource.getRepository(ActivityModel);
  
      const activity = await activityRepository.findOne({
        where: { id },
        relations: ["categories"],
      });
  
      if (!activity) {
        return next(new NotFoundException("Activity not found."));
      }
  
      return res.status(200).json({ data: activity });
    } catch (e) {
      return next(new ServerException(e.message));
    }}


  /**
   * Create Activity
   * @route POST /activities
   */
  // async create(req: Request, res: Response, next: NextFunction) {
  //   try {
  //     let { categories, ...activityData } = req.body;
  //     const activityRepository = AppDataSource.getRepository(ActivityModel);
  //     const categoryRepository = AppDataSource.getRepository(Categories);

  //     categories = Array.isArray(categories) ? categories : [categories].filter(Boolean);

  //     if (categories.length === 0) {
  //       return next(new BadRequestException("At least one valid category is required."));
  //     }

  //     const existingCategories = await categoryRepository
  //       .createQueryBuilder("category")
  //       .where("category.name IN (:...names)", { names: categories })
  //       .getMany();

  //     if (existingCategories.length !== categories.length) {
  //       return next(new BadRequestException("One or more categories do not exist."));
  //     }

  //     const activity = activityRepository.create({
  //       ...activityData,
  //       categories: existingCategories,
  //       status: ActivityStatus.PENDING,
  //       isActive: true,
  //     });

  //     const data = await activityRepository.save(activity);
  //     return res.status(201).json({ data });
  //   } catch (e) {
  //     return next(new ServerException(e.message));
  //   }
  // }





// async create(req: Request, res: Response, next: NextFunction) {
//   try {
//     let { categories, ...activityData } = req.body;
//     const activityRepository = AppDataSource.getRepository(ActivityModel);
//     const categoryRepository = AppDataSource.getRepository(Categories);

//     // Ensure categories is always an array
//     categories = Array.isArray(categories)
//       ? categories
//       : [categories].filter(Boolean);

//     if (categories.length === 0) {
//       return next(new BadRequestException("At least one valid category is required."));
//     }

//     // Validate if categories exist in DB
//     const existingCategories = await categoryRepository
//       .createQueryBuilder("category")
//       .where("category.name IN (:...names)", { names: categories })
//       .getMany();

//     if (existingCategories.length !== categories.length) {
//       return next(new BadRequestException("One or more categories do not exist."));
//     }

//     // 🔹 File Upload Handling 🔹
//     const storage = new Storage();
//     let imageFilenames: string[] = [];

//     if (req.files && req.files.avatar) {
//       if (Array.isArray(req.files.avatar)) {
//         const fileResults = await storage.storeMultiple(req.files.avatar, "activities");
//         imageFilenames = fileResults.map((file) => file.path);
//       } else {
//         const fileInfo = await storage.store(req.files.avatar, "activities");
//         if (fileInfo) imageFilenames.push(fileInfo.path);
//       }
//     } else {
//       return next(new BadRequestException("No file uploaded."));
//     }

//     // 🔹 Create the Activity 🔹
//     const activity = activityRepository.create({
//       ...activityData,
//       avatars: imageFilenames, // Make sure DB has this column
//       categories: existingCategories,
//       status: ActivityStatus.PENDING, // Assuming this is defined somewhere
//       isActive: true,
//     });

//     const data = await activityRepository.save(activity);
//     return res.status(201).json({ data });
//   } catch (e) {
//     console.error("Upload Error:", e);
//     return next(new ServerException(e.message));
//   }
// }



// async create(req: Request, res: Response, next: NextFunction) {
//   try {
//     // Destructure data from form
//     let { categories, ...activityData } = req.body;

//     // Handle file uploads
//     const storage = new Storage();
//     const gallery = req.files ? req.files['gallery[]'] : null;

//     // If files are present, store them
//     let galleryUrls = [];
//     if (gallery) {
//       const galleryFiles = Array.isArray(gallery) ? gallery : [gallery]; // In case it's a single file
//       const uploadedFiles = await storage.storeMultiple(galleryFiles, 'activities');
//       galleryUrls = uploadedFiles.map(file => storage.get(file.path));
//     }

//     const activityRepository = AppDataSource.getRepository(ActivityModel);
//     const categoryRepository = AppDataSource.getRepository(Categories);

//     // Ensure categories is an array
//     categories = Array.isArray(categories) ? categories : [categories].filter(Boolean);

//     if (categories.length === 0) {
//       return next(new BadRequestException("At least one valid category is required."));
//     }

//     // Convert categories to lowercase for comparison
//     const lowerCaseCategories = categories.map(category => category.toLowerCase());

//     // Query existing categories
//     const existingCategories = await categoryRepository
//       .createQueryBuilder("category")
//       .where("LOWER(category.name) IN (:...names)", { names: lowerCaseCategories })
//       .getMany();

//     if (existingCategories.length !== categories.length) {
//       return next(new BadRequestException("One or more categories do not exist."));
//     }

//     // Now, create the activity
//     const activity = activityRepository.create({
//       ...activityData,
//       categories: existingCategories,
//       gallery: galleryUrls, // Add the gallery URLs to the activity
//       status: 'PENDING',
//       isActive: true,
//     });

//     // Save activity to the database
//     const data = await activityRepository.save(activity);

//     return res.status(201).json({ data });
//   } catch (e) {
//     return next(new ServerException(e.message));
//   }
// }


async create(req: Request, res: Response, next: NextFunction) {
  try {
    let { categories, gallery, ...activityData } = req.body; 

    const activityRepository = AppDataSource.getRepository(ActivityModel);
    const categoryRepository = AppDataSource.getRepository(Categories);

    // Ensure categories is an array
    categories = Array.isArray(categories) ? categories : [categories].filter(Boolean);

    if (categories.length === 0) {
      return next(new BadRequestException("At least one valid category is required."));
    }

    // Query the existing categories from the database
    const existingCategories = await categoryRepository
      .createQueryBuilder("category")
      .where("category.name IN (:...names)", { names: categories })
      .getMany();

    // Ensure all categories exist in the database
    if (existingCategories.length !== categories.length) {
      return next(new BadRequestException("One or more categories do not exist."));
    }

    // Create the new activity, including the uploaded gallery images
    const activity = activityRepository.create({
      ...activityData,
      categories: existingCategories,
      gallery,  // Save gallery image paths
      status: ActivityStatus.PENDING,
      isActive: true,
    });

    // Save the activity to the database
    const data = await activityRepository.save(activity);

    // Respond with the created activity data
    return res.status(201).json({ data });
  } catch (e) {
    return next(new ServerException(e.message));
  }
}


  /**
   * Update Activity
   * @route PATCH /activities/:id
   */
  async update(req: Request, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;
      let { categories, status, ...activityData } = req.body;
  
      const activityRepository = AppDataSource.getRepository(ActivityModel);
      const activity = await activityRepository.findOne({
        where: { id },
        relations: ["categories"],
      });
      if (!activity) {
        return next(new NotFoundException("Activity"));
      }
      if (req.user.role === IRole.PROVIDER) {
        delete activityData.categories;
        delete activityData.status;
      }
      Object.assign(activity, activityData);
      if (status && req.user.role !== IRole.PROVIDER) {
        activity.status = status;
      }
      const data = await activityRepository.save(activity);
      return res.status(200).json({ data });
    } catch (e) {
      return next(new ServerException(e.message));
    }
  }
  


  /**
   * Delete Activity
   * @route DELETE /activities/:id
   */
  async delete(req: Request, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;
      const activityRepository = AppDataSource.getRepository(ActivityModel);
      const activity = await activityRepository.findOne({ where: { id } });

      if (!activity) {
        return next(new NotFoundException("Activity"));
      }

      await activityRepository.remove(activity);
      return res.status(200).json({ message: "Activity deleted successfully." });
    } catch (e) {
      return next(new ServerException(e.message));
    }
  }

  /**
   * Verify Activity
   * @route PATCH /activities/:id/verify
   */


  async verify(req: Request, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;
      const { status } = req.body;

      const activityRepository = AppDataSource.getRepository(ActivityModel);
  

      const activity = await activityRepository.findOne({ where: { id } });
  
      if (!activity) {
        return next(new NotFoundException("Activity"));
      }
      if (req.user.role === IRole.ADMIN) {
        if (!status || (status !== ActivityStatus.ACTIVE && status !== ActivityStatus.PENDING)) {
          return next(new BadRequestException("Invalid status for admin. Status must be ACTIVE or PENDING."));
        }
        activity.status = status; 
      } else {

        activity.status = ActivityStatus.VERIFIED;
      }
  

      const data = await activityRepository.save({ id: activity.id, status: activity.status });
      return res.status(200).json({ data });
    } catch (e) {
      return next(new ServerException(e.message));
    }
  }
  
  
}

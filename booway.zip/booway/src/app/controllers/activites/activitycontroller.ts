import { Request, Response, NextFunction } from "express";
import AppDataSource from "@database";
import { ActivityModel } from "@models/activity";
import { ActivityStatus } from "../../../enums/enum";
import { Categories } from "@models/category";
import { IRole } from "../../../enums/enum";
import Storage from "@utils/storage";
import {
  NotFoundException,
  ServerException,
  AuthorizationException,
  BadRequestException,
} from "@helpers/ErrorHandler";
import { deniedPermission, permissions } from "@utils/permission";
import {
  createValidator,
  updateValidator,
  deleteValidator,
  validateFile,
} from "@validators/activity";

export default class ActivityController {
  /**
   * Get All Activities for only provider
   * @route GET /activities
   */

  async getAll(req: Request, res: Response, next: NextFunction) {
    try {
      if (![IRole.PROVIDER, IRole.ADMIN].includes(req.user.role)) {
        return next(
          new AuthorizationException("You do not have permission to access activities.")
        );
      }
  
      const Role = req.user.role === IRole.PROVIDER 
        ? { created_by: req.user.id } 
        : {};
  
      const activityRepository = AppDataSource.getRepository(ActivityModel);
      const activities = await activityRepository.find({
        where: Role,
        relations: ["categories"],
      });
  
      if (!activities.length) {
        return res.status(404).json({
          message: req.user.role === IRole.PROVIDER 
            ? "No activities found. Please create your data." 
            : "No activities found.",
        });
      }
  
      return res.send({ activities });
    } catch (e) {
      return next(e);
    }
  }
  
  
  /**
   * Get All Activities for only provider/admin can view all Activites
   * @route GET /activities/:id
   */
  
  async getById(req: Request, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;
      const activityRepository = AppDataSource.getRepository(ActivityModel);
      
     const Role: any = { id };
  
      if (req.user.role === IRole.PROVIDER) {
        Role.created_by = req.user.id;
      }
  
      const activity = await activityRepository.findOne({
        where: Role,
        relations: ["categories"],
      });
  
      if (!activity) {
        return next(new NotFoundException("Activity not found."));
      }
  
      return res.send({ activity });
    } catch (e) {
      return next(e);
    }
  }
  

  /**
    Create Activity Only for Provider
   * @route POST /activitie
   */

    async create(req: Request, res: Response, next: NextFunction) {
      try {
        if (req.user.role !== IRole.PROVIDER) {
          return next(new AuthorizationException("Only providers can create activities."));
        }
    
        const createValidatedData = await createValidator.validate(req.body, { stripUnknown: true });
    
        const file = req.files;
        const storage = new Storage();
    
        const uploadFile = async (file: any, type: string, folder: string) => {
          return file ? (await storage.store(validateFile(file, type)[0], folder))?.path : null;
        };
    
        const [galleryUrls, avatarUrl, bannerImageUrl] = await Promise.all([
          file?.gallery
            ? storage.handleMultipleFileUpload(validateFile(file.gallery, "gallery"), "gallery")
            : [],
          uploadFile(file?.avatar, "avatar", "avatars"),
          uploadFile(file?.banner_image, "banner", "banners"),
        ]);
    
        const { categories, ...activityData } = createValidatedData;
        const categoryNames = String(categories || "")
          .split(",")
          .map((name) => name.trim())
          .filter(Boolean);
    
        const categoryRepository = AppDataSource.getRepository(Categories);
        const existingCategories = await categoryRepository
          .createQueryBuilder("category")
          .where("category.name IN (:...names)", { names: categoryNames })
          .getMany();
    
        if (!existingCategories.length) {
          return next(new NotFoundException("No valid categories found."));
        }
    
        const activityRepository = AppDataSource.getRepository(ActivityModel);
        const activity = new ActivityModel();
    
        Object.assign(activity, {
          ...activityData,
          status: ActivityStatus.PENDING,
          created_by: req.user.id,
          gallery: galleryUrls,
          avatar: avatarUrl,
          banner_image: bannerImageUrl,
        });
    
        activity.categories = existingCategories;
        activity.main_category = existingCategories[0] || null;
    
        const data = await activityRepository.save(activity);
        return res.status(201).json({ data });
      } catch (e) {
        console.error("Validation Errors:", e.errors || e.message);
        return next(new ServerException(e.message));
      }
    }
    
    

  /**Only for Provider
   *
   * Update Activity
   * @route PATCH /activities/:id
   */

  async update(req: Request, res: Response, next: NextFunction) {
    try {
      if (req.user.role !== IRole.PROVIDER) {
        return next(
          new AuthorizationException("Only Provider can update activities.")
        );
      }

    const updateValidated= await updateValidator.validate(req.body, { abortEarly: false });

      const { id } = req.params;
      const { categories, status, ...activityData } = updateValidated
      const file = req.files;

      const activityRepository = AppDataSource.getRepository(ActivityModel);
      const categoryRepository = AppDataSource.getRepository(Categories);

      const existingActivity = await activityRepository.findOne({
        where: { id, created_by: req.user.id },
      });

      if (!existingActivity) {
        return next(new NotFoundException("Activity not found."));
      }

      const storage = new Storage();

      if (file?.avatar && existingActivity.avatar) {
        await storage.delete(existingActivity.avatar);
      }
      if (file?.banner_image && existingActivity.banner_image) {
        await storage.delete(existingActivity.banner_image);
      }
      if (file?.gallery && existingActivity.gallery.length) {
        await Promise.all(
          existingActivity.gallery.map((img) => storage.delete(img))
        );
      }

      const [galleryUrls, avatarUrl, bannerImageUrl] = await Promise.all([
        file?.gallery
          ? storage.handleMultipleFileUpload(
              Array.isArray(file.gallery) ? file.gallery : [file.gallery],
              "gallery"
            )
          : [],
        file?.avatar
          ? (await storage.store(file.avatar, "avatars"))?.path
          : null,
        file?.banner_image
          ? (await storage.store(file.banner_image, "banners"))?.path
          : null,
      ]);

      existingActivity.gallery = galleryUrls.length
        ? galleryUrls
        : existingActivity.gallery;
      existingActivity.avatar = avatarUrl || existingActivity.avatar;
      existingActivity.banner_image =
       bannerImageUrl || existingActivity.banner_image;

      const categoryNames = [].concat(categories || []).map((name) => name.trim());
      const existingCategories = await categoryRepository
        .createQueryBuilder("category")
        .where("category.name IN (:...names)", { names: categoryNames })
        .getMany();

      if (!existingCategories.length) {
        return next(new NotFoundException("No valid categories found."));
      }

      existingActivity.categories = existingCategories;
      const primaryCategory = existingCategories[0]?.id || null;
      existingActivity.main_category = primaryCategory
        ? await categoryRepository.findOne({ where: { id: primaryCategory } })
        : null;

      Object.assign(existingActivity, activityData);

      await activityRepository.save(existingActivity);

      const updatedActivity = await activityRepository.findOne({
        where: { id },
        relations: ["categories"],
      });

      return res.send({ updatedActivity });
    } catch (e) {
      console.error("Update Error:", e.errors || e.message);
      return next(new ServerException(e.message));
    }
  }

  /** Only for Provider
   * Delete Activity
   * @route DELETE /activities/:id
   */

  async delete(req: Request, res: Response, next: NextFunction) {
    try {
      if (deniedPermission(req.user.role, permissions.activity.delete)) {
        return next(
          new AuthorizationException(
            "You do not have permission to delete this activity."
          )
        );
      }
  
      const { id } = await deleteValidator.validate(req.params, {
        abortEarly: false,
      });
  
      const activityRepository = AppDataSource.getRepository(ActivityModel);
      const activity = await activityRepository.findOne({
        where: { id, created_by: req.user.id },
      });
      if (!activity) {
        return next(new NotFoundException("Activity not found."));
      }

      const storage = new Storage();

      await Promise.all([
        activity.avatar && storage.delete(activity.avatar),
        activity.banner_image && storage.delete(activity.banner_image),
        ...activity.gallery.map((img) => storage.delete(img)),
      ]);
      await activityRepository.remove(activity);
      return res
        .status(200)
        .json({ message: "Activity deleted successfully." });
    } catch (e) {
      if (e.errors) {
        return next(new BadRequestException(e.errors)); 
      }
      console.error("Delete Error:", e.errors || e.message);
      return next(new ServerException(e.message));
    }
  }
  
}

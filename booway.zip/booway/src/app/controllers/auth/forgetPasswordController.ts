import config from "@config";
import AppDataSource from "@database";
import { PasswordReset } from "@models/passwordReset";
import { User } from "@models/user";
import Mail from "@utils/mail";
import Token from "@utils/token";
import { forgetPasswordValidator } from "@validators/auth";
import { NextFunction, Request, Response } from "express";
import path from "node:path";

export default class ForgetPasswordController {
  /**
   * Forget password  with send mail and reset password link
   *
   * @route POST /auth/forget-password
   * @param req.body - Request payload
   * email - required
   *
   */
  async forgetPassword(req: Request, res: Response, next: NextFunction) {
    try {
      const { email } = await forgetPasswordValidator.validate(req.body);

      const userRepository = AppDataSource.getRepository(User);
      const {
        firstName = "",
        lastName = "",
        email: userEmail,
      } = await userRepository.findOneOrFail({
        where: { email },
      });
      const token = new Token();
      const { uniqueStr, token: uniqueToken } = await token.create(userEmail);
      await AppDataSource.getRepository(PasswordReset).upsert(
        { email, token: uniqueToken },
        ["email"]
      );
      const templatePath = path.resolve(__dirname, "..", "..", "..");
      const mail = new Mail();
      await mail.send({
        email,
        subject: "Reset password",
        template: path.join(templatePath, `template/password-reset.html`),
        data: {
          appUrl: config.baseUrl,
          uniqueStr,
          firstName,
          lastName,
          supportMail: config.mail.from,
          companyName: config.companyName,
          hours: (config.expiresInMinutes / 60).toString(),
          baseUrl: config.baseUrl,
        },
      });
      return res.send({ data: true });
    } catch (error) {
      return next(error);
    }
  }
}

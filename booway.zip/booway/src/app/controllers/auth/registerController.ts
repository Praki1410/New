import AppDataSource from "@database";
import { User,IRole } from "@models/user";
import { registerUserValidator } from "@validators/auth";
import { NextFunction, Request, Response } from "express";
import { hashPassword } from "@validators/user";
import path from "node:path";
import Mail from "@utils/mail";
import config from "@config";

export default class RegisterController {
  /**
   * Register a new user and provider
   *
   * @route POST /auth/register
   * @param req.body - Request payload
   * email, firstName, lastName, password, role(USER,PROVIDER)
   * All that params are required
   * Role default value is USER
   * Send email to the admin for verified provider is role value is provider
   *
   */
  async index(req: Request, res: Response, next: NextFunction) {
    try {
      const user = await registerUserValidator.validate(req.body, {
        stripUnknown: true,
      });

      const userRepository = AppDataSource.getRepository(User);
      const data = await userRepository.save({
        ...user,
        password: hashPassword(user.password),
      });
      const templatePath = path.resolve(__dirname, "..", "..", "..");
      const { email, firstName = "", lastName = "" } = data;
      const mail = new Mail();
      await mail.send({
        email,
        subject: "Register Provider",
        template: path.join(templatePath, `template/register-provider.html`),
        data: {
          appUrl: config.baseUrl,
          email,
          firstName,
          lastName,
          baseUrl: config.baseUrl,
        },
      });
      delete data.password;
      return res.send({ data });
    } catch (error) {
      return next(error);
    }
  }
}

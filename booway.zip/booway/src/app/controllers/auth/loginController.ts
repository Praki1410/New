import AppDataSource from "@database";
import { NotMatchException, ServerException } from "@helpers/ErrorHandler";
import { Sessions } from "@models/session";
import { User } from "@models/user";
import { IJwtPayload } from "app/types/jwtPayload";
import JWTToken from "@utils/createJwtToken";
import { loginValidator } from "@validators/auth";
import { NextFunction, Request, Response } from "express";

export default class LoginController {
  /**
   * Login user, provider and admin with create sessions
   *
   * @route POST /auth/login
   * @param req.body - Request payload
   * email, password
   * All that params are required
   *
   */
  async index(req: Request, res: Response, next: NextFunction) {
    try {
      const { email, password } = await loginValidator.validate(req.body);

      const userRepository = AppDataSource.getRepository(User);
      const data = await userRepository.findOneOrFail({
        where: { email },
        select: [
          "password",
          "id",
          "firstName",
          "lastName",
          "email",
          "role",
          "isVerified",
        ],
      });

      if (!data.checkIfPasswordMatch(password)) {
        const err = new NotMatchException("password");
        return next(err);
      }

      try {
        const sessionRepository = AppDataSource.getRepository(Sessions);
        const updatedData = await sessionRepository.upsert(
          { userId: data.id },
          ["userId"]
        );
        const jwtPayload: IJwtPayload = {
          userId: data.id,
          email: data.email,
          sessionId: updatedData.identifiers[0].id,
        };
        const jwtToken = new JWTToken();
        const token = await jwtToken.create(jwtPayload);
        delete data.password;
        return res.send({ data: { type: "bearer", accessToken: token, data } });
      } catch (e) {
        const err = new ServerException(e.message);
        return next(err);
      }
    } catch (error) {
      return next(error);
    }
  }

   /**
   * Logout the user with remove session
   *
   * @route GET /auth/logout
   *
   */
  async logout(req: Request, res: Response, next: NextFunction) {
    const sessionRepository = AppDataSource.getRepository(Sessions);
    await sessionRepository.delete({ userId: req.user.id });
    return res.send({ data: true });
  }
}

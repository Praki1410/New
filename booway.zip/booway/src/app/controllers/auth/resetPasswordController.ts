import config from "@config";
import AppDataSource from "@database";
import { ExpiredException } from "@helpers/ErrorHandler";
import { PasswordReset } from "@models/passwordReset";
import { User } from "@models/user";
import Token from "@utils/token";
import { resetPasswordValidator } from "@validators/auth";
import { hashPassword } from "@validators/user";
import { NextFunction, Request, Response } from "express";

export default class ResetPasswordController {
  /**
   * Reset password
   *
   * @route POST /auh/reset-password
   * @param req.body - Request payload
   * token - required - extract mail from this token for identifying who reset password, this token only valid for 2 hours
   * password - required
   *
   */
  async resetPassword(req: Request, res: Response, next: NextFunction) {
    try {
      const { token: uniqueToken, password } =
        await resetPasswordValidator.validate(req.body);

      const email = Buffer.from(uniqueToken, "base64")
        .toString("utf-8")
        .split("|")[1];

      const passwordResetRepository =
        AppDataSource.getRepository(PasswordReset);
      const resetEntry = await passwordResetRepository.findOne({
        where: { email },
      });
      if (!resetEntry) {
        const err = new ExpiredException();
        return next(err);
      }

      const token = new Token();
      const verifiedToken = await token.verify({
        expiresTime: Number(config.expiresInMinutes),
        resetEntry: resetEntry as PasswordReset,
        token: uniqueToken,
      });

      if (!verifiedToken) {
        const err = new ExpiredException();
        return next(err);
      }
      await passwordResetRepository.delete(resetEntry.id);
      const userRepository = AppDataSource.getRepository(User);
      userRepository.update({ email }, { password: hashPassword(password) });
      return res.send({ data: true });
    } catch (error) {
      return next(error);
    }
  }
}

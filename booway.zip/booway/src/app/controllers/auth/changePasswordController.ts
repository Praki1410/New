import AppDataSource from "@database";
import { NotMatchException } from "@helpers/ErrorHandler";
import { User } from "@models/user";
import { changePasswordValidator } from "@validators/auth";
import { NextFunction, Request, Response } from "express";
import bcrypt from "bcryptjs";

export default class ChangePasswordController {
  /**
   * Change password
   *
   * @route POST /auth/change-password
   * @param req.body - Request payload
   * oldPassword - required
   * newPassword - required
   *
   */
  async index(req: Request, res: Response, next: NextFunction) {
    try {
      const { oldPassword, newPassword } =
        await changePasswordValidator.validate(req.body);

      const { id } = req.user;
      const userRepository = AppDataSource.getRepository(User);
      const data = await userRepository.findOneOrFail({
        where: { id },
        select: ["password"],
      });
      if (!data.checkIfPasswordMatch(oldPassword)) {
        const err = new NotMatchException("Old Password");
        return next(err);
      }
      await AppDataSource.getRepository(User).update(
        { id },
        { password: bcrypt.hashSync(newPassword, 8) }
      );

      return res.send({ data: true });
    } catch (error) {
      return next(error);
    }
  }
}

import AppDataSource from "@database";
import {
  AuthorizationException,
  BadRequestException,
  ExistException,
  NotFoundException,
} from "@helpers/ErrorHandler";
import { NextFunction, Request, Response } from "express";
import { filterSortingList } from "@utils/filterSortingList";
import { Categories } from "@models/category";
import { createOrUpdateValidator } from "@validators/category";
import { Not } from "typeorm";
import { deniedPermission, permissions } from "@utils/permission";

export default class CategoriesController {
  /**
   * Admin and Provider Only
   * Get Category list
   * @route GET /categories
   * @query page , perPage
   * implement pagination, sorting and filter on name field
   */
  async index(req: Request, res: Response, next: NextFunction) {
    try {
      if (deniedPermission(req.user.role, permissions.categories.list)) {
        const err = new AuthorizationException();
        return next(err);
      }
      const categoryRepository = AppDataSource.getRepository(Categories);
      const data = await filterSortingList(categoryRepository, req.query);
      return res.send({ data });
    } catch (e) {
      return next(e);
    }
  }

  /**
   * Admin Only
   * Create Category
   * @route POST /categories/
   * @param req.body - Request payload
   * name - required
   *
   */
  async create(req: Request, res: Response, next: NextFunction) {
    try {
      if (deniedPermission(req.user.role, permissions.categories.create)) {
        const err = new AuthorizationException();
        return next(err);
      }
      const category = await createOrUpdateValidator.validate(req.body, {
        stripUnknown: true,
      });
      const categoryRepository = AppDataSource.getRepository(Categories);
      const createdCategory = categoryRepository.create(category);
      const data = await categoryRepository.save(createdCategory);
      return res.send({ data });
    } catch (e) {
      return next(e);
    }
  }

  /**
   * Admin Only
   * Get category by id
   * @route GET /categories/:id
   *
   */
  async show(req: Request, res: Response, next: NextFunction) {
    try {
      if (deniedPermission(req.user.role, permissions.categories.show)) {
        const err = new AuthorizationException();
        return next(err);
      }
      const { id } = req.params;
      const categoryRepository = AppDataSource.getRepository(Categories);
      const data = await categoryRepository.findOne({
        where: { id },
      });
      if (!data) {
        const err = new NotFoundException("Category");
        return next(err);
      }
      return res.send({ data });
    } catch (e) {
      return next(e);
    }
  }

  /**
   * Admin Only
   * Update Category
   * @route PATCH /categories/:id
   * @route PUT /categories/:id
   * @param req.body - Request payload
   * name - required
   * applied check for we can not create category which name is already exist
   *
   */
  async update(req: Request, res: Response, next: NextFunction) {
    try {
      if (deniedPermission(req.user.role, permissions.categories.update)) {
        const err = new AuthorizationException();
        return next(err);
      }
      const { id } = req.params;
      const category = await createOrUpdateValidator.validate(req.body, {
        stripUnknown: true,
      });
      const categoryRepository = AppDataSource.getRepository(Categories);
      const existCategory = await categoryRepository.findOne({
        where: { id },
      });
      if (!existCategory) {
        const err = new NotFoundException("Category");
        return next(err);
      }
      const existName = await categoryRepository.findOne({
        where: { slug: category.name.toLowerCase(), id: Not(id) },
      });
      if (existName) {
        const err = new ExistException("Category");
        return next(err);
      }
      existCategory.name = category.name;
      const data = await categoryRepository.save(existCategory); // use save instead of update for it will trigger the hooks(updateSlug)
      delete data.slug;
      return res.send({ data });
    } catch (e) {
      return next(e);
    }
  }

  /**
   * Admin Only
   * Delete Category
   * @route DELETE /categories/:id
   *
   */
  async delete(req: Request, res: Response, next: NextFunction) {
    try {
      if (deniedPermission(req.user.role, permissions.categories.delete)) {
        const err = new AuthorizationException();
        return next(err);
      }
      const { id } = req.params;
      const categoryRepository = AppDataSource.getRepository(Categories);

      const category = await categoryRepository.findOne({
        where: { id },
        relations: ["activities"],
      });

      // If the category doesn't exist, throw a NotFoundException
      if (!category) {
        throw new NotFoundException("Category not found.");
      }

      // Proceed to delete the category
      const result = await categoryRepository.delete(id);

      return res.send({ data: Boolean(result.affected) });
    } catch (e) {
      return next(e);
    }
  }
}

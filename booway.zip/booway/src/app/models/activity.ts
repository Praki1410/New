import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToMany,
  JoinTable,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  JoinColumn,
} from "typeorm";
import {
  IsEnum,
  IsString,
  IsNumber,
  IsArray,
  IsOptional,
} from "class-validator";
import { ActivityStatus, Language, ActivityLevel } from "../../enums/enum";
import { Categories } from "./category";
import { User } from "./user"

@Entity("activities")
export class ActivityModel {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column()
  @IsString()
  guide_name: string;

  @Column()
  @IsString()
  guide_description: string;

  @Column({ nullable: true })
  @IsOptional()
  @IsString()
  avatar: string;

  @Column({ nullable: true })
  @IsOptional()
  @IsString()
  banner_image: string;

  @Column("simple-array", { nullable: true })
  @IsArray()
  @IsString({ each: true })
  gallery: string[];

  @Column("simple-array")
  @IsArray()
  @IsEnum(Language, { each: true })
  language: Language[];

  @Column("decimal", { precision: 10, scale: 2 })
  @IsNumber()
  price: number;

  @Column()
  @IsString()
  description: string;

  @ManyToMany(() => Categories, (category) => category.activities, {
    cascade: false,
  })
  @JoinTable()
  @IsArray()
  categories: Categories[];

  @ManyToOne(() => Categories, (category) => category.activities, {
    nullable: true,
  })


@ManyToOne(() => User, (user) => user.activities, { nullable: true })
@JoinColumn({ name: "created_by" })
@Column({ type: "uuid" }) 
@IsOptional()
created_by: User| string;

// @Column({ nullable: true })
// updated_by:  User|string; 

@ManyToOne(() => Categories, (category) => category.activities)
@JoinColumn({ name: "category_id" }) 
main_category: Categories;


  @Column()
  @IsString()
  duration_of_activity: string;

  @Column()
  @IsEnum(ActivityLevel)
  level_of_activity: ActivityLevel;

  @Column("int")
  @IsNumber()
  min_people: number;

  @Column("int")
  @IsNumber()
  max_people: number;

  @Column()
  @IsString()
  activity_include: string;

  @Column()
  @IsString()
  activity_exclude: string;

  @Column()
  @IsString()
  activity_highlight: string;

  @Column({ nullable: true })
  @IsOptional()
  @IsString()
  youtube_url: string | null;

  @Column("timestamp", { nullable: true })
  @IsOptional()
  booking_period_start: string;

  @Column("timestamp", { nullable: true })
  @IsOptional()
  booking_period_end: string;

  @Column("timestamp", { nullable: true })
  @IsOptional()
  cancel_booking_deadline: string;

  @Column("simple-array", { nullable: true })
  @IsArray()
  @IsString({ each: true })
  availability: string[];

  @Column()
  @IsString()
  real_address: string;

  @Column("decimal", { precision: 10, scale: 6 })
  @IsNumber()
  map_latitude: number;

  @Column("decimal", { precision: 10, scale: 6 })
  @IsNumber()
  map_longitude: number;

  @Column({ nullable: true })
  @IsOptional()
  @IsString()
  website?: string;

  @Column()
  @IsString()
  email: string;

  @Column()
  @IsString()
  phone: string;

  @Column({
    type: "enum",
    enum: ActivityStatus,
    default: ActivityStatus.PENDING,
  })
  @IsEnum(ActivityStatus)
  status: ActivityStatus;

  @CreateDateColumn()
  created_at: Date;

  @UpdateDateColumn()
  updated_at: Date | null;
}

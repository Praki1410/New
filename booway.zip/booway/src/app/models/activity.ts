import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  ManyToMany,
  JoinTable,
  CreateDateColumn,
  UpdateDateColumn,
} from "typeorm";
import {
  IsEnum,
  IsString,
  IsNumber,
  IsArray,
  IsOptional,
} from "class-validator";
import { ActivityStatus, Language, ActivityType, ActivityLevel } from "../../enums/enum";
import { Categories } from "./category";

@Entity("activities")
export class ActivityModel {
  @PrimaryGeneratedColumn("uuid")
  id: string;

  @Column()
  @IsString()
  guideName: string;

  @Column()
  @IsString()
  guideDescription: string;

  /** 🔹 Single Avatar Image */
  @Column({ nullable: true })
  @IsOptional()
  @IsString()
  avatar: string;

  /** 🔹 Single Banner Image */
  @Column({ nullable: true })
  @IsOptional()
  @IsString()
  bannerImage: string;

  /** 🔹 Multiple Images in Gallery */
  @Column("simple-array", { nullable: true })
  @IsArray()
  @IsString({ each: true })
  gallery: string[];

  @Column("simple-array")
  @IsArray()
  @IsEnum(Language, { each: true })
  language: Language[];

  @Column("decimal", { precision: 10, scale: 2 })
  @IsNumber()
  price: number;

  @Column()
  @IsString()
  description: string;

  /** 🔹 Category Relation */
  @ManyToMany(() => Categories, (category) => category.activities, { cascade: false })
  @JoinTable()
  @IsArray()
  categories: Categories[];

  @Column()
  @IsString()
  durationOfActivity: string;

  @Column()
  @IsEnum(ActivityLevel)
  levelOfActivity: ActivityLevel;

  @Column()
  @IsString()
  minPeople: number;

  @Column()
  @IsNumber()
  maxPeople: number;

  @Column()
  @IsString()
  activityInclude: string;

  @Column()
  @IsString()
  activityExclude: string;

  @Column()
  @IsString()
  activityHighlight: string;

  @Column({ nullable: true })
  @IsOptional()
  @IsString()
  youtubeUrl: string | null;

  @Column()
  @IsString()
  bookingPeriodStart: string;

  @Column()
  @IsString()
  bookingPeriodEnd: string;

  @Column()
  @IsString()
  cancelBookingDeadline: string;

  @Column("simple-array")
  @IsArray()
  @IsString({ each: true })
  availability: string[];

  /** 🔹 Location Data */
  @Column()
  @IsString()
  realAddress: string;

  @Column("decimal", { precision: 10, scale: 6 })
  @IsNumber()
  mapLatitude: number;

  @Column("decimal", { precision: 10, scale: 6 })
  @IsNumber()
  mapLongitude: number;

  /** 🔹 Contact Information */
  @Column({ nullable: true })
  @IsOptional()
  @IsString()
  website?: string;

  @Column()
  @IsString()
  email: string;

  @Column()
  @IsString()
  phone: string;

  @Column({
    type: "enum",
    enum: ActivityStatus,
    default: ActivityStatus.PENDING,
  })
  @IsEnum(ActivityStatus)
  status: ActivityStatus;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date | null;
}

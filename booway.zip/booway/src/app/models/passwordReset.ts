import { DateTime } from "luxon";
import {
  Column,
  CreateDateColumn,
  Entity,
  Unique,
  UpdateDateColumn,
} from "typeorm";

@Entity({
  name: "password_resets",
})
export class PasswordReset {
  @Column({ primary: true, type: "uuid", generated: "uuid" })
  id: string;

  @Unique("unique_email", ["email"])
  @Column()
  email: string;

  @Column()
  token: string;

  @Column()
  @CreateDateColumn()
  createdAt: DateTime;

  @Column()
  @UpdateDateColumn()
  updatedAt: DateTime | null;
}

import { DateTime } from "luxon";
import {
  Column,
  CreateDateColumn,
  Entity,
  JoinColumn,
  OneToOne,
  Unique,
  UpdateDateColumn,
} from "typeorm";
import { User } from "@models/user";

@Entity({
  name: "sessions",
})
export class Sessions {
  @Column({ primary: true, type: "uuid", generated: "uuid" })
  id: string;

  @Unique("unique_id", ["userId"])
  @Column({ name: "user_id" })
  userId: string;

  @OneToOne(() => User, { onDelete: "CASCADE" })
  @JoinColumn({ name: "user_id" })
  user: User;

  @Column()
  @CreateDateColumn()
  createdAt: DateTime;

  @Column()
  @UpdateDateColumn()
  updatedAt: DateTime | null;
}

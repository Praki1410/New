import { DateTime } from "luxon";
import { Column, CreateDateColumn, Entity, UpdateDateColumn,OneToMany     } from "typeorm";
import bcrypt from "bcryptjs";
import Storage from "@utils/storage";
import   {ActivityModel} from "./activity"


export enum IRole {
  USER = "USER",
  PROVIDER = "PROVIDER",
  ADMIN = "ADMIN",
}

@Entity({
  name: "users",
})
export class User {
  @Column({ primary: true, type: "uuid", generated: "uuid" })
  id: string;

  @Column()
  firstName: string;

  @Column()
  lastName: string;

  @Column({ unique: true })
  email: string;

  @Column({ select: false })
  password: string;

  @Column({ type: "enum", enum: IRole, default: IRole.USER })
  role: IRole;

  @Column()
  isVerified: boolean;
  
  @OneToMany(() => ActivityModel, (activity) => activity.created_by)
  activities: ActivityModel[];

  @Column({
    transformer: {
      to(value) {
        return value;
      },
      from(value) {
        const storage = new Storage();
        return value ? storage.get(value) : null;
      },
    },
    nullable: true,
  })
  avatar: string;

  @Column()
  @CreateDateColumn()
  createdAt: DateTime;

  @Column()
  @UpdateDateColumn()
  updatedAt: DateTime | null;

  checkIfPasswordMatch(unencryptedPassword: string) {
    return bcrypt.compareSync(unencryptedPassword, this.password);
  }
}

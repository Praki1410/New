import { Request, Response, NextFunction } from "express";
import { AuthorizationException, ServerException } from "@helpers/ErrorHandler";
import { IRole, User } from "@models/user";
import JWTToken from "@utils/createJwtToken";

export const checkUserRole = async (req: Request, res: Response, next: NextFunction) => {
  const jwtToken = new JWTToken();

  try {

    const user = await jwtToken.verify(req, next);
    req.user = user as User;
    if (req.user.role !== IRole.USER) {
      return next(new AuthorizationException("Access denied. Only users can perform this action."));
    }

    next(); 
  } catch (e) {
    return next(new ServerException(e.message));
  }
};

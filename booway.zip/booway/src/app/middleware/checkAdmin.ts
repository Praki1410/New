import { Request, Response, NextFunction } from "express";
import { ServerException, AuthorizationException } from "@helpers/ErrorHandler";
import JWTToken from "@utils/createJwtToken";
import { User, IRole } from "@models/user";

export const checkAdmin = async (
  req: Request, 
  res: Response, 
  next: NextFunction
) => {
  const jwtToken = new JWTToken();

  try {

    const user = (await jwtToken.verify(req, next)) as User;


    if (!req.user) {
      req.user = user;
    }

    if (req.user.role !== IRole.ADMIN) {
      return next(new AuthorizationException("Only admins can perform this action."));
    }

    next();
  } catch (e) {
    return next(new ServerException(e.message));
  }
};

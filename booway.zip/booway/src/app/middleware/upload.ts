import multer, { FileFilterCallback } from "multer";
import { Request } from "express";
import path from "path";


const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, "../../uploads/activities"));  
  },
  filename: (req, file, cb) => {

    cb(null, `${Date.now()}-${file.originalname}`);
  },
});

const fileFilter = (req: Request, file: Express.Multer.File, cb: FileFilterCallback) => {
  if (!file.mimetype.startsWith("image/")) {

    return cb(new Error("Only image files are allowed!"));
  }
  cb(null, true);
};


export const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: 5 * 1024 * 1024 },  
});

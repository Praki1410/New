import { Request, Response, NextFunction } from "express";
import { ServerException, VerifiedException } from "@helpers/ErrorHandler";
import JWTToken from "@utils/createJwtToken";
import { IRole, User } from "@models/user";

declare global {
  namespace Express {
    interface Request {
      user?: User;
    }
  }
}

export const checkVerifiedProvider = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const jwtToken = new JWTToken();

  try {
 
    const user = (await jwtToken.verify(req, next)) as User | null;

    if (!user) {
      return res.status(401).json({ message: "Unauthorized: User not found" });
    }

    req.user = user; 

    if (user.role === IRole.PROVIDER && !user.isVerified) {
      return next(new VerifiedException());
    }

    next(); 
  } catch (e) {
    return next(new ServerException(e instanceof Error ? e.message : "Unknown error"));
  }
};

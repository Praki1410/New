import { DataSource } from "typeorm";
import config from "@config";
import { PostgresConnectionOptions } from "typeorm/driver/postgres/PostgresConnectionOptions";
import { SnakeNamingStrategy } from "typeorm-naming-strategies";

const AppDataSource = new DataSource({
  type: "postgres",
  ...config.database,
  namingStrategy: new SnakeNamingStrategy(),
  entities: ["src/app/models/*.ts"],
  migrations: ["src/database/migrations/**/*.ts"],
} satisfies PostgresConnectionOptions);

export default AppDataSource;

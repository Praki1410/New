import { MigrationInterface, QueryRunner } from "typeorm";

export class NewcolAdd1741757767894 implements MigrationInterface {
    name = 'NewcolAdd1741757767894'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "activities" ADD "category_id" uuid`);
        await queryRunner.query(`ALTER TABLE "activities" DROP COLUMN "booking_period_start"`);
        await queryRunner.query(`ALTER TABLE "activities" ADD "booking_period_start" TIMESTAMP`);
        await queryRunner.query(`ALTER TABLE "activities" DROP COLUMN "booking_period_end"`);
        await queryRunner.query(`ALTER TABLE "activities" ADD "booking_period_end" TIMESTAMP`);
        await queryRunner.query(`ALTER TABLE "activities" DROP COLUMN "cancel_booking_deadline"`);
        await queryRunner.query(`ALTER TABLE "activities" ADD "cancel_booking_deadline" TIMESTAMP`);
        await queryRunner.query(`ALTER TABLE "activities" ALTER COLUMN "availability" DROP NOT NULL`);
        await queryRunner.query(`ALTER TABLE "activities" ADD CONSTRAINT "FK_cf4a8062ad267056ddd5f867ac1" FOREIGN KEY ("category_id") REFERENCES "categories"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "activities" DROP CONSTRAINT "FK_cf4a8062ad267056ddd5f867ac1"`);
        await queryRunner.query(`ALTER TABLE "activities" ALTER COLUMN "availability" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "activities" DROP COLUMN "cancel_booking_deadline"`);
        await queryRunner.query(`ALTER TABLE "activities" ADD "cancel_booking_deadline" character varying NOT NULL`);
        await queryRunner.query(`ALTER TABLE "activities" DROP COLUMN "booking_period_end"`);
        await queryRunner.query(`ALTER TABLE "activities" ADD "booking_period_end" character varying NOT NULL`);
        await queryRunner.query(`ALTER TABLE "activities" DROP COLUMN "booking_period_start"`);
        await queryRunner.query(`ALTER TABLE "activities" ADD "booking_period_start" character varying NOT NULL`);
        await queryRunner.query(`ALTER TABLE "activities" DROP COLUMN "category_id"`);
    }

}

import { IRole } from "@models/user";
import { hashPassword } from "@validators/user";
import { MigrationInterface, QueryRunner } from "typeorm";

export class AdminUserSeeder1740119703278 implements MigrationInterface {
  public async up(queryRunner: QueryRunner): Promise<void> {
    const password = hashPassword("admin@123");
    await queryRunner.query(
      `INSERT INTO users (first_name,last_name, email, password,is_verified,role) VALUES('admin','admin', 'admin@admin.com', '${password}',true,'${IRole.ADMIN}')`
    );
  }

  public async down(queryRunner: QueryRunner): Promise<void> {
    await queryRunner.query(`DELETE FROM users WHERE email='admin@admin.com'`);
  }
}

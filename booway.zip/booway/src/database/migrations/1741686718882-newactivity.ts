import { MigrationInterface, QueryRunner } from "typeorm";

export class Newactivity1741686718882 implements MigrationInterface {
    name = 'Newactivity1741686718882'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "activities" ADD "created_by" character varying NOT NULL`);
        await queryRunner.query(`ALTER TABLE "activities" DROP COLUMN "booking_period_start"`);
        await queryRunner.query(`ALTER TABLE "activities" ADD "booking_period_start" TIMESTAMP`);
        await queryRunner.query(`ALTER TABLE "activities" DROP COLUMN "booking_period_end"`);
        await queryRunner.query(`ALTER TABLE "activities" ADD "booking_period_end" TIMESTAMP`);
        await queryRunner.query(`ALTER TABLE "activities" DROP COLUMN "cancel_booking_deadline"`);
        await queryRunner.query(`ALTER TABLE "activities" ADD "cancel_booking_deadline" TIMESTAMP`);
        await queryRunner.query(`ALTER TABLE "activities" ALTER COLUMN "availability" DROP NOT NULL`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "activities" ALTER COLUMN "availability" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "activities" DROP COLUMN "cancel_booking_deadline"`);
        await queryRunner.query(`ALTER TABLE "activities" ADD "cancel_booking_deadline" character varying NOT NULL`);
        await queryRunner.query(`ALTER TABLE "activities" DROP COLUMN "booking_period_end"`);
        await queryRunner.query(`ALTER TABLE "activities" ADD "booking_period_end" character varying NOT NULL`);
        await queryRunner.query(`ALTER TABLE "activities" DROP COLUMN "booking_period_start"`);
        await queryRunner.query(`ALTER TABLE "activities" ADD "booking_period_start" character varying NOT NULL`);
        await queryRunner.query(`ALTER TABLE "activities" DROP COLUMN "created_by"`);
    }

}

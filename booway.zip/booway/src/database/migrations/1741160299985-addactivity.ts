import { MigrationInterface, QueryRunner } from "typeorm";

export class Addactivity1741160299985 implements MigrationInterface {
    name = 'Addactivity1741160299985'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TYPE "public"."activities_status_enum" AS ENUM('Pending', 'Verified', 'Rejected', 'Active')`);
        await queryRunner.query(`CREATE TABLE "activities" ("id" uuid NOT NULL DEFAULT uuid_generate_v4(), "guide_name" character varying NOT NULL, "guide_description" character varying NOT NULL, "avatar" character varying, "banner_image" character varying, "gallery" text, "language" text NOT NULL, "price" numeric(10,2) NOT NULL, "description" character varying NOT NULL, "duration_of_activity" character varying NOT NULL, "level_of_activity" character varying NOT NULL, "min_people" integer NOT NULL, "max_people" integer NOT NULL, "activity_include" character varying NOT NULL, "activity_exclude" character varying NOT NULL, "activity_highlight" character varying NOT NULL, "youtube_url" character varying, "booking_period_start" character varying NOT NULL, "booking_period_end" character varying NOT NULL, "cancel_booking_deadline" character varying NOT NULL, "availability" text NOT NULL, "real_address" character varying NOT NULL, "map_latitude" numeric(10,6) NOT NULL, "map_longitude" numeric(10,6) NOT NULL, "website" character varying, "email" character varying NOT NULL, "phone" character varying NOT NULL, "status" "public"."activities_status_enum" NOT NULL DEFAULT 'Pending', "is_active" boolean NOT NULL DEFAULT true, "created_at" TIMESTAMP NOT NULL DEFAULT now(), "updated_at" TIMESTAMP NOT NULL DEFAULT now(), CONSTRAINT "PK_7f4004429f731ffb9c88eb486a8" PRIMARY KEY ("id"))`);
        await queryRunner.query(`CREATE TABLE "activities_categories_categories" ("activities_id" uuid NOT NULL, "categories_id" uuid NOT NULL, CONSTRAINT "PK_d6262c21de8e069cddc5f2e7c14" PRIMARY KEY ("activities_id", "categories_id"))`);
        await queryRunner.query(`CREATE INDEX "IDX_05e6a66d31936ce2c367626ce4" ON "activities_categories_categories" ("activities_id") `);
        await queryRunner.query(`CREATE INDEX "IDX_dd818a821dd25bcc5774986769" ON "activities_categories_categories" ("categories_id") `);
        await queryRunner.query(`ALTER TABLE "categories" ADD CONSTRAINT "UQ_8b0be371d28245da6e4f4b61878" UNIQUE ("name")`);
        await queryRunner.query(`ALTER TABLE "activities_categories_categories" ADD CONSTRAINT "FK_05e6a66d31936ce2c367626ce49" FOREIGN KEY ("activities_id") REFERENCES "activities"("id") ON DELETE CASCADE ON UPDATE CASCADE`);
        await queryRunner.query(`ALTER TABLE "activities_categories_categories" ADD CONSTRAINT "FK_dd818a821dd25bcc5774986769b" FOREIGN KEY ("categories_id") REFERENCES "categories"("id") ON DELETE NO ACTION ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "activities_categories_categories" DROP CONSTRAINT "FK_dd818a821dd25bcc5774986769b"`);
        await queryRunner.query(`ALTER TABLE "activities_categories_categories" DROP CONSTRAINT "FK_05e6a66d31936ce2c367626ce49"`);
        await queryRunner.query(`ALTER TABLE "categories" DROP CONSTRAINT "UQ_8b0be371d28245da6e4f4b61878"`);
        await queryRunner.query(`DROP INDEX "public"."IDX_dd818a821dd25bcc5774986769"`);
        await queryRunner.query(`DROP INDEX "public"."IDX_05e6a66d31936ce2c367626ce4"`);
        await queryRunner.query(`DROP TABLE "activities_categories_categories"`);
        await queryRunner.query(`DROP TABLE "activities"`);
        await queryRunner.query(`DROP TYPE "public"."activities_status_enum"`);
    }

}

import { MigrationInterface, QueryRunner } from "typeorm";

export class Updateactivity1741675895033 implements MigrationInterface {
    name = 'Updateactivity1741675895033'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "activities" DROP COLUMN "is_active"`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "activities" ADD "is_active" boolean NOT NULL DEFAULT true`);
    }

}

# booway

# Installation Guide

## pgAdmin with PostgreSQL

### Step 1: Install PostgreSQL

1. Visit the [PostgreSQL official website](https://www.postgresql.org/) and download the appropriate installer for your operating system.
2. Follow the installation instructions provided with the installer.
3. Note down the password you set during the installation process.

### Step 2: Install pgAdmin

1. Visit the [pgAdmin official website](https://www.pgadmin.org/) and download the installer for your operating system.
2. Run the installer and follow the installation instructions.
3. Launch pgAdmin after installation.

### Step 3: Connect pgAdmin to PostgreSQL Server

1. Open pgAdmin.
2. In the Object browser panel, right-click on "Servers" and select "Create" > "Server..."
3. In the "General" tab, enter a name for your server.
4. In the "Connection" tab, fill in the following details:
   - Hostname/address: `localhost`
   - Port: `5432` (default PostgreSQL port)
   - Maintenance database: `postgres`
   - Username: Your PostgreSQL username (usually `postgres`)
   - Password: The password you set during PostgreSQL installation.
5. Click "Save" to connect to the PostgreSQL server.

---

## Setting up NodeJS Project with Migrations

## Installing dependencies

```bash
    npm install
```

## Configure Database

NodeJS uses .env file for environment configuration. Set up your env variables which given in .env.example file

## Run Migrations

```bash
   npm run typeorm migration:run
```
## Revert Migrations

```bash
   npm run typeorm migration:revert
```

## Generate Migrations

```bash
   npm run typeorm migration:generate -- src/database/migrations/users
```

## Create Migrations

```bash
 npx typeorm-ts-node-commonjs migration:create src/database/migrations/CreateUsers
```
### Running the development server.

```bash
    npm run dev
```

### Building for production.

```bash
    npm run build
```

### Running the production server.

```bash
    npm run start
```
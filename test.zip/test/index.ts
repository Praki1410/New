import 'reflect-metadata';
import express from 'express';
import cors from 'cors';
import { AppData } from "./src/config/db";
import cookieParser from 'cookie-parser';
import userRoutes from './src/routes/adminRoutes';
import authRoutes from "./src/routes/authRoutes";

const app = express();

// CORS configuration
const corsOptions = {
  origin: 'http://localhost:5173', 
  methods: 'GET,POST,PUT,DELETE,PATCH',
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: true, 
};



app.use(express.json());
app.use(cookieParser());
app.use(cors(corsOptions));

app.use('/api/v1/user', userRoutes);
app.use("/api/v1/auth", authRoutes);

const PORT = 5000;
const start = async () => {
  try {
    await AppData.initialize();
    console.log('Database connected');
    
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (err) {
    console.error('Error:', err);
  }
};

start();

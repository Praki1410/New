import { Response } from 'express';
import { AuthErrorType } from "../enum/authErrorTypes";

export interface AuthErrorResponse {
    message: string;
    status: AuthErrorType;
    details?: any;
}

export const sendAuthError = (res: Response, message: string, status: AuthErrorType, details?: any): void => {
    res.status(401).json({ message, status, details });
};




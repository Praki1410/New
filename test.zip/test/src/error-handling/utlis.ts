import { Response } from 'express';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';


export class ErrorHandler {
  static handleError(res: Response, error: any, defaultMessage = 'Internal Server Error'): void {
    res.status(500).json({ message: error.message || defaultMessage });
  }

  static handleNotFound(res: Response, message = 'Resource not found'): void {
    res.status(404).json({ message });
  }
  

}

export const validateInput = (schema: any, data: any) => {
  const { error } = schema.validate(data);
  if (error) throw new Error(error.details[0].message);
};

export const hashPassword = async (password: string) => {
  return await bcrypt.hash(password, 10);
};

export const comparePassword = async (password: string, hashedPassword: string) => {
  return await bcrypt.compare(password, hashedPassword);
};

export const generateToken = (userId: number, role: string, email: string) => {
  return jwt.sign(
    { userId, role, email },
    process.env.JWT as string,
    { expiresIn: '1h' }
  );
};




import { Request, Response, NextFunction } from 'express';
import jwt, { JwtPayload, TokenExpiredError, JsonWebTokenError } from 'jsonwebtoken';
import { AuthErrorType } from "../enum/authErrorTypes";

interface CustomJwtPayload extends JwtPayload {
    role: string;
    userId: number;
    email: string;
}

declare global {
    namespace Express {
        interface Request {
            user?: CustomJwtPayload;
        }
    }
}

const handleAuthError = (res: Response, message: string, status: AuthErrorType, details?: any): void => {
    res.status(401).json({ message, status, details });
};


export const authMiddleware = (requiredRole: string | null = null) => {
  return async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      const secret = process.env.JWT;
      if (!secret) {
        return handleAuthError(res, 'Authentication service is not properly configured', AuthErrorType.CONFIG_ERROR);
      }

      const token = req.headers['authorization']?.split(' ')[1]; 

      if (!token) {
        return handleAuthError(res, 'Missing token in Authorization header', AuthErrorType.TOKEN_MISSING);
      }

      const verified = jwt.verify(token, secret) as CustomJwtPayload;

      if (!verified.role || !verified.userId || !verified.email) {
        return handleAuthError(res, 'Invalid token payload structure', AuthErrorType.TOKEN_INVALID);
      }

      req.user = verified;

      if (requiredRole && verified.role !== requiredRole) {
        return res.status(403).json({
          message: 'Access denied due to insufficient permissions',
          status: AuthErrorType.INSUFFICIENT_PERMISSIONS,
          details: { required: requiredRole, provided: verified.role, userId: verified.userId }
        });
      }

      next();
    } catch (error) {
      if (error instanceof TokenExpiredError) {
        return handleAuthError(res, 'Token has expired. Please log in again', AuthErrorType.TOKEN_EXPIRED, {
          expiredAt: (error as TokenExpiredError).expiredAt
        });
      } else if (error instanceof JsonWebTokenError) {
        return handleAuthError(res, 'Invalid token structure or signature', AuthErrorType.TOKEN_INVALID);
      } else {
        console.error('Authentication error:', error);  // Detailed error log
        return res.status(500).json({
          message: 'Internal server error during authentication',
          status: 'INTERNAL_ERROR'
        });
      }
    }
  };
};


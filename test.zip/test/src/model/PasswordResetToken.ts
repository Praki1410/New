import { Entity, Column, PrimaryGeneratedColumn, ManyToOne } from 'typeorm';
import { Emp_DB } from './userModel';

@Entity()
export class PasswordResetToken {
  @PrimaryGeneratedColumn()
  id!: number;

  @Column()
  token!: string;

  @Column({ type: 'timestamp' })
  expiry!: Date;

  @ManyToOne(() => Emp_DB, (user) => user.passwordResetTokens, { onDelete: 'CASCADE' })
  user!: Emp_DB;
}

import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn,OneToMany , UpdateDateColumn } from 'typeorm';
import { IsEmail, Length, IsOptional, IsString } from 'class-validator';
import { Role } from '../enum/Role';
import { PasswordResetToken } from '../model/PasswordResetToken';
@Entity()
export class Emp_DB {
  @PrimaryGeneratedColumn()
  id!: number;

  @Column()
  @IsEmail()
  email!: string;

  @Column()
  @Length(6, 100) 
  password!: string;


  
  @Column({
    type: 'enum',
    enum: Role,
    default: Role.USER, 
  })
  role!: Role;

  @Column({ nullable: true })
  @IsOptional()
  @IsString()
  name!: string;

  @Column({ nullable: true })
  @IsOptional()
  @IsString()
  address!: string;


  @CreateDateColumn({ type: 'timestamp' })
  createdAt!: Date;


  @UpdateDateColumn({ type: 'timestamp' })
  updatedAt!: Date;

  @OneToMany(() => PasswordResetToken, (token) => token.user)
  passwordResetTokens!: PasswordResetToken[];
}

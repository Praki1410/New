import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';


@Entity()
export class TokenBlacklist {
  @PrimaryGeneratedColumn()
  id!: number;

  @Column()
  token!: string;

  @Column({ type: 'timestamp', default: () => 'CURRENT_TIMESTAMP' })
  expiry!: Date;
 
 
}

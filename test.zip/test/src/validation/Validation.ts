import Joi from 'joi';

export const empValidationSchema = Joi.object({
  email: Joi.string().email().required(),
  password: Joi.string().min(6).required(),
  role: Joi.string().valid('user', 'admin').default('user'),
  Name: Joi.string().optional(),
  address: Joi.string().optional(),
});

export const loginValidationSchema = Joi.object({
  email: Joi.string().email().required(),
  password: Joi.string().min(6).required(),
});

export const forgotPasswordSchema = Joi.object({
  email: Joi.string().email().required(),
});

export const resetPasswordSchema = Joi.object({
  newPassword: Joi.string().min(6).required(),
});
export const updateUserSchema = Joi.object({
  email: Joi.string().email().optional(),
  password: Joi.forbidden().messages({
    'any.unknown': 'To update your password, please visit the forgot password page.',
  }),
  role: Joi.string().valid('user', 'admin').optional(),
});

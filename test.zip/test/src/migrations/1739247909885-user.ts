import { MigrationInterface, QueryRunner } from "typeorm";

export class User1739247909885 implements MigrationInterface {
    name = 'User1739247909885'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "emp_db" ADD "Name" character varying`);
        await queryRunner.query(`ALTER TABLE "emp_db" ADD "address" character varying`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "emp_db" DROP COLUMN "address"`);
        await queryRunner.query(`ALTER TABLE "emp_db" DROP COLUMN "Name"`);
    }

}

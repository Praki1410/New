
import { Response } from 'express';
import { Role } from '../enum/Role';

export const setAuthCookies = (res: Response, userId: string, token: string, role: string   ): void => {
  const cookieOptions = {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    maxAge: 3600000,
    sameSite: 'None',
    path: '/',
  };
  res.cookie('userId', userId, cookieOptions);
  res.cookie('token', token, cookieOptions);
  res.cookie('role', role, cookieOptions);
};



export const validateRole = (role: string): void => {
  if (!Object.values(Role).includes(role as Role)) { 
    throw new Error(`Invalid role. Allowed values: ${Object.values(Role).join(', ')}`);
  }
};




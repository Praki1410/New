import { Request, Response } from 'express';
import {Role} from "../enum/Role"

export const handleRoleBasedAccess = (
    req: Request,
    res: Response,
    adminAction: (req: Request, res: Response) => void,
    userAction?: (req: Request, res: Response) => void
  ) => {
    if (req.user?.role === Role.ADMIN) {
      adminAction(req, res);
    } else if (req.user?.role === Role.USER && userAction) {
      userAction(req, res);
    } else {
      res.status(403).json({ message: 'Access denied' });
    }
  };

// import { JwtPayload } from 'jsonwebtoken';

// export interface CustomJwtPayload extends JwtPayload {
//     role: string;
//     userId: number;
//     email: string;
// }

// export interface AuthErrorResponse {
//     message: string;
//     details?: any;
// }

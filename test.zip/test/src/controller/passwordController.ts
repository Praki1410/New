
import { Request, Response } from "express";
import { PasswordService } from "../service/passwordService";
import { ErrorHandler } from "../error-handling/utlis";
import { forgotPasswordSchema, resetPasswordSchema } from "../validation/Validation";

const passService = new PasswordService();

export class PasswordController {
  
  public forgotPassword = async (req: Request, res: Response): Promise<void> => {
    try {
      const { error } = forgotPasswordSchema.validate(req.body, { abortEarly: false });

      if (error) {
        res.status(400).json({ error: error.details.map((err) => err.message) });
        return;
      }

      const { email } = req.body;
      const result = await passService.forgotPassword(email);
      res.status(200).json(result);
    } catch (error: any) {
      ErrorHandler.handleError(res, error);
    }
  };

  public resetPassword = async (req: Request, res: Response): Promise<void> => {
    try {
      const authHeader = req.headers["authorization"];
      const token = authHeader?.startsWith("Bearer ") ? authHeader.split(" ")[1] : null;

      if (!token) {
        return ErrorHandler.handleError(res, { statusCode: 400, message: "Token is required in Bearer format" });
      }

      const { error } = resetPasswordSchema.validate(req.body, { abortEarly: false });
      if (error) {
        return res.status(400).json({ error: error.details.map((err) => err.message) });
      }

      const { newPassword } = req.body;
      const result = await passService.resetPassword(token, newPassword);
      res.status(200).json(result);
    } catch (error: any) {
      ErrorHandler.handleError(res, error);
    }
  };
}


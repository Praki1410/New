

import { Request, Response } from 'express';
import { UserService } from '../service/userService';
import { ErrorHandler } from '../error-handling/utlis';
import { empValidationSchema } from '../validation/Validation';

const userService = new UserService();

export class UserController {


  public async getUser(req: Request, res: Response): Promise<void> {
    try {
      const userId = req.user?.userId;
      if (!userId) {
        res.status(401).json({ message: 'User not authenticated' });
        return;
      }

      const user = await userService.getUserById(userId);
      if (!user) {
        res.status(404).json({ message: 'User not found' });
        return;
      }

      res.status(200).json({ user });
    } catch (error: any) {
      ErrorHandler.handleError(res, error);
    }
  }

  public async updateUser(req: Request, res: Response): Promise<void> {
    try {
      const userId = req.user?.userId;
      if (!userId) {
        res.status(401).json({ message: 'User not authenticated' });
        return;
      }
      const { error } = empValidationSchema.validate(req.body, { abortEarly: false });
      if (error) {
        res.status(400).json({ errors: error.details.map((err) => err.message) });
        return;
      }

      const { email, password, role } = req.body;
      const updatedUser = await userService.updateUserProfile(userId, { email, password, role });

      if (!updatedUser) {
        res.status(404).json({ message: 'User not found' });
        return;
      }

      res.status(200).json({ message: 'User profile updated successfully', updatedUser });
    } catch (error: any) {
      ErrorHandler.handleError(res, error);
    }
  }
}

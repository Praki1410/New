
import { Request, Response } from 'express';
import { AdminService } from '../service/adminService';
import { ErrorHandler } from '../error-handling/utlis';
import { empValidationSchema, updateUserSchema } from '../validation/Validation';

const adminService = new AdminService();

export class AdminController {
  
  public async getAllUsers(req: Request, res: Response): Promise<void> {
    try {
      const { role, status, page = "1", limit = "5" } = req.query;
      const filters = {
        role: role as string | undefined,
        status: status as string | undefined,
        page: Math.max(parseInt(page as string, 10) || 1, 1),
        limit: Math.max(parseInt(limit as string, 10) || 5, 1)
      };
      const { users, total, totalPages } = await adminService.getAllUsers(filters);
      
      res.status(200).json({
        success: true,
        data: users,
        pagination: {
          currentPage: Math.min(filters.page, totalPages),
          totalPages,
          totalItems: total,
          itemsPerPage: filters.limit,
          hasNextPage: filters.page < totalPages,
          hasPrevPage: filters.page > 1
        }
      });
    } catch (error: any) {
      ErrorHandler.handleError(res, error);
    }
  }

  public async getUserById(req: Request, res: Response): Promise<void> {
    try {
      const user = await adminService.getUserById(Number(req.params.userId));
      if (!user) return ErrorHandler.handleNotFound(res);
      res.status(200).json({ user });
    } catch (error: any) {
      ErrorHandler.handleError(res, error);
    }
  }

  public async deleteUser(req: Request, res: Response): Promise<void> {
    try {
      const deletedUser = await adminService.deleteUser(Number(req.params.userId));
      if (!deletedUser) return ErrorHandler.handleNotFound(res);
      res.status(200).json({ message: 'User deleted successfully' });
    } catch (error: any) {
      ErrorHandler.handleError(res, error);
    }
  }

  public async updateUserById(req: Request, res: Response): Promise<void> {
    try {
      const { error } = updateUserSchema.validate(req.body);
      if (error) return res.status(400).json({ error: error.details[0].message });
      
      const updatedUser = await adminService.updateUserById(Number(req.params.userId), req.body);
      if (!updatedUser) return ErrorHandler.handleNotFound(res);
      
      res.status(200).json({ message: 'User profile updated successfully', updatedUser });
    } catch (error: any) {
      ErrorHandler.handleError(res, error);
    }
  }
}


import { Request, Response } from 'express';
import { UserService } from '../service/authService';
import { ErrorHandler } from '../error-handling/utlis';
import { empValidationSchema } from '../validation/Validation';
import { setAuthCookies, validateRole } from '../helpers/authHelpers';
import { validateInput } from "../error-handling/utlis";

const userService = new UserService();

export class AuthController {

  public register = async (req: Request, res: Response): Promise<void> => {
    try {
      validateInput(empValidationSchema, req.body);
      const { email, password, role } = req.body;
      validateRole(role);

      await userService.registerUser(email, password, role);
      res.status(201).json({ message: 'User created successfully' });
    } catch (error: any) {
      ErrorHandler.handleError(res, error);
    }
  };

  public login = async (req: Request, res: Response): Promise<void> => {
    try {
      const { email, password } = req.body;
      const result = await userService.loginUser(email, password);
  
      res.clearCookie('token');
      res.clearCookie('role');
      res.clearCookie('userId');
      
      res.cookie('token', result.token, { httpOnly: true, secure: true, sameSite: 'Strict' });
      res.cookie('role', result.role, { httpOnly: true, secure: true, sameSite: 'Strict' });
      res.cookie('userId', result.userId.toString(), { httpOnly: true, secure: true, sameSite: 'Strict' });
  
      res.status(200).json({
        message: result.message,
        token: result.token,
        role: result.role,
        userId: result.userId,
      });
    } catch (error: any) {
      ErrorHandler.handleError(res, error);
    }
  };
  
  

  public logout = async (req: Request, res: Response): Promise<void> => {
    try {
      res.clearCookie('userId');
      res.clearCookie('token');
      res.clearCookie('role');
      res.status(200).json({ message: 'Logged out successfully' });
    } catch (error: any) {
      ErrorHandler.handleError(res, error);
    }
  };
}


import "dotenv/config";
import { DataSource } from "typeorm";
import { Emp_DB } from "../model/userModel";
import {TokenBlacklist} from "../model/TokenBlacklist"
import { PasswordResetToken } from "../model/PasswordResetToken"

export const AppData = new DataSource({
  type: "postgres",
  host: process.env.DB_HOST || "localhost",
  port: parseInt(process.env.DB_PORT || "5432"),
  username: process.env.DB_USERNAME || "postgres",
  password: process.env.DB_PASSWORD || "root",
  database: process.env.DB_DATABASE || "Demo",
  entities: [Emp_DB,TokenBlacklist,PasswordResetToken],
  migrations: ['src/migrations/**/*.ts'], 

  synchronize: true,  
  logging: true,

});



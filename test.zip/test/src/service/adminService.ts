import { AppData } from '../config/db';
import { Emp_DB } from '../model/userModel';

import { Role } from "../enum/Role";

export class AdminService {
  private userRepository = AppData.getRepository(Emp_DB);

  public async getAllUsers(filters: {
    role?: string;
    status?: string;
    page?: number;
    limit?: number;
  }): Promise<{ users: Emp_DB[]; total: number; totalPages: number }> {
    try {
      const where: any = {};
      if (filters.role) where.role = filters.role;
      if (filters.status) where.status = filters.status;

      const page = filters.page ?? 1;
      const limit = filters.limit ?? 10;
      const skip = (page - 1) * limit;
      
      const [users, total] = await Promise.all([
        this.userRepository.find({
          where,
          skip,
          take: limit,
          order: { id: 'DESC' }
        }),
        this.getUsersCount(where)
      ]);
  
      const totalPages = total > 0 ? Math.ceil(total / limit) : 1;
  
      return { users, total, totalPages };
    } catch (error) {
      throw new Error('Failed to fetch users');
    }
  }
  


  public async getUsersCount(where: any): Promise<number> {
    try {
      return await this.userRepository.count({ where });
    } catch (error) {
      throw new Error('Failed to count users');
    }
  }

  public async getUserById(userId: number): Promise<Emp_DB | null> {
    try {
      return await this.userRepository.findOne({ where: { id: userId } });
    } catch (error) {
      throw new Error('Failed to fetch user');
    }
  }

  public async deleteUser(userId: number): Promise<Emp_DB | null> {
    try {
      const user = await this.userRepository.findOne({ where: { id: userId } });
      
      if (!user) {
        return null;
      }
      
      await this.userRepository.remove(user);
      return user;
    } catch (error) {
      throw new Error('Failed to delete user');
    }
  }

  
  public async updateUserById(
    userId: number,
    updates: {
      email?: string;
      role?: string;
      password?: string;
    }
  ): Promise<Emp_DB | null> {
    try {
    
      const user = await this.userRepository.findOne({ where: { id: userId } });
      if (!user) {
        return null; 
      }
      if (updates.password) {
        throw new Error('To update your password, please visit the forgot password page.');
      }
      if (updates.role && !Object.values(Role).includes(updates.role as Role)) {
        throw new Error('Invalid role provided.');
      }
      const updatedFields: Partial<Emp_DB> = {};
      if (updates.email) {
        updatedFields.email = updates.email;
      }
  
      if (updates.role) {
        updatedFields.role = updates.role as Role;
      }
      if (Object.keys(updatedFields).length === 0) {
        return null;
      }
      await this.userRepository.update(userId, updatedFields);
      return { ...user, ...updatedFields };
    } catch (error) {
   
      throw new Error('Failed to update user details.');
    }
  }
  



  
  public async filterUsers(filters: { 
    role?: string; 
    email?: string;
    id?:any;
  }): Promise<Emp_DB[]> {
    try {
      const queryBuilder = this.userRepository.createQueryBuilder('user');
      
      if (filters.role) {
        queryBuilder.andWhere('user.role = :role', { role: filters.role });
      }
      if (filters.email) {
        queryBuilder.andWhere('user.email LIKE :email', { email: `%${filters.email}%` });
      }
      if (filters.id) {
        queryBuilder.andWhere('user.email LIKE :id', { id: `%${filters.id}%` });
      }
      
      return await queryBuilder.getMany();
    } catch (error) {
      throw new Error('Failed to filter users');
    }
  }
}

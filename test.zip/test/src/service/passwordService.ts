import { AppData } from "../config/db";
import { Emp_DB } from "../model/userModel";
import { PasswordResetToken } from "../model/PasswordResetToken";
import { EmailService } from "../mail/EmailService";
import bcrypt from "bcryptjs";
import crypto from "crypto";
import dotenv from "dotenv";

dotenv.config();

export class PasswordService {
  private userRepository = AppData.getRepository(Emp_DB);
  private tokenRepository = AppData.getRepository(PasswordResetToken);
  private emailService = new EmailService();

  public async forgotPassword(email: string): Promise<{ message: string }> {
    const user = await this.userRepository.findOne({ where: { email } });
    if (!user) throw new Error("Email not found");

    await this.tokenRepository.delete({ user: { id: user.id } });

    const resetToken = this.tokenRepository.create({
      token: crypto.randomBytes(32).toString("hex"),
      expiry: new Date(Date.now() + 300000),
      user,
    });

    await this.tokenRepository.save(resetToken);

    const resetLink = `${process.env.FRONTEND_URL}/reset-password/${resetToken.token}`;
    await this.emailService.sendPasswordResetEmail(email, resetLink);

    return { message: "Password reset email sent" };
  }

  public async resetPassword(token: string, newPassword: string): Promise<{ message: string }> {
    const resetToken = await this.tokenRepository.findOne({
      where: { token },
      relations: ["user"],
    });

    if (!resetToken || resetToken.expiry < new Date()) {
      throw new Error("Invalid or expired token");
    }

    const user = resetToken.user;
    user.password = await bcrypt.hash(newPassword, 10);

    await Promise.all([
      this.userRepository.save(user),
      this.tokenRepository.delete({ id: resetToken.id }),
    ]);

    return { message: "Password reset successfully" };
  }
}

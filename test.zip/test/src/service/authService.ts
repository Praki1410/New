import { AppData } from '../config/db';
import { Emp_DB } from '../model/userModel';
import { Role } from '../enum/Role';
import { Repository } from 'typeorm';
import { hashPassword, comparePassword, generateToken, validateInput } from '../error-handling/utlis'; 
import {empValidationSchema} from "../validation/Validation"


export class UserService {
  private userRepository: Repository<Emp_DB>;

  constructor() {
    this.userRepository = AppData.getRepository(Emp_DB);
  }


  
  public async registerUser(email: string, password: string, role: string): Promise<{ message: string }> {
    validateInput(empValidationSchema, { email, password, role });

    const existingUser = await this.userRepository.findOne({ where: { email } });
    if (existingUser) throw new Error('User already exists');

    const hashedPassword = await hashPassword(password); 
    const user = this.userRepository.create({
      email,
      password: hashedPassword,
      role: role as Role
    });

    await this.userRepository.save(user);
    return { message: 'User registered successfully' };
  }

  public async loginUser(email: string, password: string): Promise<{ message: string; token: string; userId: number; role: string }> {
    const user = await this.userRepository.findOne({ where: { email } });
    if (!user || !(await comparePassword(password, user.password))) { 
      throw new Error('Invalid credentials');
    }
    const token = generateToken(user.id, user.role, user.email); 

    return { message: 'Login successful', token, userId: user.id, role: user.role };
  }
}

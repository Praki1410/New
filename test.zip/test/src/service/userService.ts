import { AppData } from '../config/db';
import { Emp_DB } from '../model/userModel';
import bcrypt from 'bcrypt';
import { Role } from '../enum/Role';
import { updateUserSchema } from '../validation/Validation';

export class UserService {
  private userRepository = AppData.getRepository(Emp_DB);

  public async getUserById(userId: number): Promise<Emp_DB | null> {
    return await this.userRepository.findOne({ where: { id: userId } });
  }

  public async updateUserProfile(userId: number, updates: { email?: string; password?: string; role?: string }): Promise<Emp_DB | null> {
   
    const { error } = updateUserSchema.validate(updates);
    if (error) {
      throw { statusCode: 400, message: error.details[0].message };
    }

    const user = await this.userRepository.findOne({ where: { id: userId } });

    if (!user) {
      throw { statusCode: 404, message: 'User not found' };
    }

    if (updates.email) user.email = updates.email;
    if (updates.password) user.password = await bcrypt.hash(updates.password, 10)
    if (updates.role) user.role = updates.role as Role;

    await this.userRepository.save(user);
    return user;
  }
}




import nodemailer from "nodemailer";
import dotenv from "dotenv";

dotenv.config();

export class EmailService {
  private transporter: nodemailer.Transporter;

  constructor() {
    this.transporter = nodemailer.createTransport({
      host: 'smtp.gmail.com',
      service: "gmail",
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
      },
    });
  }

  public async sendPasswordResetEmail(email: string, resetLink: string): Promise<void> {
    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: email,
      subject: "Password Reset Request",
      html: `
        <div style="font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; text-align: center;">
          <div style="max-width: 500px; background: #ffffff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);">
            <h2 style="color: #333;">Password Reset Request</h2>
            <p style="color: #666;">You recently requested to reset your password. Click the button below to reset it:</p>
            <a href="${resetLink}" 
              style="display: inline-block; padding: 12px 20px; margin: 10px 0; font-size: 16px; color: #fff; background-color: #007bff; text-decoration: none; border-radius: 5px;">
              Reset Password
            </a>
            <p style="color: #666; font-size: 14px;">If you did not request a password reset, please ignore this email.</p>
            <hr style="border: 0; height: 1px; background: #ddd; margin: 20px 0;">
          </div>
        </div>
      `,
    };

    await this.transporter.sendMail(mailOptions);
    console.log("Generated Reset Link:", resetLink);
  }
}





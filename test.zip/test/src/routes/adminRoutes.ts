import { Router } from 'express';
import { authMiddleware } from '../middleware/authMiddleware';
import { AdminController } from '../controller/adminController';
import { handleRoleBasedAccess } from '../helpers/roleBasedAccess';
import { UserController } from '../controller/userController';

const router: Router = Router();
const adminController = new AdminController();
const userController = new UserController();


//Admin / user
router.get('/users', authMiddleware(), (req, res) =>
  handleRoleBasedAccess(req, res, adminController.getAllUsers)
);
//admin & user
router.get('/profile', authMiddleware(),(req, res) =>
  handleRoleBasedAccess(req, res, userController.getUser))

//admin & user
router.patch('/edit', authMiddleware(),(req, res) =>
  handleRoleBasedAccess(req, res, userController.getUser));

//only admin
router.get('/users/:userId', authMiddleware(), (req, res) =>
  handleRoleBasedAccess(req, res, adminController.getUserById)
);
//only admin
router.get('/users/role', authMiddleware(), (req, res) =>
  handleRoleBasedAccess(req, res, adminController.getAllUsers)
);


//only admin
router.patch('/users/:userId', authMiddleware(), (req, res) =>
  handleRoleBasedAccess(req, res, adminController.updateUserById)
);

//only admin
router.delete('/users/:userId', authMiddleware(), (req, res) =>
  handleRoleBasedAccess(req, res, adminController.deleteUser)
);

export default router;

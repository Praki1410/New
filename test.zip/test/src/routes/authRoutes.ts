import { Router } from 'express';
import { authMiddleware } from '../middleware/authMiddleware';
import { AuthController } from '../controller/authController';
import { PasswordController } from '../controller/passwordController';

const router: Router = Router();
const authController = new AuthController();
const passwordController = new PasswordController();


router.post('/register', authController.register);
router.post('/login', authController.login);
router.post('/logout', authMiddleware(), authController.logout);
router.post('/forgot-password', passwordController.forgotPassword);
router.post('/reset-password', passwordController.resetPassword);

export default router;

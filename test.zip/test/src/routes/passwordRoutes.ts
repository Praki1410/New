// import { Router } from 'express';
// import { PasswordController } from '../controller/passwordController';

// const router: Router = Router();
// const passwordController = new PasswordController();

// router.post('/forgot-password', passwordController.forgotPassword);
// router.post('/reset-password', passwordController.resetPassword);

// export default router;

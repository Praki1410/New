import { Request, Response } from "express";
import { addCategoryService, getAllCategoriesService,updateCategoryService,deleteCategoryService,getFishByCategoryService } from "../services/category.service";

export const createCategory = async (req: Request, res: Response): Promise<void> => {
    try {
        const { name, description } = req.body;
        if (!name) {
            res.status(400).json({ error: "Category name is required" });
            return;
        }

        const newCategory = await addCategoryService(name, description);
        res.status(201).json({ message: "📂 Category created successfully!", data: newCategory });
    } catch (error: any) {
        console.error("🔥 Error in createCategory:", error);
        res.status(500).json({ error: error.message || "Internal Server Error" });
    }
};


export const getAllCategories = async (req: Request, res: Response): Promise<void> => {
    try {
        const categories = await getAllCategoriesService();
        res.status(200).json({ message: "📂 Categories retrieved successfully!", data: categories });
    } catch (error: any) {
        console.error("🔥 Error in getAllCategories:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
};


export const getFishByCategory = async (req: Request, res: Response): Promise<void> => {
    try {
        const { categoryId } = req.params;

        if (!categoryId) {
            res.status(400).json({ error: "Category ID is required" });
            return;
        }

        const fishList = await getFishByCategoryService(categoryId);
        res.status(200).json({ message: "🐟 Fish retrieved successfully!", data: fishList });

    } catch (error: any) {
        console.error("🔥 Error in getFishByCategory:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
};



export const updateCategory = async (req: Request, res: Response): Promise<void> => {
    try {
        const { id } = req.params;
        const { name, description } = req.body;

        if (!name) {
            res.status(400).json({ error: "Category name is required" });
            return;
        }

        const updatedCategory = await updateCategoryService(id, name, description);
        res.status(200).json({ message: "📂 Category updated successfully!", data: updatedCategory });

    } catch (error: any) {
        console.error("🔥 Error in updateCategory:", error);
        res.status(500).json({ error: error.message || "Internal Server Error" });
    }
};
export const deleteCategory = async (req: Request, res: Response): Promise<void> => {
    try {
        const { id } = req.params;

        const deletedCategory = await deleteCategoryService(id);
        res.status(200).json({ message: "📂 Category deleted successfully!", data: deletedCategory });

    } catch (error: any) {
        console.error("🔥 Error in deleteCategory:", error);
        res.status(500).json({ error: error.message || "Internal Server Error" });
    }
};
import { Request, Response } from "express";
import { registerUser, loginUser } from "../services/auth.service";

export const register = async (req: Request, res: Response): Promise<void> => {
    try {
        const { name, email, password, role } = req.body;
        await registerUser(name, email, password, role);
        res.status(201).json({ message: "User registered successfully" });
    } catch (error: unknown) {
        res.status(500).json({ message: "Registration failed", error: (error as Error).message });
    }
};

export const login = async (req: Request, res: Response): Promise<void> => {
    try {
        const { email, password } = req.body;
        const { token, user } = await loginUser(email, password);

        const cookieOptions: import("express").CookieOptions = {
            httpOnly: true,
            secure: process.env.NODE_ENV === "production",
            sameSite: "strict",  
            maxAge: 3600000, 
        };

        res.cookie("token", token, cookieOptions);
        res.json({ message: "Login successful", user: { id: user.id, role: user.role }, token });
    } catch (error: unknown) {
        res.status(500).json({ message: "Login failed", error: (error as Error).message });
    }
};

export const logout = (req: Request, res: Response) => {
    res.clearCookie("token");
    res.json({ message: "Logout successful" });
};



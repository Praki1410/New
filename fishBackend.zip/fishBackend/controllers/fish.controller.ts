import { Request, Response } from "express";
import mongoose from "mongoose";
import {
    addFishService,
    getAllFishesService,
    getFishByIdService,
    updateFishService,
    deleteFishService,
} from "../services/fish.service";
import { FishCategory } from "../model/fish.model";

export const createFish = async (req: Request, res: Response): Promise<void> => {
    try {
        console.log("📜 Request Body:", req.body);
        console.log("📸 Uploaded File:", req.file);

        const {
            name,
            category,
            scientificName,
            size,
            weight,
            habitat,
            diet,
            price,
            temperament,
            careDifficulty,
            reefCompatible,
            maxSize,
            cost,
            waterConditions,
            minTankSize,
            compatibility,
            description,
        } = req.body;

        if (!name || !category) {
            res.status(400).json({ error: "Missing required fields: name or category" });
            return;
        }

        const file = req.file ? (req.file as unknown as { path?: string; secure_url?: string }) : null;
        const imageUrl = file?.secure_url || file?.path || "";

        if (!imageUrl) {
            res.status(400).json({ error: "Image is required" });
            return;
        }

        let categoryId;
        if (mongoose.Types.ObjectId.isValid(category)) {
            categoryId = category;
        } else {
            const categoryData = await FishCategory.findOne({ name: category });
            if (!categoryData) {
                res.status(400).json({ error: `Category '${category}' not found. Please add category first.` });
                return;
            }
            categoryId = categoryData._id;
        }

 
        const newFish = await addFishService({
            name,
            category: categoryId,
            scientificName,
            size,
            weight,
            habitat,
            diet,
            price,
            imageUrl,
            temperament,
            careDifficulty,
            reefCompatible,
            maxSize,
            cost,
            waterConditions,
            minTankSize,
            compatibility,
            description
        });

        res.status(201).json({
            message: "🐟 Fish created successfully!",
            data: newFish,
            category: {
                id: categoryId,
                name: category,
            },
        });
    } catch (error: any) {
        console.error("🔥 Error in createFish:", error);
        res.status(500).json({ error: error.message || "Internal Server Error" });
    }
};



export const getAllFishes = async (req: Request, res: Response): Promise<void> => {
    try {
        const fishes = await getAllFishesService();
        res.status(200).json({ message: "🐠 Fishes retrieved successfully!", data: fishes });
    } catch (error: any) {
        console.error("🔥 Error in getAllFishes:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
};


export const getFishById = async (req: Request, res: Response): Promise<void> => {
    try {
        const { id } = req.params;
        const fish = await getFishByIdService(id);
        res.status(200).json({ message: "🐡 Fish retrieved successfully!", data: fish });
    } catch (error: any) {
        console.error("🔥 Error in getFishById:", error);
        res.status(500).json({ error: error.message || "Internal Server Error" });
    }
};

export const updateFish = async (req: Request, res: Response): Promise<void> => {
    try {
        const { id } = req.params;
        const { 
            name, category, scientificName, size, weight, habitat, 
            diet, price, temperament, careDifficulty, reefCompatible, 
            maxSize, cost, waterConditions, minTankSize, compatibility, description 
        } = req.body;

        if (!mongoose.Types.ObjectId.isValid(id)) {
            res.status(400).json({ error: "Invalid fish ID format" });
            return;
        }

        if (category) {
            const categoryData = await FishCategory.findById(category);
            if (!categoryData) {
                res.status(400).json({ error: `Category '${category}' not found. Please add category first.` });
                return;
            }
        }

        const updatedFish = await updateFishService(id, {
            name, category, scientificName, size, weight, habitat, 
            diet, price, temperament, careDifficulty, reefCompatible, 
            maxSize, cost, waterConditions, minTankSize, compatibility, description
        });

        res.status(200).json({ message: "🐠 Fish updated successfully!", data: updatedFish });
    } catch (error: any) {
        console.error("🔥 Error in updateFish:", error);
        res.status(500).json({ error: error.message || "Internal Server Error" });
    }
};


export const deleteFish = async (req: Request, res: Response): Promise<void> => {
    try {
        const { id } = req.params;

        if (!mongoose.Types.ObjectId.isValid(id)) {
            res.status(400).json({ error: "Invalid fish ID format" });
            return;
        }

        await deleteFishService(id);
        res.status(200).json({ message: "🗑️ Fish deleted successfully!" });
    } catch (error: any) {
        console.error("🔥 Error in deleteFish:", error);
        res.status(500).json({ error: error.message || "Internal Server Error" });
    }
};

import { Request, Response, NextFunction } from "express";
import Joi from "joi";

const registerSchema = Joi.object({
    name: Joi.string().required(),
    email: Joi.string().email().required(),
    password: Joi.string().min(6).required(),
    role: Joi.string().valid("admin", "user"),
});

const loginSchema = Joi.object({
    email: Joi.string().email().required(),
    password: Joi.string().required(),
});

export const validateRegister = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
        const { error } = registerSchema.validate(req.body);
        if (error) {
            res.status(400).json({ error: error.details[0].message });
            return;
        }
        next();
    } catch (err) {
        next(err);
    }
};

export const validateLogin = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
        const { error } = loginSchema.validate(req.body);
        if (error) {
            res.status(400).json({ error: error.details[0].message });
            return; 
        }
        next();
    } catch (err) {
        next(err);
    }
};

import mongoose from "mongoose";
import { Fish, IFish } from "../model/fish.model";
import { FishCategory } from "../model/fish.model";


export const addFishService = async (
    fishData: {
        name: string;
        category: string;
        scientificName?: string;
        size?: string;
        weight?: string;
        habitat?: string;
        diet?: string;
        price?: number;
        imageUrl?: string;
        temperament?: string;
        careDifficulty?: string;
        reefCompatible?: boolean;
        maxSize?: string;
        cost?: number;
        waterConditions?: string;
        minTankSize?: string;
        compatibility?: string;
        description?: string;
    }
): Promise<IFish> => {
    try {

        const categoryId = new mongoose.Types.ObjectId(fishData.category);


        const fish = new Fish({
            name: fishData.name,
            category: categoryId,
            scientificName: fishData.scientificName,
            size: fishData.size,
            weight: fishData.weight,
            habitat: fishData.habitat,
            diet: fishData.diet,
            price: fishData.price,
            image: fishData.imageUrl,
            temperament: fishData.temperament,
            careDifficulty: fishData.careDifficulty,
            reefCompatible: fishData.reefCompatible,
            maxSize: fishData.maxSize,
            cost: fishData.cost,
            waterConditions: fishData.waterConditions,
            minTankSize: fishData.minTankSize,
            compatibility: fishData.compatibility,
            description: fishData.description,
        });


        return await fish.save();
    } catch (error: any) {
        console.error("🔥 Database Error:", error);
        throw new Error("Database operation failed!");
    }
};

// ✅ Get All Fishes Service
export const getAllFishesService = async () => {
    try {
        // Retrieve all fishes, populate category information
        return await Fish.find().populate("category", "name");
    } catch (error: any) {
        console.error("🔥 Database Error in getAllFishesService:", error);
        throw new Error("Failed to retrieve fishes");
    }
};

// ✅ Get Fish By ID Service
export const getFishByIdService = async (id: string): Promise<IFish | null> => {
    try {
        // Validate the fish ID format
        if (!mongoose.Types.ObjectId.isValid(id)) {
            throw new Error("Invalid fish ID format");
        }

        // Retrieve fish by ID, populate category information
        const fish = await Fish.findById(id).populate("category", "name");

        if (!fish) {
            throw new Error("Fish not found");
        }

        return fish;
    } catch (error: any) {
        console.error("🔥 Error in getFishByIdService:", error);
        throw new Error("Failed to retrieve fish by ID");
    }
};

// ✅ Update Fish Service
export const updateFishService = async (
    id: string,
    updateData: Partial<IFish>
): Promise<IFish | null> => {
    try {
        // Update fish entry with the provided data
        const updatedFish = await Fish.findByIdAndUpdate(id, updateData, { new: true })
            .populate("category", "name");

        if (!updatedFish) {
            throw new Error("Fish not found");
        }

        return updatedFish;
    } catch (error: any) {
        console.error("🔥 Database Error in updateFishService:", error);
        throw new Error("Database update failed!");
    }
};


export const deleteFishService = async (id: string): Promise<void> => {
    try {
        // Check if fish exists in the database
        const fish = await Fish.findById(id);
        if (!fish) {
            throw new Error("Fish not found");
        }

        // Delete the fish from the database
        await Fish.findByIdAndDelete(id);
    } catch (error: any) {
        console.error("🔥 Database Error in deleteFishService:", error);
        throw new Error("Database delete failed!");
    }
};

// ✅ Add Fish Category Service
export const addFishCategoryService = async (name: string, description?: string) => {
    try {
        const category = new FishCategory({
            name,
            description,
        });

        return await category.save();
    } catch (error: any) {
        console.error("🔥 Database Error in addFishCategoryService:", error);
        throw new Error("Failed to add fish category");
    }
};

// ✅ Get All Fish Categories Service
export const getAllFishCategoriesService = async () => {
    try {
        return await FishCategory.find();
    } catch (error: any) {
        console.error("🔥 Database Error in getAllFishCategoriesService:", error);
        throw new Error("Failed to retrieve fish categories");
    }
};

// ✅ Get Fish Category By ID Service
export const getFishCategoryByIdService = async (id: string) => {
    try {
        if (!mongoose.Types.ObjectId.isValid(id)) {
            throw new Error("Invalid category ID format");
        }

        const category = await FishCategory.findById(id);
        if (!category) {
            throw new Error("Category not found");
        }

        return category;
    } catch (error: any) {
        console.error("🔥 Error in getFishCategoryByIdService:", error);
        throw new Error("Failed to retrieve fish category");
    }
};

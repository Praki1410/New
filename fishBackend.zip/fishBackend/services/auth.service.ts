import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import User from "../model/user.model";

interface UserType {
    id: string;
    role: string;
    email: string;
    password: string;
}

export const registerUser = async (name: string, email: string, password: string, role: string) => {
    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = new User({ name, email, password: hashedPassword, role });
    return await newUser.save();
};

export const loginUser = async (email: string, password: string): Promise<{ token: string; user: UserType }> => {
    const user = await User.findOne({ email }).lean();
    
    if (!user) throw new Error("User not found");

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) throw new Error("Invalid credentials");

    const token = jwt.sign({ id: user._id.toString(), role: user.role }, process.env.JWT_SECRET as string, { expiresIn: "1h" });

    return { 
        token, 
        user: { id: user._id.toString(), role: user.role, email: user.email, password: user.password }  // ✅ Fix id issue
    };
};


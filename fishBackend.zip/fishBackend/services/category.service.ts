import { FishCategory,Fish } from "../model/fish.model";


export const addCategoryService = async (name: string, description?: string) => {
    try {
        const category = new FishCategory({ name, description });
        return await category.save();
    } catch (error: any) {
        console.error("🔥 Database Error:", error);
        throw new Error("Database operation failed!");
    }
};


export const getAllCategoriesService = async () => {
    return await FishCategory.find();
};

export const updateCategoryService = async (id: string, name: string, description?: string) => {
    try {
        const updatedCategory = await FishCategory.findByIdAndUpdate(
            id,
            { name, description },
            { new: true, runValidators: true }
        );

        if (!updatedCategory) {
            throw new Error("Category not found");
        }
        await Fish.updateMany(
            { category: id },
            { categoryName: name }
        );

        return updatedCategory;
    } catch (error: any) {
        console.error("🔥 Database Error:", error);
        throw new Error("Database operation failed!");
    }
};
export const deleteCategoryService = async (id: string) => {
    try {
        const category = await FishCategory.findByIdAndDelete(id);
        if (!category) {
            throw new Error("Category not found");
        }


        await Fish.updateMany(
            { category: id },
            { $unset: { category: "" } }
        );

        return category;
    } catch (error: any) {
        console.error("🔥 Database Error:", error);
        throw new Error("Database operation failed!");
    }
};
export const getFishByCategoryService = async (categoryId: string) => {
    try {
        const fishList = await Fish.find({ category: categoryId });
        return fishList;
    } catch (error: any) {
        console.error("🔥 Database Error:", error);
        throw new Error("Database operation failed!");
    }
};

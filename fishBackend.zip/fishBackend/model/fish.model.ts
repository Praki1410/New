

import mongoose, { Schema, Document } from "mongoose";


export interface IFishCategory extends Document {
    name: string;
    description?: string;
}


export interface IFish extends Document {
    name: string;
    category: mongoose.Schema.Types.ObjectId; 
    scientificName?: string;
    size?: string;
    weight?: string;
    habitat?: string;
    diet?: string;
    price?: number;
    image?: string;
    temperament?: string;            
    careDifficulty?: string;       
    reefCompatible?: boolean;         
    maxSize?: string;                
    cost?: number;                   
    waterConditions?: string;        
    minTankSize?: string;            
    compatibility?: string;          
    description?: string;           
}


const FishCategorySchema = new Schema<IFishCategory>({
    name: { type: String, required: true, unique: true },
    description: { type: String },
});


const FishSchema = new Schema<IFish>(
    {
        name: { type: String, required: true },
        category: { type: mongoose.Schema.Types.ObjectId, ref: "FishCategory", required: true },
        scientificName: { type: String },
        size: { type: String },
        weight: { type: String },
        habitat: { type: String },
        diet: { type: String },
        price: { type: Number },
        image: { type: String },
        temperament: { type: String },               
        careDifficulty: { type: String },           
        reefCompatible: { type: Boolean },           
        maxSize: { type: String },                   
        cost: { type: Number },                      
        waterConditions: { type: String },        
        minTankSize: { type: String },                
        compatibility: { type: String },             
        description: { type: String },                
    },
    { timestamps: true }
);


export const FishCategory = mongoose.model<IFishCategory>("FishCategory", FishCategorySchema);
export const Fish = mongoose.model<IFish>("Fish", FishSchema);

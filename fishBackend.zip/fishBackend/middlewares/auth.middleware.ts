import jwt, { JwtPayload } from "jsonwebtoken";
import { Request, Response, NextFunction } from "express";


export interface AuthRequest extends Request {
  user?: JwtPayload & { id: string; role: string };
}

export const verifyToken = (req: AuthRequest, res: Response, next: NextFunction): void => {
  try {

    const token = req.headers.authorization?.split(" ")[1] || req.cookies?.token;

    if (!token) {
      res.status(401).json({ error: "Unauthorized: No token provided" });
      return
    }


    const decoded = jwt.verify(token, process.env.JWT_SECRET as string) as JwtPayload & { id: string; role: string };

    req.user = decoded; 
    
    next(); 
  } catch (error) {
     res.status(403).json({ error: "Forbidden: Invalid token" });
     return
    }
};

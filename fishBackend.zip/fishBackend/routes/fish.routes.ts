import { Router } from "express";
import { verifyToken } from "../middlewares/auth.middleware";
import { upload } from "../middlewares/upload.middleware";
import {isAdmin}from "../middlewares/role.middleware"

import { createFish, getAllFishes, getFishById,updateFish,deleteFish } from "../controllers/fish.controller";
import { createCategory, getAllCategories,updateCategory,deleteCategory,getFishByCategory  } from "../controllers/category.controller";



const router = Router();



//for All
router.get("/",verifyToken, getAllFishes);
router.get("/getcategories", verifyToken,getAllCategories);
router.get("/category/:categoryId", verifyToken, getFishByCategory);

//only admin fish(category)
router.post("/addCategory",verifyToken,isAdmin ,createCategory);
router.put("/editCategory/:id", verifyToken,isAdmin, updateCategory);  
router.delete("/deleteCategory/:id", verifyToken,isAdmin, deleteCategory);


//onlyadmin(addfish)
router.post("/add-fish",verifyToken,isAdmin, upload.single("image"),createFish);
router.get("/:id",verifyToken,isAdmin, getFishById);
router.put("/editFish/:id",verifyToken,isAdmin,updateFish);
router.delete("/deleteFish/:id",verifyToken,isAdmin, deleteFish);


export default router;
